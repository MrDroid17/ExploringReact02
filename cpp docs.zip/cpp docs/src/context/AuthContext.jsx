import { useKeycloak } from "@react-keycloak/web"
import React, { createContext, useContext, useMemo, useState } from "react"

const AuthContext = createContext(undefined)

// eslint-disable-next-line react/function-component-definition
export const AuthProvider = ({ children }) => {
  const token = localStorage.getItem("token")
  const [isLoggedIn, setIsLoggedIn] = useState(!!token)
  const { keycloak } = useKeycloak();

  const login = () => {
    setIsLoggedIn(true)
  }

  const logout = () => {
    keycloak.logout();
    localStorage.clear();
    sessionStorage.clear();
    setIsLoggedIn(false)
  }

  return (
    <AuthContext.Provider
      value={useMemo(() => ({ isLoggedIn, login, logout }), [isLoggedIn])}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
