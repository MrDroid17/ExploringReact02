/* eslint-disable react-hooks/exhaustive-deps */
import React, { createContext, useContext, useMemo, useState } from "react";
import Loader from "../shared/ui/Loader";

const LoaderContext = createContext(undefined)

export function LoaderProvider({ children }) {
  const [isLoading, setIsLoading] = useState(false)

  const showLoader = state => {
    setIsLoading(state)
  }

  const contextValue = useMemo(
    () => ({
      isLoading,
      showLoader
    }),
    [isLoading, showLoader]
  )

  return (
    <LoaderContext.Provider value={contextValue}>
      {children}
      {isLoading && <Loader />}{" "}
      {/* Render Loader component if isLoading is true */}
    </LoaderContext.Provider>
  )
}

export function useLoader() {
  const context = useContext(LoaderContext)

  if (!context) {
    throw new Error("useLoader must be used within a LoaderProvider")
  }

  return context
}
