// ToastProvider.tsx

import React, { createContext, useContext, useMemo } from "react";
import { Bounce, ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const toasterConfig = {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
      transition: Bounce,
      newestOnTop:true,
      
}
const ToastContext = createContext(null);


export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider");
  }
  return context;
};

export function ToastProvider({ children }) {
  const showSuccessToast = ({ detail }) => {
    toast.success(detail,{toastId:'custom-id-yes'});
  };

  const showErrorToast = ({ detail }) => {
    toast.error(detail,{toastId:'custom-id-yes'});
  };


  return (
    <ToastContext.Provider
      value={useMemo(() => ({ showSuccess: showSuccessToast, showError: showErrorToast }), [])}
    >
      {children}

      <ToastContainer {...toasterConfig}/>
    </ToastContext.Provider>
  );
}
