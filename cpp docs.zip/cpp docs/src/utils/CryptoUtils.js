import CryptoJS from "crypto-js"

// Encryption function
export const encryptData = (key, data) => {
  try {
    const encrypted = CryptoJS.AES.encrypt(data, key).toString()
    return encrypted
  } catch (error) {
    console.error("Encryption error:", error)
    throw error
  }
}

// Decryption function
export const decryptData = (key, encryptedData) => {
  try {
    const bytes = CryptoJS.AES.decrypt(encryptedData, key)
    const decrypted = bytes.toString(CryptoJS.enc.Utf8)
    return decrypted
  } catch (error) {
    console.error("Decryption error:", error)
    throw error
  }
}


export const decrpt=(encryptedText)=> {
  let SECERET_KEY_DECRYPTION = 'AAAAAAAAAAAAAAAA';
  let SECERET_IV_DECRYPTION = 'BBBBBBBBBBBBBBBB';
  var Base64CBC = encryptedText;
  var iv = CryptoJS.enc.Utf8.parse(SECERET_IV_DECRYPTION);
  var key = CryptoJS.enc.Utf8.parse(SECERET_KEY_DECRYPTION);
  var decrypted = CryptoJS.AES.decrypt(Base64CBC, key, { iv: iv, mode: CryptoJS.mode.CBC });
  var finaleDecrptedValue = decrypted.toString(CryptoJS.enc.Utf8);
  return finaleDecrptedValue
}
