export const downloadFile = (data, filename) => {
    if (data && filename) {
      const fileUrl = data;
      const fileName = filename;
  
      // Create a temporary download link
      const link = document.createElement('a');
      link.href = fileUrl;
      link.download = decodeURIComponent(fileName); // Decode URL-encoded filename if necessary
  
      // Trigger the download
      document.body.appendChild(link);
      link.click();
  
      // Cleanup
      document.body.removeChild(link);
      console.log('File downloaded successfully!');
    } else {
      console.error('Invalid response format:');
    }
  };


export const formatDate = (date) => {
  if (!date) return "";
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${year}-${month}-${day}`;
};


export const awbNumberFormat = (e, fn, param) => {
  if (e.key === "Enter") {
    if (param !== undefined) {
      fn(param); 
    } else {
      fn(); 
    }
  }

  if (
    !/[0-9]/.test(e.key) &&
    e.key !== "Backspace" &&
    e.key !== "ArrowLeft" &&
    e.key !== "ArrowRight"
  ) {
    e.preventDefault();
  }
};