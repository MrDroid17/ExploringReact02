import { encryptData, decryptData } from "./CryptoUtils"

// Define your mappings
export const keyfile = {
  token: "ecomUserToken",
  username: "ecomUserName",
  data: "ecomUserData",
  groupCode: "ecomGroupCode"
}

export const localStoragekey = {
  token: "token",
  username: "username",
  data: "data",
  groupCode: "groupCode"
}

// Function to store encrypted data and its encryption key in localStorage
export const storeEncryptedData = (key, dataKey, data) => {
  try {
    const encrypted = encryptData(key, data) // Encrypt data using provided key
    const storageKey = localStoragekey[dataKey]
    localStorage.setItem(storageKey, encrypted)
  } catch (error) {
    console.error("Error storing encrypted data:", error)
    throw error // Handle or rethrow appropriately
  }
}

// Function to retrieve and decrypt data using its data key from localStorage
export const retrieveDecryptedData = (dataKey, key) => {
  try {
    const storageKey = localStoragekey[dataKey]
    const encryptedData = localStorage.getItem(storageKey)
    if (!encryptedData) return null

    const decrypted = decryptData(key, encryptedData) // Decrypt data using provided key
    return decrypted
  } catch (error) {
    console.error("Error retrieving decrypted data:", error)
    throw error // Handle or rethrow appropriately
  }
}

// Function to clear encrypted data from localStorage
export const clearEncryptedData = dataKey => {
  try {
    const storageKey = localStoragekey[dataKey]
    localStorage.removeItem(storageKey)
  } catch (error) {
    console.error("Error clearing encrypted data:", error)
    throw error // Handle or rethrow appropriately
  }
}
