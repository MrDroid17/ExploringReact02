export const queryIdMapping = {
    'Bad Address' : "badaddress-listing",
    Exceptions : "exception-listing",
    'To be Picked' : "tobepicked-listing",
    'Pickup Failed': "pickupfailed-listing",
    NDR : "ndr-listing",
    Manifest : 'manifest-listing',
    Delivered : "delivered-listing",
    'Forward Pickup' : 'forwardpickup-listing',
    'Reverse Pickup' : 'reversepickup-listing',
    'In-Transit' : 'intransit-listing',
    'Out for Delivery' : 'outfordelivery-listing',
    RTO : 'rto-listing',
    Collected : 'collected-listing',
    Undelivered : 'undelivered-listing'
  };

export const queryIdMappingAWB = {
    'Bad Address' : "badaddress-search-awb",
    Exceptions : "exception-search-awb",
    'To be Picked' : "tobepicked-search-awb",
    'Pickup Failed': "pickupfailed-search-awb",
    NDR : "ndr-search-awb",
    Manifest : 'manifest-search-awb',
    Delivered : "delivered-search-awb",
    'Forward Pickup' : 'forwardpickup-search-awb',
    'Reverse Pickup' : 'reversepickup-search-awb',
    'In-Transit' : 'intransit-search-awb',
    'Out for Delivery' : 'outfordelivery-search-awb',
    RTO : 'rto-search-awb',
    Collected : 'collected-search-awb',
    Undelivered : 'undelivered-search-awb'
};

export const queryIdMappingPaymentType = {
    'Bad Address' : "badaddress-search-paymenttype",
    Exceptions : "exception-search-paymenttype",
    'To be Picked' : "tobepicked-search-paymenttype",
    'Pickup Failed': "pickupfailed-search-paymenttype",
    NDR : "ndr-search-paymenttype",
    Manifest : 'manifest-search-paymenttype',
    Delivered : "delivered-search-paymenttype",
    'Forward Pickup' : 'forwardpickup-search-paymenttype',
    'Reverse Pickup' : 'reversepickup-search-paymenttype',
    'In-Transit' : 'intransit-search-paymenttype',
    'Out for Delivery' : 'outfordelivery-search-paymenttype',
    RTO : 'rto-search-paymenttype',
    Collected : 'collected-search-paymenttype',
    Undelivered : 'undelivered-search-paymenttype'
};