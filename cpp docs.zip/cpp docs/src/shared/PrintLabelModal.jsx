import React, { useState } from 'react'
import { Button, Card, Dropdown, Form, InputGroup, Modal } from 'react-bootstrap';

const PrintLabelModal = ({ printshow, handleprintClose }) => {


    const [selected, setSelected] = useState(true)
    const [selected1, setSelected1] = useState(true)
    const [selected2, setSelected2] = useState(true)
    const [selected3, setSelected3] = useState(true)
    

    const handleClose = () => {
        setSelected(true)
        handleprintClose()
    }

  return (
    <div className='track-order-modal'>
        <Modal className="custom-modal" show={printshow} onHide={handleprintClose}>
            <Modal.Header className='bg-slate-100'>
                <Modal.Title>Print Shipping Label</Modal.Title>
            </Modal.Header>

            <Modal.Body>
                <div>
                    <h6 className='mb-0'>Label Size</h6>
                    <p className='text-gray-400 text-xs'>Choose which print template size would you like to print</p>

                    <div className='flex justify-evenly'>
                        <Card style={{ width: '11rem' }} className={selected ? 'py-1 cursor-pointer !bg-slate-100' : 'py-1 cursor-pointer !bg-blue-600 text-white'} onClick={() => setSelected(!selected)}>
                            <Card.Body className='!p-1 px-2'>
                                <div className='!flex gap-3'>
                                    <Form.Check type="radio" aria-label="radio 1" />
                                    <div>
                                        <Card.Title className='!text-base mb-0'>Large</Card.Title>
                                        <Card.Text className='text-xs'>8 x 5.50 inch</Card.Text>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>

                        <Card style={{ width: '11rem' }} className={selected1 ? 'py-1 cursor-pointer !bg-slate-100' : 'py-1 !bg-blue-600 text-white cursor-pointer'} onClick={() => setSelected1(!selected1)}>
                            <Card.Body className='!p-1 px-2'>
                                <div className='!flex gap-3'>
                                    <Form.Check type="radio" aria-label="radio 1" />
                                    <div>
                                        <Card.Title className='!text-base mb-0'>Medium</Card.Title>
                                        <Card.Text className='text-xs'>4 x 5.50 inch</Card.Text>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>

                        <Card style={{ width: '11rem' }} className={selected2 ? 'py-1 cursor-pointer !bg-slate-100' : 'py-1 cursor-pointer !bg-blue-600 text-white'} onClick={() => setSelected2(!selected2)}>
                            <Card.Body className='!p-1 px-2'>
                                <div className='!flex gap-3'>
                                    <Form.Check type="radio" aria-label="radio 1" />
                                    <div>
                                        <Card.Title className='!text-base mb-0'>Small</Card.Title>
                                        <Card.Text className='text-xs'>4 x 2.5 inch</Card.Text>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </div>
                </div>

                <div className='mt-4'>
                    <h6 className='mb-0'>Customized Label</h6>
                    <p className='text-gray-400 text-xs'>Choose customized Label template which you created</p>
                    <div className='border-1 border-gray-400 p-2 h-20 rounded-lg'>
                        <Card style={{ width: '7rem' }} className='!bg-slate-100 cursor-pointer'>
                            <Card.Body className='!p-1 px-2'>
                                <div className='!flex gap-3'>
                                    <Form.Check type="radio" aria-label="radio 1" />
                                    <div>
                                        <Card.Title className='!text-base mb-0'>Default</Card.Title>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </div>
                </div>

                <div className='mt-4'>
                    <h6 className='mb-0'>Label Per Page</h6>
                    <p className='text-gray-400 text-xs'>Choose which Paper to use for print</p>
                    <div>
                        <Card style={{ width: '11rem' }} className={selected3 ? 'p-2 !bg-slate-100 cursor-pointer' : 'p-2 cursor-pointer !bg-blue-600 text-white'} onClick={() => setSelected3(!selected3)}>
                            <div className='!flex gap-3'>
                                <Form.Check type="radio" aria-label="radio 1" />
                                <Card.Title className='!text-base mb-0'>4 label</Card.Title>
                            </div>
                            
                                <Card.Body className={selected3 ? '!p-2 mt-2 text-center bg-white rounded-md cursor-pointer' : '!p-2 mt-2 text-center bg-white rounded-md cursor-pointer text-black'} onClick={() => setSelected3(!selected3)}>
                                    <p className='!text-xs mb-0'>A4 Paper Print</p>
                                </Card.Body>
                        </Card>
                    </div>
                </div>

            </Modal.Body>

            <Modal.Footer>
                <Button variant="outline-dark" onClick={() => handleClose()}>Cancel</Button>
                <Button className='!bg-pink-600 !border-pink-600'>Print</Button>
            </Modal.Footer>
        </Modal>
    </div>
  )
}

export default PrintLabelModal