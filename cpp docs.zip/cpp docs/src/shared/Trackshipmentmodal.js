// Modal.js
import React, { useState } from 'react';
import Dropdown from 'react-bootstrap/Dropdown';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import DatePicker from 'react-datepicker';
import Calendar from "../assets/images/calender.svg" 
import './Trackshipmentmodal.css'


const Trackshipmentmodal = ({ showModal, handleClose }) => {

      // Fetch the values of current date and date a week ago
      const today = new Date();
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(today.getDate() - 7);
    
      const [dateRange, setDateRange] = useState([oneWeekAgo, today]);
      const [startDate, endDate] = dateRange;

  return (
    
    <div className='track-order-modal'>
        <Modal className="custom-modal" show={showModal} onHide={handleClose}>
            <Modal.Header closeButton>
            <Modal.Title>Track Order</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <div className='flex gap-24'>
                 <div className='my-4'>
                     <span>Date</span>
                     <div style={{ position: "relative", display: "inline-block" }}>
                        <DatePicker
                            className="react-datepicker-for-range-generic p-2 !h-[40px]"
                            selectsRange={true}
                            startDate={startDate}
                            endDate={endDate}
                            onChange={(update) => {
                            setDateRange(update);
                            }}
                        />
                        <img
                            src={Calendar}
                            alt="calendar-icon"
                            style={{
                            position: "absolute",
                            right: "10px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            pointerEvents: "none",
                            }}
                        />
                    </div>
                 </div>
                 <div className='my-4'>
                     <span>Data Type</span>
                     <Dropdown>
                         <Dropdown.Toggle className='w-[245px]' variant="outline-dark" id="dropdown-basic">
                             Select
                         </Dropdown.Toggle>

                         <Dropdown.Menu className='w-[245px]'>
                             <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                             <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                             <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                         </Dropdown.Menu>
                     </Dropdown>
                 </div>
             </div>
             <div className='flex gap-24'>
                 <div className='my-4'>
                     <span>Product</span>
                     <Dropdown>
                         <Dropdown.Toggle className='w-[245px] text-left' variant="outline-dark" id="dropdown-basic">
                            <span className='text-left'>Select</span>
                         </Dropdown.Toggle>

                         <Dropdown.Menu className='w-[245px]'>
                             <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                             <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                             <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                         </Dropdown.Menu>
                     </Dropdown>
                 </div>
                 <div className='my-4'>
                     <span>Status Filter</span>
                     <Dropdown>
                         <Dropdown.Toggle className='w-[245px] text-left' variant="outline-dark" id="dropdown-basic">
                             Select
                         </Dropdown.Toggle>

                         <Dropdown.Menu className='w-[245px]'>
                             <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                             <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                             <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                         </Dropdown.Menu>
                     </Dropdown>
                 </div>
             </div>
            </Modal.Body>
            <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
                Cancel
            </Button>
            <Button variant="primary" onClick={handleClose}>
                Search
            </Button>
            </Modal.Footer>
        </Modal>
    </div>
  );
};

export default Trackshipmentmodal;
