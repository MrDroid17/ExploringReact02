import React from 'react'
import './ProgressBar.css'

const ProgressBar = ({ steps }) => {
  return (
    <div className="progress-bar-container">
      {steps.map((step, index) => (
        <div key={index} className="step-container">
          <div className={`dot ${step.active ? 'active' : 'inactive'}`}></div>
          <div className="step-labels">
            <span className="step-label">{step.label}</span>
            <span className="step-sublabel text-xs">{step.sublabel}</span>
          </div>
          {index < steps.length - 1 && <div className="connector"></div>}
        </div>
      ))}
    </div>
  )
}

export default ProgressBar