// DoughnutChart.js
import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
} from 'chart.js';

// Register the required components
ChartJS.register(ArcElement, Tooltip);

const DoughnutChart = ({ dashData }) => {
  const data = {
    labels: ['Collected', 'Out For Delivery', 'Undelivered'],
    datasets: [
      {
        label: 'COD Amount',
        data: [
          dashData.cod_collected_amount || 0,
          dashData.cod_ofd_amount || 0,
          dashData.cod_undelivered_amount || 0,
        ],
        backgroundColor: [
          'rgba(147, 197, 114, 0.2)', // Pistachio
          'rgba(52, 152, 219, 0.2)',  // Blue
          'rgba(255, 105, 180, 0.2)', // Pink
        ],
        borderColor: [
          'rgba(147, 197, 114, 1)',   // Pistachio
          'rgba(52, 152, 219, 1)',    // Blue
          'rgba(255, 105, 180, 1)',   // Pink
        ],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      tooltip: {
        enabled: true,
        callbacks: {
          label: function (tooltipItem) {
            const value = tooltipItem.raw;
            return `${value}`;
          },
        },
      },
    },
    cutout: '70%', // Same cutout for the smaller chart
  };

  const centerTextPlugin = {
    id: 'centerText',
    beforeDraw: (chart) => {
      const { width, height, ctx } = chart;
      ctx.save();

      // Dynamically calculate font size
      const countFontSize = Math.min(width, height) / 7;
      const labelFontSize = Math.min(width, height) / 15;

      // Draw the count text
      const countText = dashData.cod_delivered_count || '0';
      ctx.font = `${countFontSize}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#000'; // Black color for text
      ctx.fillText(countText, width / 2, height / 2 - 10); // Count above center

      // Draw the label text
      const labelText = 'Delivered';
      ctx.font = `${labelFontSize}px sans-serif`;
      ctx.fillStyle = '#666'; // Gray color for label text
      ctx.fillText(labelText, width / 2, height / 2 + 15); // Label below center

      ctx.restore();
    },
  };

  return (
    <div style={{ width: '70%', height: '210px' }}>
      <Doughnut data={data} options={options} plugins={[centerTextPlugin]} />
    </div>
  );
};

export default DoughnutChart;
