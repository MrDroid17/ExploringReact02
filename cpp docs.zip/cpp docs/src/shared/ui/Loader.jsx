import React, { useState } from "react"
import ScaleLoader from "react-spinners/ScaleLoader"

const override = {
  display: "block",
  margin: "0 auto",
  borderColor: "red"
}

function Loader() {
  const [loading] = useState(true)
  const [color] = useState("blue")

  return (
    <div className="app-loader">
      <div className="sweet-loading">
        <ScaleLoader
          color={color}
          loading={loading}
          cssOverride={override}
          aria-label="Loading Spinner"
          data-testid="loader"
        />
      </div>
    </div>
  )
}

export default Loader
