import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const ConfirmationDialog = ({showDialog, data, dialogTitle, description, closeButtonLabel, ConfirmButtonLabel, onConfirmation
    , onCancel}) => {
    const [show, setShow] = useState(showDialog);

    if(!showDialog) return null;
    
    const onConfirmClick = () =>{
        onConfirmation(data);
        setShow(false);
    }

    return (
        <>
            <Modal
                show={show}
                onHide={() => onCancel()}
                dialogClassName="modal-40w"
                aria-labelledby="example-custom-modal-styling-title"
            >
                <Modal.Header closeButton>
                    <Modal.Title id="example-custom-modal-styling-title">
                        {dialogTitle}
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p>
                        {description}
                    </p>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => {onCancel()}}>
                        {closeButtonLabel}
                    </Button>
                    <Button variant="primary" onClick={() => {onConfirmClick()}}>
                        {ConfirmButtonLabel}
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default ConfirmationDialog;