import React, { useState } from 'react'
import { Button, Modal } from 'react-bootstrap'
import ProgressBar from './ProgressBar/ProgressBar';

const Transithistoymodal = ({ transitshow, handletransitClose }) => {

    const [currentStep, setCurrentStep] = useState(2);
    const steps = [
        { 
          label: 'Delivery', 
          sublabel: 'to Consignee | HNH | 07 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 0 
        },
        { 
          label: 'Out For Delivery', 
          sublabel: 'MOHAMMED Haneef - DP117957 | HNH | 07 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 1 
        },
        { 
          label: 'Reached at Delivery Center', 
          sublabel: 'HNH | 06 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 2 
        },
        { 
          label: 'In Transit', 
          sublabel: 'MLR | HNH | 04 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 3 
        },
        { 
          label: 'Shipment Picked Up', 
          sublabel: 'MLR | 03 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 4 
        },
        { 
          label: 'Order Confirmed', 
          sublabel: 'MLR | 03 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 5 
        },
      ];      

  return (
    <div>
        <Modal show={transitshow} onHide={handletransitClose}>
            <Modal.Header style={{ backgroundColor: '#F4F5F7'}}>
                <Modal.Title>Transit History</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className='px-2'>
                    <ProgressBar steps={steps} />
                    {/* <div style={{ marginTop: '20px' }}>
                        <button
                        onClick={() => setCurrentStep((prev) => Math.min(prev + 1, steps.length - 1))}
                        >
                        Next Step
                        </button>
                        <button
                        onClick={() => setCurrentStep((prev) => Math.max(prev - 1, 0))}
                        >
                        Previous Step
                        </button>
                    </div> */}
                </div>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handletransitClose} style={{ backgroundColor: '#E10F76', borderColor: 'pink' }}>
                Cancel
                </Button>
            </Modal.Footer>
        </Modal>
    </div>
  )
}

export default Transithistoymodal