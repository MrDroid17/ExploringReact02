import React, { useEffect, useState } from "react";
import { Button, Form, InputGroup, Modal } from "react-bootstrap";
import DatePicker from "react-datepicker";
import { useForm, Controller } from "react-hook-form";
import Calendar from "../assets/images/calender.svg";
import { ApiUrl } from "./apiUrl";
import useHttps from "../hooks/useHttps";

const ReattemptModal = ({ show, handleClose, rowData }) => {

  const [alternativeNumber, setAlternativeNumber] = useState(false);
  const [startDate, setStartDate] = useState(new Date())
  const { getRequest } = useHttps();
  const [isDisabled, setIsDisabled] = useState(false);

  // React Hook Form setup
  const {
    register,
    handleSubmit,
    watch,
    control,
    reset,
    setValue,
    formState: { errors },
  } = useForm();

  const fetchPincode = async (pincode) => {
    try {
      const response = await getRequest(`${ApiUrl.PINCODE}?pincode=${pincode}`);
      console.log(response.data[0]);
      const { State, city_name } = response.data.length > 0 ? response.data[0] : '';

      // Set the values of `state` and `city`
      setValue("state", State);
      setValue("city", city_name);

      setIsDisabled(true);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  // Custom close handler to reset `alternativeNumber`
  const handleModalClose = () => {
    reset(); // Reset form state
    setAlternativeNumber(false); // Reset alternative number state
    setIsDisabled(false)
    handleClose(); // Call parent handler
  };

  const pincode = watch("pincode");

  useEffect(() => {
    if (pincode?.length === 6) {
      fetchPincode(pincode);
    }
  }, [pincode]);

  const onSubmit = (data) => {
    console.log("Form Submitted:", data);
    reset(); // Reset form after submission
    setAlternativeNumber(false); // Reset alternative number
    handleClose(); // Close modal
  };

  const awbNumber = rowData["AWB No/Order ID"].split(",")[0];

  return (
    <div>
      <Modal
        show={show}
        onHide={handleModalClose}
        size="lg"
        className="reattempt-modal"
      >
        <Modal.Header style={{ backgroundColor: "#F4F5F7" }}>
          <Modal.Title>Re Attempt - Shipment</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Modal.Body>
            <div className="reattempt m-2">
              {/* AWB number display at the top */}
              <div className="awb-top p-2 px-4 bg-blue-100 text-xs">
                <p className="mb-0 font-bold">AWB - {awbNumber}</p>
                <p className="mb-0">Consignee not available at home.</p>
              </div>

              {/* Fields input */}
              <div className="fields mt-3">
                <div className="row1 flex gap-5">
                  {/* Date Filter */}
                  <div className="field1-date flex-1">
                    <p className="mb-1">Re-Attempt Date</p>
                    <div style={{ position: "relative", display: "inline-block" }}>
                      <DatePicker
                        className="react-datepicker-for-range-generic p-2"
                        selected={startDate}
                        onChange={(update) => {
                          setStartDate(update);
                        }}
                      />
                      <img
                        src={Calendar}
                        alt="calendar-icon"
                        style={{
                          position: "absolute",
                          right: "10px",
                          top: "50%",
                          transform: "translateY(-50%)",
                          pointerEvents: "none",
                        }}
                      />
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div className="field1-number flex-1">
                    <p className="mb-1">Phone Number</p>
                    <InputGroup className="mb-1">
                      <InputGroup.Text id="basic-addon1">+91</InputGroup.Text>
                      <Form.Control
                        {...register("phoneNumber", {
                          required: "Phone number is required",
                          pattern: {
                            value: /^[0-9]{10}$/,
                            message: "Invalid phone number",
                          },
                        })}
                        placeholder="Phone Number"
                        aria-label="Phone Number"
                        aria-describedby="basic-addon1"
                      />
                    </InputGroup>
                    {errors.phoneNumber && (
                      <p className="text-red-500 text-xs">
                        {errors.phoneNumber.message}
                      </p>
                    )}
                    {!alternativeNumber && (
                      <p
                        onClick={() => setAlternativeNumber(true)}
                        className="mb-0 text-blue-500 cursor-pointer text-xs text-right"
                      >
                        Add Alternative Number
                      </p>
                    )}
                  </div>
                </div>

                {/* Alternative Number */}
                {alternativeNumber && (
                  <div className="field1-number w-1/2 my-4">
                    <p className="mb-1">Alternative Phone Number</p>
                    <InputGroup className="mb-1">
                      <InputGroup.Text id="basic-addon1">+91</InputGroup.Text>
                      <Form.Control
                        {...register("alternativePhoneNumber", {
                          pattern: {
                            value: /^[0-9]{10}$/,
                            message: "Invalid phone number",
                          },
                        })}
                        placeholder="Phone Number"
                        aria-label="Phone Number"
                        aria-describedby="basic-addon1"
                      />
                    </InputGroup>
                    {errors.alternativePhoneNumber && (
                      <p className="text-red-500 text-xs">
                        {errors.alternativePhoneNumber.message}
                      </p>
                    )}
                  </div>
                )}

                {/* Address Line input */}
                <div className="addressline">
                  <p className="mb-1">Shipping Address Line 1</p>
                  <input
                    {...register("addressLine", { required: "Address line is required" })}
                    className="border p-2 rounded-sm w-[100%]"
                    placeholder="Enter Address Line 1"
                  />
                  {errors.addressLine && (
                    <p className="text-red-500 text-xs">{errors.addressLine.message}</p>
                  )}
                </div>
              </div>

              {/* Landmark and Pincode */}
              <div className="field3 flex gap-5 mt-6">
                <div className="landmark flex-1">
                  <p className="mb-1">Land Mark</p>
                  <input
                    {...register("landmark")}
                    className="border p-2 rounded-sm w-full"
                    placeholder="Enter Land Mark"
                  />
                </div>
                <div className="pincode flex-1">
                  <p className="mb-1">Pincode</p>
                  <input
                    {...register("pincode", {
                      required: "Pincode is required",
                      pattern: {
                        value: /^[0-9]{6}$/,
                        message: "Invalid pincode",
                      },
                    })}
                    className="border p-2 rounded-sm w-full"
                    placeholder="Enter Pincode"
                    disabled={isDisabled}
                  />
                  {errors.pincode && (
                    <p className="text-red-500 text-xs">{errors.pincode.message}</p>
                  )}
                </div>
              </div>

              {/* State and City */}
              <div className="field4 flex gap-5 mt-6">
                <div className="state flex-1">
                  <p className="mb-1">State</p>
                  <input
                    {...register("state", { required: "State is required" })}
                    className="border p-2 rounded-sm w-full"
                    placeholder="Enter State"
                    disabled={isDisabled}
                  />
                  {errors.state && (
                    <p className="text-red-500 text-xs">{errors.state.message}</p>
                  )}
                </div>
                <div className="city flex-1">
                  <p className="mb-1">City</p>
                  <input
                    {...register("city", { required: "City is required" })}
                    className="border p-2 rounded-sm w-full"
                    placeholder="Enter City"
                    disabled={isDisabled}
                  />
                  {errors.city && (
                    <p className="text-red-500 text-xs">{errors.city.message}</p>
                  )}
                </div>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button
              className="text-xs"
              variant="outline-dark"
              onClick={handleModalClose}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="text-xs"
              style={{ backgroundColor: "#E10F76", borderColor: "pink" }}
            >
              Confirm
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </div>
  );
};

export default ReattemptModal;
