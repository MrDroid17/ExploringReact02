import React, { useEffect, useState } from 'react';
import './Listing.css';
import { Button, Dropdown, PageItem, Tab, Table, Tabs } from 'react-bootstrap';
import Reattemptmodal from '../../shared/Reattemptmodal';
import Transithistoymodal from '../../shared/Transithistoymodal';
import { useNavigate, useParams } from 'react-router-dom';
import { ApiUrl } from '../../shared/apiUrl';
import useHttps from '../../hooks/useHttps';
import download from "../../assets/images/download.svg"
import refresh from "../../assets/images/refresh.svg"
import search from "../../assets/images/ic_search.svg"
import Pagination from 'react-bootstrap/Pagination';
import DatePicker from 'react-datepicker';
import Calendar from "../../assets/images/calender.svg" 
import Origin from "../../assets/images/origin_point.svg"
import Destination from "../../assets/images/destination_point.svg"
import { awbNumberFormat, formatDate } from '../../utils/common';
import { toast } from 'react-toastify';
import Printer from "../../assets/images/Print icon.svg"
import Filter from "../../assets/images/filter.svg"
import PrintLabelModal from '../../shared/PrintLabelModal';
import { queryIdMapping, queryIdMappingAWB, queryIdMappingPaymentType } from '../../utils/ListingConstants';

const Listing = () => {

  const { screen } = useParams();
  const [show, setShow] = useState(false);
  const [transitShow, setTransitShow] = useState(false);
  const [printShow, setPrintShow] = useState(false)
  const [selectedRow, setSelectedRow] = useState(null);
  const [listingData, setListingData] = useState([]);
  const [allData, setAllData] = useState([])
  const [ndrHeader, setNdrHeader] = useState([]);
  const { postRequest } = useHttps();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [inputAWBValue, setInputAWBValue] = useState('');
  const [CODCheck, setCODCheck] = useState(false)
  const [PPDCheck, setPPDCheck] = useState(false)
  const [awbList, setAwbList] = useState([])
  const [allChecked, setAllChecked] = useState(false); // State for "Select All"
  const [rowCheckboxStates, setRowCheckboxStates] = useState(
    listingData.map(() => false) // Initialize individual row checkbox states as false
  );
  let awbNumberList = []


  // Fetch the values of current date and date a week ago
  const today = new Date();
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(today.getDate() - 7);

  const [dateRange, setDateRange] = useState([oneWeekAgo, today]);
  const [startDate, endDate] = dateRange;


  // Called when Paginator is in action and page is changed
  useEffect(() => {
    fetchData(currentPage);
  }, [currentPage]);



   // Called when Date Range is selected
   useEffect(() => {
    if (startDate && endDate) {
      fetchData(1);
    }
  }, [dateRange]);



  // Function to navigate the user to tracking page 
  const handleAWBClick = (awbNumber) => {
    console.log(awbNumber)
    navigate(`/home/trackShipment/${awbNumber}`);
  };


  // Functions to handle modals opening
  const handleShowModal = (row) => {
    setSelectedRow(row);
    setShow(true);
  };

  const handleShowTransit = (row, event) => {
    event.stopPropagation();
    setSelectedRow(row);
    setTransitShow(true);
  };

  const handleShowPrintModal = () => {
    setPrintShow(true);
    console.log(printShow)
  }



  // Function to fetch data for different screens according to their respective queryid
  const fetchData = async (page) => {
    const from_date = formatDate(startDate)
    const to_date = formatDate(endDate)
    const list_name = "Manifestation"
    const queryId = queryIdMapping[screen]
    try {
      const response = await postRequest(
        `${ApiUrl.LISTING}?query_id=${queryId}&page_no=${page}&size=25&from_date=${from_date}&to_date=${to_date}&list_name=${list_name}`);
      setListingData(response.data.records); 
      setNdrHeader(response.data.header);
      setAllData(response.data.records);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };




  // Function to handle the checkbox change for ppd and cod filter of payment type
  const handleCheckboxChange = async (e) => {
    const { id, checked } = e.target;
  
    if (id === "cod") {
      setCODCheck(checked);
    } else if (id === "ppd") {
      setPPDCheck(checked);
    }
  
    const updatedCODCheck = id === "cod" ? checked : CODCheck;
    const updatedPPDCheck = id === "ppd" ? checked : PPDCheck;
  
    if (updatedCODCheck === updatedPPDCheck) {
      setListingData(allData);
      return;
    }
  
    const paymentType = updatedCODCheck ? "cod" : "ppd";
  
    const from_date = formatDate(startDate);
    const to_date = formatDate(endDate);
    const list_name = "Manifestation";
  
    const queryId = queryIdMappingPaymentType[screen];
  
    try {
      const response = await postRequest(
        `${ApiUrl.LISTING}?query_id=${queryId}&page_no=${currentPage}&size=25&from_date=${from_date}&to_date=${to_date}&list_name=${list_name}&payment_type='${paymentType}'`
      );
      setListingData(response.data.records);
      setNdrHeader(response.data.header);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  



  // Function to handle submit search functionality
  const handleSubmit = async () => {
    const minLength = 5;
    const maxLength = 20;


    if (!inputAWBValue){
      fetchData(currentPage)
    }
    
    if ((inputAWBValue.length < minLength || inputAWBValue.length > maxLength) && inputAWBValue) {
      toast.error(`Input length must be between ${minLength} and ${maxLength} characters`);
    }

    else if (inputAWBValue.length > minLength && inputAWBValue.length < maxLength) {
      const from_date = formatDate(startDate)
      const to_date= formatDate(endDate)
      const list_name= "Manifestation"
      const awb_number= inputAWBValue

      const queryId = queryIdMappingAWB[screen]
      try {
        const response = await postRequest(
          `${ApiUrl.LISTING}?query_id=${queryId}&page_no=${currentPage}&size=25&from_date=${from_date}&to_date=${to_date}&list_name=${list_name}&awb_number=${awb_number}`);
        setListingData(response.data.records); 
        setNdrHeader(response.data.header);
        console.log(listingData)
      } catch (error) {
        console.error('Error fetching data:', error);
      }

      console.log('Submitting value:', inputAWBValue);
    }
  };




  const handleSelectAllChange = () => {
    const newAllChecked = !allChecked; // Toggle select all
    setAllChecked(newAllChecked);
  
    // Set all checkboxes to the new state
    const newRowCheckboxStates = listingData.map(() => newAllChecked);
    setRowCheckboxStates(newRowCheckboxStates);
  
    // Update AWB List based on selection
    if (!newAllChecked) {
      setAwbList(listingData.map(item => item[ndrHeader[0]].split(",")[0])); // Add all AWBs
    } else {
      setAwbList([]); // Clear AWB List when deselecting all
    }

    console.log(awbList)
  };
  
  // Function to check particular checkboxes for downloading records
  const handleRowCheckboxChange = (index, awb) => {
    setRowCheckboxStates((prevStates) => {
      const updatedStates = [...prevStates];
      updatedStates[index] = !updatedStates[index]; 
      return updatedStates;
    });
  
    setAwbList((prevList) => {
      const newList = prevList.includes(awb) 
        ? prevList.filter((item) => item !== awb) 
        : [...prevList, awb];
      return newList;
    });
  
    // Ensure select-all checkbox updates correctly
    setAllChecked((prevAllChecked) => {
      const allChecked = rowCheckboxStates.every((state) => state);
      return allChecked;
    });
  };




  const handlePageChange = (page) => {
    if (page !== currentPage) {
      setCurrentPage(page);
    }
  };

  return (
    <div className="ndr w-[100%]">
      <Tabs defaultActiveKey="ndr" transition={false} id="noanim-tab-example" className="custom-tabs">
        <Tab eventKey="ndr" title={screen}>
            <div className="ndr-header flex justify-between mt-2 items-center">
                <div className="input-container">
                    <img className="icon" src={search} alt="search icon" />
                    <input className="header-search" 
                      onChange={(e) => setInputAWBValue(e.target.value)}
                      onKeyDown={(e) => awbNumberFormat(e, handleSubmit)} 
                      placeholder="Search AWB Number" 
                    />
                </div>
                <div className="flex gap-4">
                <div style={{ position: "relative", display: "inline-block" }}>
                  <DatePicker
                    className="react-datepicker-for-range-generic p-2"
                    selectsRange={true}
                    startDate={startDate}
                    endDate={endDate}
                    onChange={(update) => {
                      setDateRange(update);
                    }}
                  />
                  <img
                    src={Calendar}
                    alt="calendar-icon"
                    style={{
                      position: "absolute",
                      right: "10px",
                      top: "50%",
                      transform: "translateY(-50%)",
                      pointerEvents: "none",
                    }}
                  />
                </div>
                    <img className="cursor-pointer w-6 h-6" src={download} alt="download icon" title="Download Data"/>
                    <img className="cursor-pointer w-6 h-6" src={Printer} onClick={() => handleShowPrintModal()} alt="print label icon" title="Print Label"/>
                    <img className="cursor-pointer w-6 h-6" onClick={() => fetchData(currentPage)} src={refresh} alt="refresh icon" title="Refresh Data"/>
                </div>
            </div>
          {<PrintLabelModal printshow={printShow} handleprintClose={() => setPrintShow(false)} />}
          <Table className="custom-table mb-4 mt-2" hover responsive>
            <thead>
            <tr className="ndr-header">
              <th><input type="checkbox" checked={allChecked}
              onChange={handleSelectAllChange} /></th>
              {ndrHeader.map((header, index) => (
                <th
                  key={index}
                  className={header =='Payment Type' ? `ndr-header-filter` : "ndr-header"}
                >
                  {header}
                  {header =='Payment Type' ? 
                  <Dropdown>
                  {/* Replace the default toggle button with a custom one */}
                    <Dropdown.Toggle 
                      as="div" 
                      id="dropdown-custom-toggle" 
                      style={{ display: "inline-flex", alignItems: "center", cursor: "pointer" }}
                    >
                      <img src={Filter} alt="Filter Icon" className='w-3 h-3 mx-2' />
                    </Dropdown.Toggle>
            
                    <Dropdown.Menu>
                    <Dropdown.Item
                      href="#/action-1"
                      onClick={(e) => e.stopPropagation()}
                      className="border-b-2 my-2"
                    >
                      <input
                        className="mr-3"
                        onChange={handleCheckboxChange}
                        id="cod"
                        type="checkbox"
                      />
                      COD
                    </Dropdown.Item>
                    <Dropdown.Item href="#/action-2" onClick={(e) => e.stopPropagation()}>
                      <input
                        className="mr-3"
                        onChange={handleCheckboxChange}
                        id="ppd"
                        type="checkbox"
                      />
                      PPD
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
                 : ''}
                </th>
              ))}
              {/* <th className="ndr-header">Action</th> */}
            </tr>
            </thead>
            <tbody>
              {listingData.length ?
              listingData.map((item, index) => (
                <tr key={index}>
                  <td><input type="checkbox" checked={rowCheckboxStates[index] || false} onChange={() => handleRowCheckboxChange(index,item[ndrHeader[0]].split(",")[0])}
                /></td>
                  <td className='w-[150px]'>
                    <a onClick={() => handleAWBClick(item[ndrHeader[0]].split(",")[0])} className="mb-0 cursor-pointer">{`AWB- ${item[ndrHeader[0]].split(",")[0]}`}</a>
                    <p className="mb-0">{`Order ID- ${item[ndrHeader[0]].split(",")[1]}`}</p>
                  </td>
                  <td>{item[ndrHeader[1]].toUpperCase()}</td>
                  <td>{item[ndrHeader[2]].toUpperCase()}</td>
                  <td onClick={(e) => handleShowTransit(item, e)}>
                    <div className="flex items-center justify-center h-full w-full">
                      
                      <div className="text-center flex-1">
                        <p className="mb-0">{item[ndrHeader[3]].split(",")[0]}</p>
                        <p className="mb-0">{item[ndrHeader[3]].split(",")[1]}</p>
                      </div>
                      <div className="flex items-center mx-2">
                        <img className="w-5 h-5" src={Origin} alt="Origin" />
                        <div className="flex-1 border-t-2 border-dotted border-gray-400 min-w-[30px]"></div>
                        <img className="w-5 h-5" src={Destination} alt="Destination" />
                      </div>

                      <div className="text-center flex-1">
                        <p className="mb-0">{item[ndrHeader[3]].split(",")[2]}</p>
                        <p className="mb-0">{item[ndrHeader[3]].split(",")[3]}</p>
                      </div>
                    </div>
                  </td>


                  <td className="!w-[250px]">
                    <p className="mb-0 text-left">{item[ndrHeader[4]].split(",")[0] + ',' + item[ndrHeader[4]].split(",")[1]}</p>
                    <p className="mb-0 text-left">{item[ndrHeader[4]].split(",")[2]}</p>
                    <p className='mb-0 text-left'>({item[ndrHeader[4]].split(",")[3]})</p>
                  </td>
                  <td className="">
                    <div className="flex gap-2 items-center justify-center h-full">
                      {item[ndrHeader[5]] ? (
                        <>
                          {(item[ndrHeader[5]][0] === 'reattempt') && (
                            <Button
                              onClick={() => handleShowModal(item)}
                              className="!text-xs"
                              variant="outline-dark"
                            >
                              {item[ndrHeader[5]][0]}
                            </Button>
                          )}
                          {(item[ndrHeader[5]][0] === 'scheduledelivery') && (
                            <Button
                              className="!text-xs"
                              variant="outline-dark"
                            >
                              {item[ndrHeader[5]][0]}
                            </Button>
                          )}
                          {(item[ndrHeader[5]][1] === 'return/mark rts') && (
                            <Button
                              className="!text-xs"
                              variant="outline-dark"
                            >
                              {item[ndrHeader[5]][1]}
                            </Button>
                          )}
                        </>
                      ) : <div className='font-medium'>- - - -</div> }
                      {/* {console.log("Value of item[ndrHeader[5]]:", item[ndrHeader[5]].length)} */}
                      
                    </div>
                  </td>
                </tr>
              ))
             : <div className='text-md text-red-500 m-2'>No records Found</div>}
            </tbody>
          </Table>
        </Tab>
      </Tabs>
      {selectedRow && (
        <>
          <Reattemptmodal show={show} handleClose={() => setShow(false)} rowData={selectedRow} />
          <Transithistoymodal transitshow={transitShow} handletransitClose={() => setTransitShow(false)} rowData={selectedRow} />
        </>
      )}
        <div className='float-right mr-2'>
            <Pagination size='lg'>
                <Pagination.Prev onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1 || listingData.length <= 25}/>
                <Pagination.Next onClick={() => handlePageChange(currentPage + 1)} disabled={listingData.length <= 25}/>
            </Pagination>
        </div>
    </div>
  );
};

export default Listing;