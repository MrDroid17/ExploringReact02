import React from 'react'
import './PaymentDetails.css'

const PaymentDetails = () => {
  return (
    <div className='delivery-details border-2 rounded-md p-2 shadow-sm flex-1'>
        <div className='flex justify-between align-content-center'>
            <p className='font-bold mx-2'>Payment Details</p>
            <button className='bg-slate-100 text-xs px-1 rounded-md shadow-sm py-0 border-2'>Print Invoice</button>
        </div>

        <div className='charges mt-4 m-4'>
            <p className='mb-4'>Shipping Charge Breakup</p>
            <div className='flex justify-between'>
                <p className='text-sm'>Frieght Cost</p>
                <p>₹54.08</p>
            </div>
            <div className='flex justify-between'>
                <p className='text-sm'>Fuel Subcharge & DPH</p>
                <p>₹0.78</p>
            </div>
            <div className='flex justify-between'>
                <p className='text-sm'>Prepaid Delivery</p>
                <p>₹40.00</p>
            </div>
            <div className='flex justify-between'>
                <p className='text-sm'>GST - 18% (CGST=SGST)</p>
                <p>₹17.06</p>
            </div>
            <div className='flex justify-between border-t-2 border-t-slate-400 pt-3'>
                <p className='font-bold text-lg'>Total</p>
                <p className='font-bold'>₹111.84</p>
            </div>
        </div>
        
    </div>
  )
}

export default PaymentDetails