import React from 'react'
import './DeliveryDetails.css'

const DeliveryDetails = () => {
  return (
    <div className='delivery-details border-2 rounded-md p-2 shadow-sm flex-1'>
        <p className='font-bold mx-2'>Delivery Details</p>
        <div>
            <p className='mx-2 mb-1'>Pickup Address</p>
            <div className='pickup-address m-2 p-2 border-2 rounded-sm shadow-sm bg-slate-100'>
                <p className='mb-0'>Avi Fashions</p>
                <p className='mb-0 text-xs'>4th & 5th Floor EIL Annexe  Building </p>
                <p className='mb-0 text-xs'>Bhikaji Cama Place, New Delhi - 110066 </p>
            </div>
        </div>

        <div className='!mt-6'>
            <p className='mx-2 mb-1'>Delivery Address</p>
            <div className='delivery-address m-2 p-2 border-2 rounded-sm shadow-sm bg-slate-100'>
                <p className='mb-0'>Avi Fashions</p>
                <p className='mb-0 text-xs'>4th & 5th Floor EIL Annexe  Building </p>
                <p className='mb-0 text-xs'>Bhikaji Cama Place, New Delhi - 110066 </p>
                <p className='mb-1 text-xs'>Mobile : 9494930293</p>
            </div>
        </div>
    </div>
  )
}

export default DeliveryDetails