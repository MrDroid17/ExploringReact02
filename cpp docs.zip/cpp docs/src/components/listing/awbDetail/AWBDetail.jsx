import React, { useState } from 'react'
import './AWBDetail.css'
import { Badge, Button } from 'react-bootstrap'
import PackageDetails from './packagedetails/PackageDetails'
import ProgressBar from '../../../shared/ProgressBar/ProgressBar'
import DeliveryDetails from './deliverydetails/DeliveryDetails'
import PaymentDetails from './paymentdetails/PaymentDetails'
import Reattemptmodal from '../../../shared/Reattemptmodal'

const AWBDetail = () => {

    const [show, setShow] = useState(false);
    const [currentStep, setCurrentStep] = useState(2);

    const handleShow = () => setShow(true); 
    const handleClose = () => setShow(false);

    const steps = [
        { 
          label: 'Delivery', 
          sublabel: 'to Consignee | HNH | 07 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 0 
        },
        { 
          label: 'Out For Delivery', 
          sublabel: 'MOHAMMED Haneef - DP117957 | HNH | 07 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 1 
        },
        { 
          label: 'Reached at Delivery Center', 
          sublabel: 'HNH | 06 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 2 
        },
        { 
          label: 'In Transit', 
          sublabel: 'MLR | HNH | 04 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 3 
        },
        { 
          label: 'Shipment Picked Up', 
          sublabel: 'MLR | 03 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 4 
        },
        { 
          label: 'Order Confirmed', 
          sublabel: 'MLR | 03 Oct, 2024, 17:21 hrs', 
          active: currentStep >= 5 
        },
      ];  

  return (
    <div className='awb-details rounded-md p-4'>
        <div className='awb-details-details flex-1'>
            <div className='awb-details-header mb-1'>
                <div className="inline-block bg-green-100 text-green-700 px-3 p-1 text-xs rounded-full backdrop-blur-sm">
                    Delivered
                </div>
                <div className="inline-block mx-3 bg-gray-100 px-3 p-1 text-xs rounded-full backdrop-blur-sm">
                    Ordered on: May 19, 2024
                </div>
                <div className="inline-block bg-gray-100 px-3 p-1 text-xs rounded-full backdrop-blur-sm">
                    Surface
                </div>
            </div>

            <div className='awb-details-content p-2'>
                <PackageDetails />
            </div>
            <div className='delivery-payment-details p-2'>
                <DeliveryDetails />
                <PaymentDetails />
            </div>
        </div> 

        <div>
            <div className='awb-details-track flex-2 border-2 p-3 rounded-md'>
                <p className='font-bold mx-2'>Order Tracker</p>
                <div className='delivery-address m-2 px-4 py-3 border-2 rounded-md shadow-sm bg-slate-100'>
                    <p className='font-bold text-xs mb-0'>AWB No.- 9898989898 </p>
                    <p className='text-xs'>Order ID- 56897124</p>
                    <div className='flex'>
                        <div className='flex-1'>
                            <p className='mb-0 font-bold text-xs'>Box Size</p>
                            <p className='mb-0 text-xs'>27x20x15</p>
                        </div>
                        <div className='flex-1'>
                            <p className='mb-0 font-bold text-xs'>Box Weight</p>
                            <p className='mb-0 text-xs'>500gm</p>
                        </div>
                    </div>
                </div>
                <ProgressBar steps={steps} />
            </div> 
            <div className='buttons space-x-1 my-2'>
                <Button className='w-[49%] px-0 !text-xs bg-white text-black !border-[#C5C7C9]' onClick={handleShow}>Re Attempt</Button>
                <Button className='w-[49%] px-0 !text-xs !bg-[#E10F76] text-white !border-[#C5C7C9]'>Return/ Mark RTS</Button>
            </div>
            <Reattemptmodal show={show} handleClose={handleClose} />
        </div>

    </div>
  )
}

export default AWBDetail