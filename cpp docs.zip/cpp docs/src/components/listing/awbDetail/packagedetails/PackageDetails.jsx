import React from 'react'
import './PackageDetails.css'
import Table from 'react-bootstrap/Table';

const PackageDetails = () => {
  return (
    <div className='package-details border-2 rounded-md p-2 shadow-sm'>
      <p className='font-bold mx-2 mb-1'>Package Details</p>
      <div className='package-items'>
        <Table>
          <tbody className='border-none'>
            <tr>
              <td className='!text-left'>
                <p className='mb-0'>Tshirt - AAP001</p>
                <p className='mb-0 text-xs'>Clothing</p>
              </td>
              <td className='!text-left'>
                <p className='mb-0'>₹180.00</p>
                <p className='mb-0 text-xs'>Tax@₹18.00 | 18%</p>
              </td>
              <td>1</td>
              <td>
                <p className='mb-0'>₹0.00</p>
                <p className='mb-0 text-xs'>0% off</p>
              </td>
            </tr>
            <tr>
              <td className='!text-left'>
                <p className='mb-0'>Tshirt - AAP001</p>
                <p className='mb-0 text-xs'>Clothing</p>
              </td>
              <td className='!text-left'>
                <p className='mb-0'>₹180.00</p>
                <p className='mb-0 text-xs'>Tax@₹18.00 | 18%</p>
              </td>
              <td>1</td>
              <td>
                <p className='mb-0'>₹0.00</p>
                <p className='mb-0 text-xs'>0% off</p>
              </td>
            </tr>
          </tbody>
        </Table>
      </div>
    </div>
  )
}

export default PackageDetails