import React, { useState } from 'react'
import './Trackshipment.css'
import trackshipmentImage from '../../../assets/images/create shipment.svg'
import searchImage from '../../../assets/images/ic_search.svg'
import Trackshipmentmodal from '../../../shared/Trackshipmentmodal'
import { OverlayTrigger, Tooltip } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'

const Trackshipment = () => {
    const [showModal, setShowModal] = useState(false);
    const navigate = useNavigate()

    const handleShow = () => setShowModal(true);
    const handleClose = () => setShowModal(false);

    const handleButtonClick = () => {
        navigate("/home/shipment")
    }


  return (
    <div className='track-shipment grid grid-cols-2 gap-2'>
        <div className='manifest'>
            <button onClick={handleButtonClick} title='Manifest Now' className="bg-pink-600 text-sm text-white w-full font-semibold py-2 justify-center border border-pink-600 rounded flex items-center">
                <img className="manifest-img h-4 w-4 mr-2" src={trackshipmentImage} alt="Manifest" />
                <p className='manifest-dash items-center m-0'>Manifest</p>
            </button>
        {/* </OverlayTrigger> */}
        </div>
        <div className='track'>
            <button title="Track your Order" onClick={handleShow} className="bg-white text-sm hover:bg-gray-100 w-full text-black font-semibold py-2 justify-center border border-gray rounded flex items-center">
                <img className="manifest-img h-4 w-4 mr-2" src={searchImage} alt="TrackSearch" />
                <p className='track-dash m-0'>Track Order</p>
            </button>
            <Trackshipmentmodal showModal={showModal} handleClose={handleClose} />
        </div>
    </div>
  )
}

export default Trackshipment