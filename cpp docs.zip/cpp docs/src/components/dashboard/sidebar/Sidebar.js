import React, { useState } from "react";
import './sidebar.css'
import eElementImage from '../../../assets/images/E elements.svg';
import TechnicalImage from '../../../assets/images/sidebar/Technical.svg'
import ShipmentImage from '../../../assets/images/sidebar/Shipment.svg'
import DashboardImage from '../../../assets/images/sidebar/Dashboard.svg'
import RightarrowImage from '../../../assets/images/sidebar/ic_arrow_forward.svg'


const Sidebar = () => {

  const [selectedIcon, setSelectedIcon] = useState(null);


  // Icons array for easier mapping
  const icons = [
    { id: 'ecom-logo', src: eElementImage, alt: 'ecom-logo' },
    { id: 'arrow', src: RightarrowImage, alt: 'arrow' },
    { id: 'dashboard', src: DashboardImage, alt: 'dashboard' },
    { id: 'shipment', src: ShipmentImage, alt: 'shipment' },
    { id: 'tech', src: TechnicalImage, alt: 'tech' },
  ];


  return (
    <div className="sidebar">
      <ul>
        {icons.map(icon => (
          <li key={icon.id}>
            <img
              className={`icon-logo ${selectedIcon === icon.id ? 'highlight' : ''}`}
              src={icon.src}
              alt={icon.alt}
              onClick={() => setSelectedIcon(icon.id)} // Update selected icon on click
            />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;
