import React from 'react'
import './Wallet.css'
import walletImage from '../../../assets/images/wallet.svg'

const Wallet = (props) => {

    const dashboardWallet = (
        <div className='wallet-container flex justify-between'>
            <div className='icon-balance flex'>
                <div className='wallet-icon'>
                    <img className='' src={walletImage} alt='wallet'/>
                </div>
                <div className='balance'>
                    <div className='balance-header text-sm text-white'>
                        Balance
                    </div>
                    <div className='amount text-xl font-bold text-white'>
                        ₹ 0
                    </div>

                </div>
            </div>
            <div className='recharge-button'>
                <button className="bg-transparent text-sm hover:bg-gray-100 text-white font-semibold py-2 px-2 mx-2 border border-white rounded">
                    Recharge
                </button>
            </div>
        </div>
    )

    const settingWallet = (
        <div className='setting-wallet-container flex justify-between'>
            <div className='icon-balance flex align-items-center'>
                <img className='mx-2' src={walletImage} alt='wallet'/>
                <div className='balance-header text-xs text-white'>
                    Balance:
                </div>
                <div className='amount text-sm text-white ml-2'>
                    ₹53,000,45
                </div>
            </div>
            <div className='recharge-button ml-4'>
                <button className="bg-transparent text-sm hover:bg-gray-100 text-white font-semibold py-2 px-2 mx-2 border border-white rounded">
                    Recharge
                </button>
            </div>
        </div>
    )

    return props.isDashboard ? dashboardWallet : settingWallet;

}

export default Wallet