import React from 'react'
import "./Shimmer.css";

const Shimmer = () => {
  return (
    <div className="shimmer-container">
    <div className="shimmer-wrapper my-2 p-2">
        <div className="shimmer-action rounded-lg mb-2"></div>
        <div className="flex gap-3">
            <div>
                <div className="flex gap-3 mb-2">
                    <div className="shimmer-cards rounded-lg"></div>
                    <div className="shimmer-cards rounded-lg"></div>
                    <div className="shimmer-cards rounded-lg"></div>
                </div>
                <div className="shimmer-cod rounded-lg"></div>
            </div>
            <div className="shimmer-shipper rounded-lg"></div>
        </div>
    </div>

    <div className="shimmer-2 my-2 py-2">
        <div className="shimmer-wallet mb-2 rounded-lg"></div>
        <div className="flex gap-2 mb-2">
            <div className="shimmer-manifest rounded-lg"></div>
            <div className="shimmer-manifest rounded-lg"></div>
        </div>
        <div className="shimmer-noti rounded-lg"></div>
    </div>
</div>

  )
}

export default Shimmer