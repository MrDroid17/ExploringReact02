import React from 'react'
import './Statuscards.css'
import Card from 'react-bootstrap/Card';
import { useNavigate } from 'react-router-dom';


const Statuscards = ({header, data}) => {

  const navigate = useNavigate()

  let displayData = ''
  let queryId = ''

  if (header === 'Manifest'){
    displayData = data.manifest
    queryId = 71
  }else if (header === 'Delivered'){
    displayData = data.delivered
    queryId = 74
  }else{
    displayData = data.remittance
    queryId = ''
  }

  const handleButtonClick = () => {
    navigate(`/home/generic-list/${header}`); // Navigate to the desired route
  };

  return (
    <div className='Statuscards w-full'>
        <Card onClick={handleButtonClick} className='!rounded-none shadow-sm border-none w-full cursor-pointer'>
          <Card.Body>
            <Card.Text className='text-gray-500'>{header}</Card.Text>
            <Card.Text className='text-xl'> {displayData} </Card.Text>
          </Card.Body>
        </Card>
    </div>
  )
}

export default Statuscards