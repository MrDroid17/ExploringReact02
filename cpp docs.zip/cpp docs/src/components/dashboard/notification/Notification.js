import React, { useEffect, useState } from 'react'
import './notification.css'
import eElementImage from '../../../assets/images/E elements.svg';
import { Card, Image, ListGroup, ListGroupItem } from 'react-bootstrap';
import { ApiUrl } from '../../../shared/apiUrl';
import useHttps from '../../../hooks/useHttps';

const Notification = () => {

  const { getRequest } = useHttps();
  const [notificationsData, setNotificationsData] = useState([])

  const fetchData = async () => { 
    try {
      const response = await getRequest(
        `${ApiUrl.NOTIFICATIONS}`);
      setNotificationsData(response.results)
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    fetchData()
  },[])


  return (
      <Card className="noti-card"> {/* Fixed card width and height */}
        <Card.Body className="shadow-sm h-full">
          <Card.Title className="text-lg font-bold mb-3">Notification</Card.Title>
          <ListGroup
            variant="flush"
            className="overflow-y-auto overflow-x-auto border-t border-gray-200"
          > {/* Enable vertical scrolling and hide horizontal overflow */}
            <ListGroupItem className="notification-data d-flex p-0">
              <ul className="block !pl-0 w-[100%] noti-list">
                {notificationsData.map((notification, key) => (
                  <li
                    className="flex py-3 border-b border-gray-200 w-full"
                    key={key}
                  >
                    {/* Notification Image */}
                    <Image
                      src={eElementImage}
                      className="notification-logo border-black mr-3 flex-shrink-0"
                      alt="notification-logo"
                    />

                    {/* Notification Text */}
                    <div className="font-medium text-md break-words">
                      {notification.title}
                    </div>
                  </li>
                ))}
              </ul>
            </ListGroupItem>
          </ListGroup>
        </Card.Body>
      </Card>
  )
}

export default Notification