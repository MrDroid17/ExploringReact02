import React, { useEffect, useState } from 'react'
import './body.css'
import Badge from 'react-bootstrap/Badge';
import { Button, Col, Container, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import useHttps from '../../../hooks/useHttps';
import { ApiUrl } from '../../../shared/apiUrl';
import Carousel from 'react-bootstrap/Carousel';
// import ExampleCarouselImage from 'components/ExampleCarouselImage';


const Body = ({header , data}) => {

    const navigate = useNavigate()
    const { getRequest } = useHttps();
    const [bannerData, setBannerData] = useState([])
    

    const bannerActions = {
      'Manifest Now' : '/home/shipment',
      'Start Shipping' : '',
      'View Now' : ''
    }



    const handleBannerClick = (banner) => {
        // navigate(bannerActions[banner])
        console.log(bannerActions[banner])
    }

    const handleBannerImage = async () => {
      try {
        const response = await getRequest(
          `${ApiUrl.BANNER}`);
        setBannerData(response.results)
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    }

    useEffect(() => {
        handleBannerImage()
    },[])

    if (header != 'Action Required'){
        return (
            <div className='action-required'>
                {/* <div className="background-container">
                    <div className="">
                        <div className='overlay-content'>
                            <h3>Congrats</h3>
                            <p>Your account is activated, You are all set to Manifest</p>
                        </div>
                        <Button onClick={() => handleManifestClick()} className='overlay-content-btn' variant="light">Manifest</Button>
                    </div>
                </div> */}

              <div>
              <Carousel indicators={false} className="w-full">
                {bannerData.map((banner, index) => (
                  <Carousel.Item key={index}>
                    {/* Dynamic Background Container */}
                    <div
                      className="background-container"
                      style={{
                        backgroundImage: `url(${banner.url})`, // Use banner.url for dynamic background
                      }}
                    ></div>

                    {/* Caption Content */}
                    <Carousel.Caption className='top-[7%]'>
                      <h4 className="text-left mb-0">{banner.title}</h4>
                      <div className='flex justify-between gap-2'>
                        <p className='text-left text-sm mb-0 content-center'>{banner.content}</p>
                        <Button className="!py-1 !text-xs" variant="light" onClick={() => handleBannerClick(banner.name)}>{banner.name}</Button>
                      </div>
                    </Carousel.Caption>
                  </Carousel.Item>
                ))}
              </Carousel>

              </div>
                
                <div>
                  {/* <Carousel className=''>
                    <Carousel.Item>
                      <ExampleCarouselImage text="First slide" />
                      <div className='background-container'></div>
                      <Carousel.Caption>
                        <h3 className='text-black'>First slide label</h3>
                        <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                      </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item>
                      <ExampleCarouselImage text="Second slide" />
                      <Carousel.Caption>
                        <h3>Second slide label</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                      </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item>
                      <ExampleCarouselImage text="Third slide" />
                      <Carousel.Caption>
                        <h3>Third slide label</h3>
                        <p>
                          Praesent commodo cursus magna, vel scelerisque nisl consectetur.
                        </p>
                      </Carousel.Caption>
                    </Carousel.Item>
                  </Carousel> */}
                </div>
            </div>
        )
    }

    const handleButtonClick = (screen) => {
        navigate(`/home/generic-list/${screen}`); // Navigate to the desired route
      };

  return (
    <div className='action-body'>
        <div className='body-header'>{header}</div>
        <Container>
            <Row className='g-3'>
                <Col className='text-center text-sm text-gray-500'>Bad Address
                    <Col className='box-content'>{data.bad_address}</Col>
                    <Badge className="activate" onClick={() => handleButtonClick('Bad Address')} pill bg='success'>Activate Now</Badge>
                </Col>
                <Col className='text-center text-sm text-gray-500'>Exceptions
                    <Col className='box-content'>{data.exceptions}</Col>
                    <Badge onClick={() => handleButtonClick('Exceptions')} pill>Act Now</Badge>
                </Col>
                <Col className='text-center text-sm text-gray-500'>To be Picked
                    <Col className='box-content'>{data.to_be_picked}</Col>
                    <Badge className={data.to_be_picked <= 0 ? "disabled-badge" : ""} onClick={() => handleButtonClick('To be Picked')} pill>Act Now</Badge>
                </Col>
                <Col className='text-center text-sm text-gray-500'>Pickup Failed
                    <Col className='box-content'>{data.pickup_failed}</Col>
                    <Badge className={data.pickup_failed <= 0 ? "disabled-badge" : ""} onClick={() => handleButtonClick('Pickup Failed')} pill>Act Now</Badge>
                </Col>
                <Col className='text-center text-sm text-gray-500'>NDR
                    <Col className='box-content'>{data.ndr}</Col>
                    <Badge className={data.ndr <= 0 ? "disabled-badge" : ""} onClick={() => handleButtonClick('NDR')} pill>Act Now</Badge>
                </Col>
            </Row>
        </Container>
    </div>
    
  )
}

export default Body