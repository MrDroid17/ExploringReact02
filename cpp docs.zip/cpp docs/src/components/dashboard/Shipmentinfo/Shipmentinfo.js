import React from 'react'
import './Shipmentinfo.css'
import { Col, Row } from 'react-bootstrap';
import shimpmentImage from '../../../assets/images/lineicons_delivery 1.svg'
import origin from '../../../assets/images/mdi_location-origin.svg'
import destination from '../../../assets/images/mdi_location-destination.svg'
import { useNavigate } from 'react-router-dom';


const Shipmentinfo = ({data}) => {

  const navigate = useNavigate()

  const handleClick = (endp) => {
    console.log(endp)
    navigate(`/home/generic-list/${endp}/`);
  }

  return (
    <div className='Shipmentinfo'>
        <div className='Shipmentinfo-header'>Shipments in Network</div>
        <div className='shipment-img'>
          <img src={origin} />
          <img src={shimpmentImage} />
          <img src={destination} />
        </div>
        <div className='dotted-line'></div>
        <Row className="container-fluid">

            <Col className='list1 col-md-6 col-12'>
              <li className="d-flex justify-content-between" onClick={() => handleClick('Forward Pickup')}>
                <span className='cursor-pointer'>Forward Pick-up</span>
                <span className='cursor-pointer'>{data.forward_pickup}</span>
              </li>
              <li className="d-flex justify-content-between" onClick={() => handleClick('Reverse Pickup')}>
                <span className='cursor-pointer'>Reverse Pick-up</span>
                <span className='cursor-pointer'>{data.reverse_pickup}</span>
              </li>
              <li className="d-flex justify-content-between" onClick={() => handleClick('In-Transit')}>
                <span className='cursor-pointer'>In-Transit</span>
                <span className='cursor-pointer'>{data.in_transit}</span>
              </li>
            </Col>

            <Col className='list2 col-md-6 col-12'>
              <li className="d-flex justify-content-between" onClick={() => handleClick('Out for Delivery')}>
                <span className='cursor-pointer'>Out for Delivery</span>
                <span className='cursor-pointer'>{data.ofd}</span>
              </li>
              <li className="d-flex justify-content-between cursor-pointer" onClick={() => handleClick('NDR')}>
                <span className='cursor-pointer'>NDR</span>
                <span className='cursor-pointer'>{data.ndr}</span>
              </li>
              <li className="d-flex justify-content-between" onClick={() => handleClick('RTO')}>
                <span className='cursor-pointer'>RTO</span>
                <span className='cursor-pointer'>{data.rto}</span>
              </li>

            </Col>
        </Row>
    </div>
  )
}

export default Shipmentinfo