import React from 'react'
import './Codshipment.css'
import DoughnutChart from '../../../shared/DoughnutChart'
import { useNavigate } from 'react-router-dom'

const Codshipment = ({data}) => {

  const navigate = useNavigate()


  const handleClick = (endp) => {
    console.log(endp)
    navigate(`/home/generic-list/${endp}/`);
  }


  return (
    <div className='Codshipment'>
        <div className='Codshipment-header'>COD Shipments</div>
        <div className="cod-container">
            <div className='chart'>
              <DoughnutChart dashData={data}/>
            </div>
            <ul>

              <li className='flex justify-between cursor-pointer' onClick={() => handleClick('Collected')}>
                <div>Collected</div>
                <div>₹{data.cod_collected_amount}</div>
              </li>

              <li className='flex justify-between cursor-pointer' onClick={() => handleClick('Out for Delivery')}>
                <div>Out for Delivery</div>
                <div>₹{data.cod_ofd_amount}</div>
              </li>

              <li className='flex justify-between cursor-pointer' onClick={() => handleClick('Undelivered')}>
                <div>Undelivered</div>
                <div>₹{data.cod_undelivered_amount}</div>
              </li>

            </ul>
        </div>
    </div>
  )
}

export default Codshipment