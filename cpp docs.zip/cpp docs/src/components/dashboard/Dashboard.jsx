import React, { useEffect, useState } from "react";
import Body from "./body/Body";
import Statuscards from "./Statuscards/Statuscards";
import Shipmentinfo from "./Shipmentinfo/Shipmentinfo";
import Codshipment from "./Codshipment/Codshipment";
import Notification from "./notification/Notification";
import Wallet from './wallet/Wallet';
import Trackshipment from './trackshipment/Trackshipment';
import "./Dashboard.css";
import { ApiUrl } from "../../shared/apiUrl";
import useHttp from '../../hooks/useHttps';
import Shimmer from "./Shimmer";
import { toast } from "react-toastify";


const Tooltip = ({ children }) => {
    return (
      <div className="tooltip">
        {children}
      </div>
    );
  };

const Dashboard = ()=>{

  const { getRequest } = useHttp();
  const [dashData, setdashData] = useState(null)

  const dashboardData = async()=>{
    try{
        const resp = await getRequest(ApiUrl.DASHBOARD);
        // if (resp){
          setdashData(resp.data)
        // }
        console.log(resp)
    }catch(error){
        console.error('Error fetching data:', error);
    }
  }

  useEffect(() => {
    dashboardData()
  }, [])


    return (

      dashData === null ? <Shimmer /> : ( <>
            <div className="body-cards">
                <div className="body-content">
                    <Body header={''} />
                </div>
                <div className="body-content">
                    <Body header={'Action Required'} data={dashData} />
                </div>
                <div className="shipment-cod-container">
                    <div className="status-shipment">
                        <div className="status ml-4 mt-2">
                            <div className="cards">
                                <Statuscards header={'Manifest'} data={dashData} />
                            </div>
                            <div className="cards p-0">
                                <Statuscards header={'Delivered'} data={dashData} />
                            </div>
                            <div className="cards">
                                <Statuscards header={'Remittance'} data={dashData} />
                            </div>
                        </div>
                        <div className="body-shipment">
                            <Shipmentinfo data={dashData} />
                        </div>
                    </div>
                    <div className="body-cod">
                        <Codshipment data={dashData} />
                    </div>
                </div>
            </div>
            <div className="notification-content">
                <Wallet isDashboard={true}/>
                <div className="highlighted-trackshipment">
                    {dashData.bad_address === 0 && (
                    <Tooltip>
                        <Trackshipment />
                        <span className="tooltip-text">You do not have any shipments to track, Please manifest first.</span>
                    </Tooltip>
                    )}
                    {dashData.bad_address !== 0 && (
                    <Trackshipment />
                    )}
                </div>
                <Notification />
            </div>
        </>)
        
    )
}

export default Dashboard;