import React, { useEffect, useState } from "react";
import { Form, Button } from "react-bootstrap";
import { VscInfo, VscAdd } from "react-icons/vsc";
import { BsPencil, BsSearch } from "react-icons/bs";
import AddAddressModal from "../AddAddressModal/AddAddressModal";
import "./AddressDetailsCard.css";
import useHttp from '../../../hooks/useHttps';
import { ApiUrl } from "../../../shared/apiUrl";
import { Typeahead } from "react-bootstrap-typeahead";


const AddressDetailsCard = (props) => {
  const { getRequest }  = useHttp();
  const [showPickupAddress, setPickupAddressModal] = useState(false);
  const [showReturnAddress, setReturnAddressModal] = useState(false);
  const [shipperList, setShipperList] = useState([]);
  const [pickUpAddressData, setPickupAddressData] = useState(null); // Store pickup address data
  const [returnAddressData, setReturnAddressData] = useState(null); // Store return address data
  const [singleSelections, setSingleSelections] = useState([]);
  const [isBillingSame, setIsBilling] = useState(false);
  const [isOtpRequired, setIsOtpRequired]=useState(false);



  useEffect(() => {
    getShipperList();
  }, []);

  const getShipperList = async () => {
    const resp = await getRequest(ApiUrl.PICKUP_ADDRESS);
    if(resp && resp.results && resp.results.length){
      setShipperList(resp.results);
    }
  };


  const handlePickupFormData = (data) => {
    setPickupAddressData(data); // Store pickup address data
    props.handleAddressData({ type: 'pickup', data: data });
    setPickupAddressModal(false); // Close the modal
    getShipperList();
  };

  const handleReturnFormData = (data) => {
    setReturnAddressData(data); // Store return address data
    props.handleAddressData({ type: 'return', data: data });
    setReturnAddressModal(false); // Close the modal
  };

  const selectShipperAddress = (event)=>{
    setSingleSelections(event);
    if(event.length){
      const data = event[0];
      handlePickupFormData({
        city: data.city,
        contactPerson: data.contact_person_name,
        fName: data.name,
        facilityName: data.facility_name,
        landmark: data.landmark,
        phoneNumber: data.phone_number,
        pincode: data.pincode,
        shippingLine: data.address_line_1,
        state: data.state,
        subShipper: data.name
      });
    }
  }

  // const filterBy = () => true;


  return (
    <div className="address-details-card block-border m-2 shadow-sm">
      <p className="font-bold d-flex align-items-center">
        {props.title} <VscInfo className="label-icon" />
      </p>

      {/* Sub-Shipper Section */}
      <div className="row">
        <div className="col-12">
          <Form.Label htmlFor="inputSubshipper" className="text-sm-dark d-flex align-items-center">
            Sub-Shipper <VscInfo className="label-icon" />
          </Form.Label>
          <div className="search-input-container">
            <div className="search-input">
              <BsSearch className="search-icon" />

              <Typeahead
                  // filterBy={filterBy}
                  id="inputSubshipper"
                  labelKey="name"
                  onChange={selectShipperAddress}
                  options={shipperList}
                  placeholder="Search"
                  className="search-with-button w-100"
                  selected={singleSelections}
                  required
                />
              {/* <Form.Control
                type="text"
                id="inputSubshipper"
                aria-describedby="inputHelpSubShipper"
                className="search-with-button"
                placeholder="Search"
                required
              /> */}
            </div>
            <Button
              variant="light"
              size="sm"
              className="add-store-btn shadow-sm"
              onClick={() => setPickupAddressModal(true)}
            >
              + Sub-Shipper
            </Button>
          </div>
        </div>
      </div>

      {/* Address Sections */}
      <div className="row addresses flex my-2">
        {/* Pickup Address Section */}
        <AddressSection
          addressData={pickUpAddressData}
          addressType="pickup"
          title="Pickup Address"
          handleFormData={handlePickupFormData}
          showModal={showPickupAddress}
          setShowModal={setPickupAddressModal}
        />

        {/* Return Address Section */}
        <AddressSection
          addressData={returnAddressData}
          addressType="return"
          title="Delivery Address"
          handleFormData={handleReturnFormData}
          showModal={showReturnAddress}
          setShowModal={setReturnAddressModal}
        />
      </div>

      {/* Billing and OTP verification checkbox */}
      <div className="d-flex justify-content-between align-items-center">
        <div className="billing-address-checkbox">
          <Form.Check
            type="checkbox"
            id="billing-checkbox"
            label="Billing address is same as shipping address"
            value={isBillingSame}
            onChange={(e)=> {
              setIsBilling(e.target.checked)
            }}
          />
        </div>
        <div className="otp-verified-checkbox">
          <Form.Check
            type="checkbox"
            id="otp-checkbox"
            label="OTP verified Delivery"
            value={isOtpRequired}
            onChange={(e)=> {
              setIsOtpRequired(e.target.checked)
            }}
          />
        </div>
      </div>
    </div>
  );
};


const AddressSection = ({
  addressData,
  addressType,
  title,
  handleFormData,
  showModal,
  setShowModal
}) => {
  const handleOpenModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);

  return (
    <div className="col-lg-6 col-md-12 col-sm-12">
      <Form.Label htmlFor={`input${addressType}`} className="text-sm-dark d-flex align-items-center">
        {title}
      </Form.Label>
      <div className="block-border">
        <AddressLoading data={addressData} />
      
        <div className="new-address-btn-container">
          <span className="new-address-btn" onClick={handleOpenModal}>
            {
              addressData ? <BsPencil /> :
              <VscAdd />
            }
          </span>

          {showModal && (
            <AddAddressModal
              showModal={showModal}
              handleClose={handleCloseModal}
              handleFormData={handleFormData}
              addressType={addressType}
              title={`Add ${title} Details`}
            />
          )}
        </div>
      </div>
    </div>
  );
};

// AddressLoading Component
const AddressLoading = ({ data }) => {
  const classes = data ? 'address' : 'skeleton-line';
  const boldAddress = data ? `font-bold` : '';
  return (
    <div className="full-address">
      <p className={`${classes} ${boldAddress}`}>{data?.fName} {data?.lName}</p>
      <p className={classes}>{data?.shippingLine}</p>
      <p className={classes}>
        {data && (
          <>
            {data.city} , {data.state} - {data.pincode}
          </>
        )}
      </p>
    </div>
  );
};

export default AddressDetailsCard;
