import React, { useEffect, useRef, useState } from 'react';
import './AddAddressModal.css';
import { Form, InputGroup, Button, Modal, Card } from 'react-bootstrap';
import useHttps from '../../../hooks/useHttps';
import { ApiUrl } from '../../../shared/apiUrl';
import { useToast } from '../../../context/ToastContext';

const AddAddressModal = ({ addressData, showModal, handleClose, handleFormData, addressType, title }) => {
    const [validated, setValidated] = useState(false);
    const [addressId, setAddressid] = useState((addressData && addressData.id) || "");
    const formRef = useRef(null) //Using ref for form
    const { getRequest, postRequest, putRequest } = useHttps();
    const { showSuccess, showError } = useToast();

    // State to hold form values
    const [formData, setFormData] = useState({
        subShipper: (addressData && addressData.name) || '',
        facilityName: (addressData && addressData.facility_name) || '',
        phoneNumber: (addressData && addressData.phone_number) || '',
        contactPerson: (addressData && addressData.contact_person_name) || '',
        email: (addressData && addressData.email) || '',
        shippingLine: (addressData && addressData.address_line_1) || '',
        landmark: (addressData && addressData.landmark) || '',
        pincode: (addressData && addressData.pincode) || '',
        state: (addressData && addressData.state) || '',
        city: (addressData && addressData.city) || '',
        fName: (addressData && addressData.fname) || '',
        lName: (addressData && addressData.lname) || ''
    });

    const handleAddAlternateAddress = (event) => {
        event.preventDefault(); // Prevent default anchor behavior
        console.log("Add Alternate Address Line clicked");
    };

    // Handle change for form inputs
    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [id]: value
        }));
    };

    const getCityAndState = async () => {
        if (formData.pincode) {
            const response = await getRequest(`${ApiUrl.PINCODE}?pincode=${formData.pincode}`);
            if (response && response.data && response.data.length) {
                setFormData((prevData) => ({
                    ...prevData,
                    state: response.data[0].State,
                    city: response.data[0].city_name,
                }))
            };
        }
    }

    const handleSubmit = (event) => {

        event.preventDefault(); // Prevent parent form submission
        const form = formRef.current;

        // Check if form is valid
        if (form.checkValidity() === false) {
            event.stopPropagation(); // Stop submission if invalid
        }

        setValidated(true);

        if (form.checkValidity()) {
            if (addressType === 'pickup') {
                addPickupAddress(formData)
            } else {
                addDeliveryAdd(formData);
            }
        }
    };

    const addPickupAddress = async (formData) => {
        console.log('Form Submitted with data for pickup address:', formData);
        const reqBody = {
            "name": formData.subShipper,
            "facility_name": formData.facilityName,
            "phone_number": +formData.phoneNumber,
            "contact_person_name": formData.contactPerson,
            "address_line_1": formData.shippingLine,
            "landmark": formData.landmark,
            "pincode": +formData.pincode,
            "state": formData.state,
            "city": formData.city,
        }
        addAddress(formData, reqBody, ApiUrl.PICKUP_ADDRESS);

    }

    const addDeliveryAdd = async (formData) => {
        console.log('Form Submitted with data for delivert address:', formData);
        const reqBody = {
            "first_name": formData.fName,
            "last_name": formData.lName,
            "phone_number": +formData.phoneNumber,
            "alternate_phone_number": +formData.phoneNumber,
            "email": formData.email,
            "address_line_1": formData.shippingLine,
            "address_line_2": formData.shippingLine,
            "landmark": formData.landmark,
            "pincode": +formData.pincode,
            "state": formData.state,
            "city": formData.city,
        }
        addAddress(formData, reqBody, ApiUrl.DELIVERY_ADDRESS);
    }

    const addAddress = async (formData, reqBody, apiUrl) => {

        if (addressId) {
            // Api for updating address
            const res = await putRequest(apiUrl + addressId + "/", reqBody);
            if (res && res.message) {
                showSuccess({ detail: res.message });
                handleFormData(formData);
            }
        } else {
            const res = await postRequest(apiUrl, reqBody);
            if (res && res.message) {
                showSuccess({ detail: res.message });
                handleFormData(formData);
            }
        }
    }

    return (
        <div className="add-address-modal">
            {showModal && (
                <Modal show={showModal} onHide={handleClose} size="lg" backdrop="static">
                    <Form noValidate validated={validated} ref={formRef}>
                        <Modal.Header>
                            <Modal.Title className="text-sm-dark">{title}</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            {addressType === 'pickup' && (
                                <div className="row">
                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                        <Form.Label htmlFor="subShipper" className="text-sm-dark">
                                            Sub-Shipper Name
                                        </Form.Label>
                                        <Form.Control
                                            type="text"
                                            id="subShipper"
                                            value={formData.subShipper}
                                            onChange={handleChange}
                                            required={addressType === 'pickup'}
                                            isValid={formData.subShipper.length > 0} // Bootstrap validation styling
                                        />
                                    </div>
                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                        <Form.Label htmlFor="facilityName" className="text-sm-dark">
                                            Facility Name
                                        </Form.Label>
                                        <Form.Control
                                            type="text"
                                            id="facilityName"
                                            value={formData.facilityName}
                                            onChange={handleChange}
                                            required={addressType === 'pickup'}
                                            isValid={formData.facilityName.length > 0} // Bootstrap validation styling
                                        />
                                    </div>
                                </div>
                            )}

                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12">
                                    <Form.Label htmlFor="phoneNumber" className="text-sm-dark">
                                        Phone Number
                                    </Form.Label>
                                    <InputGroup className="mb-3">
                                        <InputGroup.Text id="phoneNumber">+91</InputGroup.Text>
                                        <Form.Control
                                            id="phoneNumber"
                                            value={formData.phoneNumber}
                                            onChange={handleChange}
                                            aria-describedby="phone_numbers"
                                            required
                                            isValid={formData.phoneNumber.length > 0} // Bootstrap validation styling
                                        />
                                    </InputGroup>
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12">
                                    {addressType === 'pickup' ? (
                                        <>
                                            <Form.Label htmlFor="contactPerson" className="text-sm-dark d-flex justify-content-between align-items-center">
                                                Contact Person Name <small>Optional</small>
                                            </Form.Label>
                                            <Form.Control
                                                type="text"
                                                id="contactPerson"
                                                value={formData.contactPerson}
                                                onChange={handleChange}
                                            />
                                        </>
                                    ) : (
                                        <>
                                            <Form.Label htmlFor="email" className="text-sm-dark">
                                                Email
                                            </Form.Label>
                                            <Form.Control
                                                type="email"
                                                id="email"
                                                value={formData.email}
                                                onChange={handleChange}
                                                required={addressType === 'return'}
                                            />
                                        </>
                                    )}
                                </div>
                            </div>

                            <div className="address-magic-fill">
                                <Card>
                                    <Card.Header className="text-sm-dark">Magic Fill</Card.Header>
                                    <Card.Body>
                                        <div>
                                            <span muted>Paste Address for the Magic.</span>
                                        </div>
                                        <Button variant="outline-primary float-end">Fill</Button>
                                    </Card.Body>
                                </Card>
                            </div>

                            {addressType === 'return' && (
                                <div className="row">
                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                        <Form.Label htmlFor="fName" className="text-sm-dark">
                                            First Name
                                        </Form.Label>
                                        <Form.Control
                                            type="text"
                                            id="fName"
                                            value={formData.fName}
                                            onChange={handleChange}
                                            required={addressType === 'return'}
                                        />
                                    </div>
                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                        <Form.Label htmlFor="lName" className="text-sm-dark">
                                            Last Name
                                        </Form.Label>
                                        <Form.Control
                                            type="text"
                                            id="lName"
                                            value={formData.lName}
                                            onChange={handleChange}
                                            required={addressType === 'return'}
                                        />
                                    </div>
                                </div>
                            )}

                            <div className="row">
                                <div className="col-12">
                                    <Form.Label htmlFor="shippingLine" className="text-sm-dark">
                                        Shipping Address Line 1
                                    </Form.Label>
                                    <Form.Control
                                        type="text"
                                        id="shippingLine"
                                        value={formData.shippingLine}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                {addressType !== 'pickup' && (
                                    <div className="d-flex justify-content-end">
                                        <Form.Text id="shippingLine1">
                                            <a href="#" onClick={handleAddAlternateAddress}>Add Alternate Address Line</a>
                                        </Form.Text>
                                    </div>
                                )}
                            </div>

                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12">
                                    <Form.Label htmlFor="landmark" className="text-sm-dark">
                                        Land Mark
                                    </Form.Label>
                                    <Form.Control
                                        type="text"
                                        id="landmark"
                                        value={formData.landmark}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12">
                                    <Form.Label htmlFor="pincode" className="text-sm-dark">
                                        Pincode
                                    </Form.Label>
                                    <Form.Control
                                        type="text"
                                        id="pincode"
                                        value={formData.pincode}
                                        onBlur={getCityAndState}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12">
                                    <Form.Label htmlFor="state" className="text-sm-dark">
                                        State
                                    </Form.Label>
                                    <Form.Control
                                        type="text"
                                        id="state"
                                        value={formData.state}
                                        onChange={handleChange}
                                        disabled
                                        required
                                    />
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12">
                                    <Form.Label htmlFor="city" className="text-sm-dark">
                                        City
                                    </Form.Label>
                                    <Form.Control
                                        type="text"
                                        id="city"
                                        value={formData.city}
                                        onChange={handleChange}
                                        disabled
                                        required
                                    />
                                </div>
                            </div>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="light" onClick={handleClose} className="text-sm-dark">
                                Cancel
                            </Button>
                            <Button variant="primary" type="button" className="submit-btn text-sm-dark" onClick={handleSubmit}>
                                {title}

                            </Button>
                        </Modal.Footer>
                    </Form>
                </Modal>
            )}
        </div>
    );
};

export default AddAddressModal;
