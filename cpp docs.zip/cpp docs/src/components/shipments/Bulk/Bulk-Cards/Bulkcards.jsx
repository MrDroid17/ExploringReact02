import React from 'react'
import './Bulkcards.css'
import { Button } from 'react-bootstrap'
import { ApiUrl } from '../../../../shared/apiUrl';
import useHttps from '../../../../hooks/useHttps';
import { useToast } from '../../../../context/ToastContext';
import { downloadFile } from '../../../../utils/common';

const Bulkcards = (props) => {
    const { getRequest } = useHttps();
    const {showSuccess} = useToast();
    const header = props.header;

    const downloadSampleFile = async()=>{
      const fileRes = await getRequest(`${ApiUrl.DOWNLOAD_MANIFEST_SAMPLE_FILE}?shipment_type=${props.shipmentType}`);
      if(fileRes && fileRes.data){
          const fileName = fileRes.data.split('/').pop().split('?')[0];
          downloadFile(fileRes.data,fileName)
      }
  }

  return (
    <div className='bulk-cards my-2 p-2'>
        <p className='text-sm font-bold m-0'>{header}</p>
        <p className='text-xs'>Download template & Fill rows with order data</p>
        <div className='options space-x-1'>
            <Button className='w-[49%] !text-xs bg-white text-black !border-[#C5C7C9]'>Edit Optional Fields</Button>
            <Button className='w-[49%] !text-xs bg-white text-black !border-[#C5C7C9]' onClick={downloadSampleFile}>Download</Button>
        </div>
    </div>
  )
}

export default Bulkcards