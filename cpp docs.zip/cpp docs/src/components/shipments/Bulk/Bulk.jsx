import React, { useRef, useState } from 'react'
import './Bulk.css'
import { Button, Card, Form } from 'react-bootstrap'
import Bulkcards from './Bulk-Cards/Bulkcards';
import useHttps from '../../../hooks/useHttps';
import { useToast } from '../../../context/ToastContext';
import { ApiUrl } from '../../../shared/apiUrl';
import { decrpt } from '../../../utils/CryptoUtils';
import { BsCloudUpload, BsExclamationCircle } from 'react-icons/bs';
import { VscInfo } from 'react-icons/vsc';
import { BiDownload } from 'react-icons/bi';
import { downloadFile } from '../../../utils/common';
import { useLoader } from '../../../context/LoaderContext';

const Bulk = () => {
    const { postRequest } = useHttps();
    const {showLoader}  = useLoader();
    const { showSuccess, showError} = useToast();
    const [shipmentType, setShipmentType] = useState('RVP');
    const [uploadResponse, setUploadResponse] = useState({
            "bulk_task_id": null,
            "validated_url": "",
            "validated_count": null,
            "missing_required_url": "",
            "missing_required_count": null,
            "field_format_url": "",
            "field_format_count": null
    });
    const inputFileRef = useRef();
    const allowedFileExtensions = ['.xls','.xlsx'];

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const fileExtension = file.name.slice(file.name.lastIndexOf('.')).toLowerCase();
    
            if (!allowedFileExtensions.includes(fileExtension)) {
                showError({detail:'Invalid file type. Please upload a .xls or .xlsx file.'})
                return;
            }
    
            uploadFile(file);
        }
    };
    const uploadFile = async(file)=>{
        showLoader(true);
        let reqBody = new FormData();
        // reqBody.append('shipment_type',shipmentType);
        reqBody.append('manifest_upload_file', file);
        reqBody.append('activity_type','Bulk Manifest');
        const res = await postRequest(ApiUrl.BULK_MANIFEST_UPLOAD, reqBody);
        if(res){
            setUploadResponse(res);
            inputFileRef.current.value = '';
            showLoader(false);
        }
    }

    const handleManifestClick = async()=>{
        if(!uploadResponse.bulk_task_id) return;
        const formData = new FormData();
        // formData.append('shipment_type', shipmentType);
        formData.append('bulk_task_id', uploadResponse.bulk_task_id);
        const res = await postRequest(ApiUrl.BULK_MANIFEST_SUBMIT, formData);
        if(res){
            showSuccess({detail: res.message});
            setUploadResponse({
                    "bulk_task_id": null,
                    "validated_url": "",
                    "validated_count": null,
                    "missing_required_url": "",
                    "missing_required_count": null,
                    "field_format_url": "",
                    "field_format_count": null
            })
        }
    }

    const handleResponseFile = (filename)=>{
        const res_file = decrpt(uploadResponse.field_format_url);
        downloadFile(res_file,filename)
    }

    

  return (
    <div className='bulk flex mb-2 p-3'>
        {/* Upload file and summary of upload  */}
        <div className='basis-[65%] m-2'>
            {/* File Upload  */}
            <div className="block-border m-2 shadow-sm">
                <Form.Label htmlFor="channel" className='text-sm-dark d-flex align-items-center'>Upload CSV or Excel File<VscInfo className='label-icon' /></Form.Label>
            <div className='upload-container file-upload text-center m-2 block-border '>
                                <div className='justify-center'>
                                    <span className='product-image-upload-icon'><BsCloudUpload /></span>
                                    <Form.Group controlId="formFile">
                                        <Form.Label className="text-decoration-none">
                                            <span className='btn btn-link text-decoration-none'>Click to upload</span>
                                            <span>or drag and drop</span>
                                            <br />
                                            <span>CSV,XLX or XLXS</span>
                                            <Form.Control
                                                type="file"
                                                onChange={handleFileChange}
                                                style={{ display: 'none' }}
                                                accept='.xls,.xlsx'
                                                ref={inputFileRef}
                                            />
                                        </Form.Label>
                                    </Form.Group>
                                </div>
                            </div>
                <p className='text-[#6E7478] text-xs ml-2'>Using this tool you can upload single or multiple shipments via excel upload. You can download the sample excel format.</p>
            </div>
            {/* Summary of Uploads  */}
            {
                uploadResponse.bulk_task_id &&
                <div className='block-border m-2 shadow-sm  p-2 my-2'>
                    <p className='font-bold'>Uploaded file Summary</p>
                    <div className='file-cards grid grid-cols-3 gap-2'>
                        <Card>
                            <Card.Body className='text-center'>
                                <p className='text-xl d-flex justify-content-center align-items-center'>{uploadResponse.validated_count}</p>
                                <p className='text-xs m-0 d-flex justify-content-center align-items-center'>Uploaded Successfully <BsExclamationCircle className='ml-2'/></p>
                            </Card.Body>
                        </Card>
                        <Card>
                            <Card.Body className='text-center'>
                                <p className='text-xl m-0 d-flex justify-content-center align-items-center'>{uploadResponse.missing_required_count} <BiDownload className='m-2 cursor-pointer' onClick={()=>handleResponseFile('missing_field_error.xls')} title='download file'/>
                                </p>
                                <p className='text-xs m-0 d-flex justify-content-center align-items-center'>Missing Required Filed <BsExclamationCircle className='m-2'/></p>
                            </Card.Body>
                        </Card>
                        <Card>
                            <Card.Body className='text-center'>
                                <p className='text-xl m-0 d-flex justify-content-center align-items-center'>{uploadResponse.field_format_count} <BiDownload className='m-2 cursor-pointer' onClick={()=>handleResponseFile('field_format_error.xls')} title="download file"/>
                                </p>
                                <p className='text-xs m-0 d-flex justify-content-center align-items-center'>Field Format Error<BsExclamationCircle className='m-2'/></p>
                            </Card.Body>
                        </Card>
                    </div>
                </div>

            }


        </div>


        {/* Sample Download and Actions  */}
        <div className='basis-[35%]'>


            {/* Download Samples  */}
            <div className='sample download  p-2 m-2'>
                <p className='font-bold'>Download Sample File</p>
                <Bulkcards header={'Forward Shipment'} shipmentType='FWD'/>
                <Bulkcards header={'Reverse Shipment'} shipmentType='RVP'/>
                <Bulkcards header={'MPS Shipment-Forward'} shipmentType='MPS'/>
                <div className='instructions'>
                    <p className='font-bold'>Important Instructions</p>
                    <ol className="list-decimal pl-4">
                        <li className='text-xs text-gray-400 py-1'>You cannot change the sequence of columns in the sample file. Sequence has to be the same.</li>
                        <li className='text-xs text-gray-400 py-1'>Mandatory fields are followed by “*” in the sample file.</li>
                        <li className='text-xs text-gray-400 py-1'>When you upload a file, all valid records will be uploaded immediately into ECOM’s system. Invalid records will NOT.</li>
                    </ol>
                </div>
            </div>

            {/* Actions  */}
            <div className='buttons space-x-1 m-2'>
                <Button className='w-[49%] !text-xs bg-white text-black !border-[#C5C7C9]'
                disabled={!uploadResponse.bulk_task_id}>Create Orders</Button>
                <Button className='w-[49%] !text-xs !bg-[#E10F76] text-white !border-[#C5C7C9]' onClick={handleManifestClick}
                disabled={!uploadResponse.bulk_task_id}>Manifest Now</Button>
            </div>


        </div>
    </div>
  )
}

export default Bulk