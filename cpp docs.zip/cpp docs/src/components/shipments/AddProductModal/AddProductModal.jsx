// Modal.js
import React, { useEffect, useRef, useState } from 'react';
import './AddProductModal.css';
import { Form, InputGroup, Button, Modal, Card } from 'react-bootstrap';
import { BsCloudUpload, BsCurrencyRupee } from 'react-icons/bs';
import { VscInfo } from 'react-icons/vsc';
import { useForm } from 'react-hook-form';
import useHttps from '../../../hooks/useHttps';
import { useToast } from '../../../context/ToastContext';
import { ApiUrl } from '../../../shared/apiUrl';
import uploadIcon from "../../../assets/images/upload.svg";
import infoIcon from "../../../assets/images/info-small.svg";
import { AiOutlineDelete } from 'react-icons/ai';
import { SlPencil } from 'react-icons/sl';
import ConfirmationDialog from '../../../shared/ui/ConfirmationDialog';
import { Input } from 'postcss';


const AddProductModal = ({ productData, showModal, handleClose, handleSubmitForm, title }) => {
    const [file, setFile] = useState(null);
    const formRef = useRef(null) //Using ref for form
    const [validated, setValidated] = useState(false);
    const [productId, setProductId] = useState((productData && productData.id) || "");
    const [imageUrl, setImageUrl] = useState((productData && productData.image_url) || null);
    const [showDeleteDialog, setShowDeleteDialog] = useState(false);
    const [deleteData, setDeleteData] = useState({});
    const { register, handleSubmit, formState: { errors }, reset, clearErrors } = useForm({
        defaultValues: {
            "productName": (productData && productData.name) || '',
            "hsn_code": (productData && productData.hsn_code) || '',
            "category": (productData && productData.category) || '',
            "product_price": (productData && productData.price) || '',
            "taxType": (productData && productData.tax_type) || '',
            "discount": (productData && productData.discount) || '',
            "dangerousGoods": (productData && productData.is_dangerous_goods) || '',
            "essentialGoods": (productData && productData.is_essential_goods) || ''
            // "file": (productData && productData.image_url) || '',
        }
    });
    const { postRequest, putRequest } = useHttps();
    const { showSuccess } = useToast();

    useEffect(() => {
        if (showModal) {
            // Clear form state when modal is reopened
            resetForm();
        }
    }, [showModal]);

    const handleFileChange = async (e) => {
        const file = e.target.files[0];
        if(file){
                // Create a URL for the selected file to use as the image preview
                const imageUrl = URL.createObjectURL(file);
                setImageUrl(imageUrl); // Set the image preview state
                setFile(file);
        }
    };

    const onSubmit = (data) => {
        setValidated(true);
        const reqBody = {
            "name": data.productName,
            "hsn_code": data.hsn_code,
            "category": data.category,
            "price": data['product_price'],
            "tax_type": data.taxType,
            "discount": data.discount,
            "is_dangerous_goods": data.dangerousGoods,
            "is_essential_goods": data.essentialGoods,
            "product_images": file,
        }
        addProduct(reqBody);

    }

    const addProduct = async (reqBody) => {
        handleSubmitForm(reqBody);
        const req = new FormData();
        Object.entries(reqBody).forEach(([key, value]) => {
            req.append(key, value);
        });

        if (productId) {
            /**
             * If productId is there then update the product
             */
            const response = await putRequest(ApiUrl.PRODUCTS + productId + "/", req);
            if (response && response.message) {
                showSuccess({ detail: response.message });
                resetForm();
                handleSubmitForm(reqBody);
                handleClose();
                setImageUrl("");
            }
        } else {
            const response = await postRequest(ApiUrl.PRODUCTS, req);
            if (response && response.message) {
                showSuccess({ detail: response.message });
                resetForm();
                handleSubmitForm(reqBody);
                handleClose();
                setImageUrl("");
            }
        }

    }

    const resetForm = () => {
        if (formRef.current) {
            setValidated(false);
            setFile(null);
            reset(); // Reset form state
            clearErrors();
        }
    }

    const deleteButtonHandler = (data) => {
        setShowDeleteDialog(true);
        setDeleteData(data);
    }

    const onDeleteConfirmationCancel = () => {
        setShowDeleteDialog(false);
        setDeleteData({});
    }

    const onDeleteConfirmation = (data) => {
        setShowDeleteDialog(false);
        deleteProductImage(data);
    }

    const deleteProductImage = (data) => {
        console.log("Deleted Image====>")
        setImageUrl(null);
    }

    const updateProductImage = () => {

    }


    return (
        <div className='add-address-modal'>
            <Modal show={showModal} onHide={handleClose} size='lg' backdrop="static">
                <Form noValidate validated={validated} ref={formRef}>
                    <Modal.Header >
                        <Modal.Title className='text-sm-dark'>{title} Details</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>

                        <div className='address-magic-fill mb-2'>
                            <Card>
                                <Card.Header className='text-sm-dark'>Magic Fill</Card.Header>
                                <Card.Body>
                                    <div>
                                        <span muted>
                                            Paste Address for the Magic.

                                        </span>
                                    </div>
                                    <Button variant="outline-primary float-end">Fill</Button>
                                </Card.Body>
                            </Card>
                        </div>

                        <div className='row mb-2'>
                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                <Form.Label htmlFor="productName" className='text-sm-dark'>Product Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    id="productName"
                                    {...register("productName", { required: true })}
                                    isInvalid={errors.productName?.type === 'required'}
                                    placeholder='Enter Item Name'
                                />
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                <Form.Label htmlFor="hsn" className='text-sm-dark'>HSN Code</Form.Label>
                                <Form.Control
                                    type="number"
                                    id="hsn"
                                    placeholder='Enter HSN Code'
                                    {...register("hsn_code", { required: true })}
                                    isInvalid={errors.hsn_code?.type === 'required'}
                                />

                            </div>
                        </div>

                        <div className='row mb-2'>
                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                <Form.Label htmlFor="category" className='text-sm-dark'>Category</Form.Label>
                                <Form.Control
                                    type="text"
                                    id="category"
                                    placeholder='For Example, Electronics, Cloth etc'
                                    {...register("category", { required: true })}
                                    isInvalid={errors.category?.type === 'required'}

                                />

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                <Form.Label htmlFor="product-price" className='text-sm-dark'>Price</Form.Label>
                                <InputGroup id='product-price'>
                                    <InputGroup.Text id="rupee-icon"><BsCurrencyRupee /></InputGroup.Text>
                                    <Form.Control
                                        placeholder="Enter Price"
                                        type="number"
                                        id="price"
                                        {...register("product_price", { required: true })}
                                        isInvalid={errors['product_price']?.type === 'required'}


                                    />
                                </InputGroup>
                            </div>
                        </div>



                        <div className='row mb-2'>
                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                <div className='col-12'>
                                    <Form.Label htmlFor="taxType" className='text-sm-dark'>Tax Type</Form.Label>
                                    <Form.Select id='taxType' {...register("taxType", { required: true })}
                                        isInvalid={errors.taxType?.type === 'required'}
                                    >
                                        <option disabled>Open this select menu</option>
                                        <option value="GST">GST</option>
                                        <option value="VAT">VAT</option>
                                        <option value="CST">CST</option>
                                    </Form.Select>
                                </div>
                                <div className='col-12 mt-2'>
                                    <Form.Label htmlFor="discount" className='text-sm-dark'>Discount</Form.Label>
                                    <Form.Control
                                        type="number"
                                        id="discount"
                                        placeholder='Enter Discount'
                                        {...register("discount", { required: true })}
                                        isInvalid={errors.discount?.type === 'required'}

                                    />




                                </div>
                                <div className='col-12 d-flex mt-3'>
                                    <div className='col-6'>
                                        <Form.Check // prettier-ignore
                                            type='checkbox'
                                            id='essentialGoods'
                                            label='Essential Goods'
                                            {...register("essentialGoods", { required: false })}

                                        />
                                    </div>
                                    <div className='col-6'>
                                        <Form.Check // prettier-ignore
                                            type='checkbox'
                                            id='dangerousGoods'
                                            label='Dangerous Goods'
                                            {...register("dangerousGoods", { required: false })}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12'>

                                <p className='text-sm-dark d-flex align-items-center my-2'>Product Image
                                    <img src={infoIcon} alt="Info" className='w-5 cursor-pointer' />
                                </p>
                                {
                                    imageUrl ? (
                                        <>
                                            <div className='text-center border border-slate-300'>
                                                <img src={imageUrl} alt="Product-Image" width="80%" className='mx-auto m-2 rounded-md' />
                                            </div>
                                            <div className='col-12 d-flex justify-content-end'>
                                                <AiOutlineDelete className='m-2 ml-2 cursor-pointer' title='Delete product image'
                                                    onClick={() => {
                                                        deleteButtonHandler(imageUrl)
                                                    }} />
                                                <div>
                                                    <Form.Label>
                                                        <SlPencil className='w-[0.85em] m-2 ml-2 cursor-pointer' title='Update Image' />
                                                        <Form.Control
                                                            type="file"
                                                            onChange={handleFileChange}
                                                            style={{ display: 'none' }}
                                                        />
                                                    </Form.Label>
                                                </div>
                                            </div>
                                        </>
                                    ) : (
                                        <div className='upload-container text-center border border-slate-300'>
                                            <div className='justify-center'>
                                                <span className='product-image-upload-icon'><img src={uploadIcon} alt="File-upload" /></span>
                                                <Form.Group controlId="formFile">
                                                    <Form.Label className="text-decoration-none">
                                                        <span className='text-decoration-none text-sm text-[#158BF8] cursor-pointer' >Click to upload </span>
                                                        <span className='text-sm'>or drag and drop</span>
                                                        <p className='text-sm text-[#6E7478] m-0'>.jpeg, .png or gif</p>
                                                        <Form.Control
                                                            type="file"
                                                            onChange={handleFileChange}
                                                            style={{ display: 'none' }}
                                                        />
                                                    </Form.Label>
                                                </Form.Group>
                                            </div>
                                        </div>
                                    )
                                }
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="light" onClick={handleClose} className='text-sm-dark'>
                            Cancel
                        </Button>

                        <Button variant="primary" onClick={handleSubmit(onSubmit)} className='submit-btn text-sm-dark'>
                            {title}
                        </Button>

                    </Modal.Footer>
                </Form>

                {
                    showDeleteDialog && <ConfirmationDialog
                        showDialog={showDeleteDialog}
                        data={deleteData}
                        dialogTitle="Delete Confirmation"
                        description="Are you sure, you want to delete this product image?"
                        closeButtonLabel="Cancel"
                        ConfirmButtonLabel="Delete"
                        onConfirmation={onDeleteConfirmation}
                        onCancel={onDeleteConfirmationCancel} />
                }

            </Modal>

        </div>
    );
};

export default AddProductModal;
