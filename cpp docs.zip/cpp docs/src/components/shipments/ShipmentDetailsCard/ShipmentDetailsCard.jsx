import React, { useEffect, useState } from "react";
import "./ShipmentDetailsCard.css"
import { Form, Button } from 'react-bootstrap';
import { VscInfo } from 'react-icons/vsc';
import { BsFillPencilFill, BsSearch } from 'react-icons/bs';
import AddProductModal from "../AddProductModal/AddProductModal";
import useHttps from "../../../hooks/useHttps";
import { ApiUrl } from "../../../shared/apiUrl";
import { Typeahead } from "react-bootstrap-typeahead";
import { FaRegTrashAlt } from "react-icons/fa";
import { useForm } from 'react-hook-form';

const ShipmentDetailsCard = (props) => {
    const { getRequest } = useHttps();
    const { register, handleSubmit, formState: { errors }, reset, clearErrors, getValues } = useForm();
    const [validated, setValidated] = useState(false);
    const [pageNumber, setPageNumber] = useState(1);
    const [isNextPageExist, setIsPageExist] = useState(true);
    const [productList, setProductsList] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState([]);
    const [showNewProductModal, setNewProductModal] = useState(false);
    const handleNewProductModal = () => setNewProductModal(true);
    const handleCloseNewProductModal = () => setNewProductModal(false);

    useEffect(() => {
        getProducts();
       
    }, [showNewProductModal,pageNumber]);

    useEffect(()=>{
        if(selectedProduct){
            onFormChange();
        }
    },[selectedProduct])

    const getProducts = async () => {
        if(isNextPageExist){
            const products = await getRequest(`${ApiUrl.PRODUCTS}?page=${pageNumber}`);
            if (products && products?.results.length) {
                setIsPageExist(products.next ? true : false);
                setProductsList((prevProducts) => [...prevProducts, ...products.results]);
            }
        }
    }

    const onProductPageChange = () => {
        setPageNumber(pageNumber+1);
    }

    const onSelectProduct = (result) => {
        setSelectedProduct(result);
        // onFormChange();
    }
    const handleQuantityChange = (index, value) => {
        const updatedProducts = [...selectedProduct];
        updatedProducts[index].quantity = value > 0 ? value : 1; // Ensure valid quantity
        setSelectedProduct(updatedProducts);
    };

    const handleDeleteProduct = (index) => {
        const updatedProducts = selectedProduct.filter((_, i) => i !== index);
        setSelectedProduct(updatedProducts);
    };

   const handleNewProductData = (data)=>{
        setSelectedProduct((product) => {
            const exists = product.some((p) => p.name === data.name);
            if (!exists) {
                return [...product, { ...data }];
            }
            return product; // Return unchanged if product exists
        });
   }

   const onFormChange = ()=>{
        const reqBody = { ...getValues(), products:selectedProduct, isNewShipmentRequested: false, id:props.currentShipment};
        props.handleAddNewShipment(reqBody);
   }

   const handleProductDetailsSubmission = (data)=>{
    if(!selectedProduct.length){
        return;
    }else{
        setValidated(true);
        const reqBody = { ...getValues(), products:selectedProduct, isNewShipmentRequested: true, id:props.currentShipment};
        props.handleAddNewShipment(reqBody);
    }
   }
    
    return (
        <>
        <div className='return-details block-border m-2 shadow-sm'>
            <p className='font-bold d-flex align-items-center'>{props.title} <VscInfo className='label-icon' /></p>
            <div className="row">
                <div className="col-12">
                    <Form.Label htmlFor="inputAddProduct" className='text-sm-dark d-flex align-items-center'>Add Product<VscInfo className='label-icon' /></Form.Label>
                    <div className="search-input-container">
                        <div className="search-input">
                            <BsSearch className="search-icon" />
                            <Typeahead
                                onPaginate={onProductPageChange}
                                paginate={true}
                                maxResults={20}
                                id="inputAddProduct"
                                labelKey="name"
                                onChange={onSelectProduct}
                                options={productList}
                                placeholder="Search Product"
                                className="search-with-button w-100"
                                selected={selectedProduct}
                                paginationText="Load more"
                                renderMenuItemChildren={(product) => (
                                    <>
                                        <div className="d-flex justify-content-between">
                                            <div className="d-flex">
                                                <img
                                                    alt={product.name}
                                                    src={product.image_url}
                                                    style={{
                                                        height: '24px',
                                                        marginRight: '10px',
                                                        width: '24px',
                                                    }}
                                                />
                                                <span>{product.name}</span>
                                            </div>
                                            <span>{product.category}</span>
                                            <span>{product.price}</span>
                                        </div>
                                    </>
                                )}

                                required
                            />
                        </div>

                        <Button variant="light" size="sm" className="add-store-btn shadow-sm" onClick={handleNewProductModal}>+ Add Product</Button>
                        <AddProductModal
                            showModal={showNewProductModal}
                            handleClose={handleCloseNewProductModal}
                            handleSubmitForm={handleNewProductData}
                            key='1' />

                    </div>
                    <Form.Text id="inputHelpAddProduct" muted>
                        Add Product you want to ship,
                        This cannot be modified once the order is created.
                    </Form.Text>

                </div>
            </div>

            {
                selectedProduct.length ?

                    selectedProduct.map((product, index) => {
                        return (
                            <div className="row" key={index}>
                                <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <div className="d-flex justify-content-between">
                                        <div className="d-flex">
                                            {/* <img
                                                alt={product.name}
                                                src={product.product_images[0]}
                                                style={{
                                                    height: '24px',
                                                    marginRight: '10px',
                                                    width: '24px',
                                                }}
                                            /> */}
                                            <span>{product.name}</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <div className="d-flex justify-content-between align-items-center">
                                        <span>{product.price}</span>
                                        <div className="w-25">
                                            {/* <Form.Control size="sm" type="number" placeholder="Quantity"/> */}
                                            <Form.Control
                                                size="sm"
                                                type="number"
                                                placeholder="Quantity"
                                                value={product.quantity || 1} // Default value
                                                min="1" // Minimum quantity
                                                max="999" // Optional: Set a maximum limit
                                                onChange={(e) => handleQuantityChange(index, e.target.value)} // State handler
                                                aria-label={`Quantity for ${product.name}`}
                                            />

                                        </div>    
                                    </div>
                                </div>
                                <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <div className="d-flex justify-content-between">

                                        <span>{product.price}</span>
                                        <div className="d-flex shipment-icon-container">
                                            <button className="icon-btn" type="button">
                                                <BsFillPencilFill />
                                            </button>
                                            <button className="icon-btn ml-4" type="button"
                                            onClick={(e)=>handleDeleteProduct(index)}>
                                                <FaRegTrashAlt />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        )
                    })
                    : ''

            }

            <div className='my-2'>
                <p className='font-bold d-flex align-items-center'>Package Details <VscInfo className='label-icon' /></p>
                <div className="row">
                    <div className='col-lg-6 col-md-12 col-sm-12'>
                        <Form.Label htmlFor="inputSelectProduct" className='text-sm-dark'>Package Type</Form.Label>

                        <Form.Select id="inputSelectProduct" required
                        {...register("package_type", {required: true, onChange:()=>{onFormChange()}})}
                        isInvalid = {errors.package_type?.type ==='required'}
                        >
                            <option disabled>Select Package Type</option>
                            <option value="flyer">Flyer</option>
                            <option value="box">Box</option>
                        </Form.Select>
                        <Form.Text id="inputSelectProduct" muted>
                            Select package which will be used to ship.
                        </Form.Text>
                    </div>
                    <div className='col-lg-6 col-md-12 col-sm-12'>
                        <Form.Label htmlFor="inputProductSize" className='text-sm-dark'>Size</Form.Label>
                        <div className="d-flex">
                            <Form.Control
                                type="text"
                                id="inputProductSize"
                                className='product-size'
                                placeholder="Length"
                                {...register("length", {required: true, onChange:()=>{onFormChange()} })}
                                isInvalid = {errors.length?.type ==='required'}
                                required
                            />
                            <Form.Control
                                type="text"
                                id="inputProductSize"
                                className='product-size'
                                placeholder="Breadth"
                                onChange={onFormChange}
                                {...register("breadth", {required: true, onChange:()=>{onFormChange()}})}
                                isInvalid = {errors.breadth?.type ==='required'}

                                required
                            />
                            <Form.Control
                                type="text"
                                id="inputProductSize"
                                className='product-size'
                                placeholder="Height"
                                onChange={onFormChange}
                                {...register("height", {required: true, onChange:()=>{onFormChange()}})}
                                isInvalid = {errors.height?.type ==='required'}
                                required
                            />
                            <Form.Control
                                type="text"
                                id="inputProductSize"
                                className='product-size'
                                placeholder="cm"
                                disabled
                                required
                            />
                        </div>
                        <Form.Text id="inputProductSize" muted>
                            Length+Breadth+Height should be atleast 15 CM.
                        </Form.Text>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className='col-lg-6 col-md-12 col-sm-12'>
                    <Form.Label htmlFor="inputDeadWeight" className='text-sm-dark d-flex align-items-center'>Dead Weight (gm) <VscInfo className='label-icon' /></Form.Label>
                    <Form.Control
                        type="text"
                        id="inputDeadWeight"
                        className='product-size'
                        placeholder="Enter Dead Weight"
                        onChange={onFormChange}
                        {...register("deadWeight", {required: true, onChange:()=>{onFormChange()}})}
                        isInvalid = {errors.deadWeight?.type ==='required'}
                        required
                    />
                </div>
            </div>
        </div>
        {
          props.totalShipment-1 === props.currentShipment &&
            <div className='d-flex justify-content-end m-2'>
                        <Button variant="light" size="sm" className="add-store-btn shadow-sm" 
                        onClick={handleSubmit(handleProductDetailsSubmission)} 
                        >+ Add Shipment</Button>
            </div>
        }
        </>
    )
}


export default ShipmentDetailsCard;