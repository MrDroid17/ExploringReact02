// src/hooks/useManifestForm.js

import { useState } from "react";

const useManifestForm = () => {
  const [form, setForm] = useState({
    channel: "Manual - Custom",
    order_id: "",
    sub_shipper: "",
    pickup_address: {
      subShipper: "",
      facilityName: "",
      phoneNumber: "",
      contactPerson: "",
      shippingLine: "",
      landmark: "",
      pincode: "",
      state: "",
      city: "",
    },
    return_address: {
      phoneNumber: "",
      contactPerson: "",
      email: "",
      shippingLine: "",
      landmark: "",
      pincode: "",
      state: "",
      city: "",
      fName: "",
      lName: "",
    },
    billing_same: "",
    otp_required: "",
    shipments: [],
    // payment_details: {
      shipment_value: "",
      collectable_value: "",
      payment_mode: "",
      shipping_mode: "",
    // },
  });

  const updateFormField = (field, value) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  return { form, updateFormField };
};

export default useManifestForm;
