import React, { useEffect, useRef, useState } from "react";
import { VscInfo } from "react-icons/vsc";
import { Accordion, Button, Card, Form } from "react-bootstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "./Forward.css";
import AddressDetailsCard from "../AddressDetailsCard/AddressDetailsCard";
import ShipmentDetailsCard from "../ShipmentDetailsCard/ShipmentDetailsCard";
import shopImage from "../../../assets/images/Notifications.svg";
import { FaStore } from "react-icons/fa";
import InputGroup from "react-bootstrap/InputGroup";
import { BsCurrencyRupee } from "react-icons/bs";
import ShippingModeCard from "../ShippingModeCard/ShippingModeCard";
import shippingModeSurface from "../../../assets/images/lineicons_delivery 1.svg";
import { useToast } from "../../../context/ToastContext";
import { useLoader } from "../../../context/LoaderContext";
import useHttp from "../../../hooks/useHttps";
import { ApiUrl } from "../../../shared/apiUrl";
import useManifestForm from "./hooks/useManifestForm";
import { useForm } from "react-hook-form";

const Forward = () => {
  const { showSuccess, showError } = useToast();
  const { getRequest, postRequest } = useHttp();
  const { showLoader } = useLoader();
  const { register, handleSubmit, formState: { errors }, reset, clearErrors, getValues } = useForm();
  const { form, updateFormField } = useManifestForm();
  const [file, setFile] = useState(null);
  const [shipments, setShipments] = useState([1]);
  const [validated, setValidated] = useState(false);
  const [selectedShippingMode, setSelectedShippingMode] = useState(1); 
  const [isFinanceDetailsRequired, setIsFinanceDetailsRequired] = useState(false);
  const formRef = useRef(null)
  const options = ["Manual - Custom"];

  const [shipmentList, setShipmentList] = useState([]);

  const handleAddNewShipment = (data) => {
    if(data.isNewShipmentRequested){
        setShipments((prev) => [...prev, prev[prev.length - 1] + 1]);
    }

    // Update the shipment list
    setShipmentList((prevList) => {
        const exists = prevList.some((p) => p.id === data.id);

        if (!exists) {
            // Add the new product if it doesn't exist
            return [...prevList, { ...data }];
        }
        // Update existing product details
        return prevList.map((p) =>
            p.id === data.id ? { ...p, ...data } : p
        );
    });


  };


  const handleChange = (e) => {
    const { id, value } = e.target;
    updateFormField(id, value);
  };

  const getAddressFromAddressDetails = (data) => {
    const addressType = data.type === "pickup" ? "pickup_address" : "return_address";
    updateFormField(addressType, { ...data.data });
  };

  const validateForm = () => {
    // const form = document.getElementById("forwardForm");
    const form = formRef.current;
    if (form.checkValidity() === false) {
      setValidated(true);
      return false;
    }
    return true;
  };

  const onChangeCollectableValue = ()=>{
        const { collectable_value } = getValues();
        if(collectable_value && +collectable_value >=50000){
            setIsFinanceDetailsRequired(true);
        }else{
            setIsFinanceDetailsRequired(false);
        }
  }

  const manifestShipment = async(event) => {
    // event.preventDefault();
    if (validateForm()) {
      console.log("Form is valid. Proceed with submission.", form);
      console.log("newForm value", getValues())
      console.log("shipment deatils", shipmentList);

      const formValue= getValues();
      // Handle form submission logic
      const reqBody = shipmentList.map(shipment=>{
        return {
            RETURN_PHONE: form.pickup_address.phoneNumber,
            CONSIGNEE_ADDRESS1: form.pickup_address.shippingLine, ///Address
            DG_SHIPMENT: shipment.products[0].is_dangerous_goods,
            RETURN_MOBILE: form.pickup_address.phoneNumber,
            DESTINATION_CITY: form.return_address.city,
            PICKUP_PINCODE: form.pickup_address.pincode,
            STATE: form.pickup_address.state,
            PICKUP_MOBILE:form.pickup_address.phoneNumber,
            LENGTH: shipment.length,
            PIECES: shipment.products.length,
            ORDER_NUMBER: formValue.order_id,
            PICKUP_NAME: form.pickup_address.contactPerson,
            BREADTH: shipment.breadth,
            PRODUCT: shipment.products[0].name,
            RETURN_NAME: form.return_address.fName + form.return_address.lName,
            HEIGHT: shipment.height,
            PICKUP_ADDRESS_LINE1: form.pickup_address.shippingLine,
            MOBILE: form.pickup_address.phoneNumber,
            COLLECTABLE_VALUE: formValue.collectable_value,
            CONSIGNEE: form.pickup_address.facilityName,
            PINCODE: form.pickup_address.pincode,
            DECLARED_VALUE:formValue.shipment_value,
            PICKUP_PHONE: form.pickup_address.phoneNumber,
            VOLUMETRIC_WEIGHT: (shipment.length*shipment.breadth*shipment.height)/5000,
            RETURN_PINCODE: form.return_address.pincode,
            RETURN_ADDRESS_LINE1: form.return_address.shippingLine,
            ACTUAL_WEIGHT: shipment.deadWeight,
            ITEM_DESCRIPTION: shipment.products[0].name,
            OTP_REQUIRED:'',
            PRODUCT_TYPE:'FWD'
        }
      });


      console.log(reqBody);
      return;

      let res = await postRequest(ApiUrl.SINGLE_MENIFEST, reqBody);
      if(res && res.message){
        showSuccess({detail: res.message});

        //reset the form and values.
      }
    }
  };



  const shippingModes = [
    { id: 1, img: shippingModeSurface, title: "Surface", price: "500", deliveryDays: "3" },
    { id: 2, img: shippingModeSurface, title: "Air", price: "", deliveryDays: "" },
  ];

  const handleSelectShippingMode = (id) => {
    // If the selected card is clicked again, toggle it off; otherwise, select it
    setSelectedShippingMode(id === selectedShippingMode ? null : id);
  };

  const calculateRate = async()=>{
        console.log("dssjlkfsdf", getValues())
        const totalWeight = shipmentList.reduce((next, acc)=> (+acc.deadWeight)+(+next.deadWeight));
        const totalValue = getValues().collectable_value;
        if(totalWeight && totalValue){
            const reqBody = {
                "originPincode": form.pickup_address.pincode,
                "destinationPincode": form.return_address.pincode,
                "productType": getValues().payment_mode,
                "chargeableWeight": totalWeight,
                "codAmount": totalValue
              }
    
            const res = await postRequest(ApiUrl.RATE_CALCULATOR, reqBody);
            if(res && res.data){
                console.log("rate", res.data);
            }  
        }
  }

    return (
        <Form noValidate validated={validated} ref={formRef}>
            <div className='forward w-[100%] mb-2 p-3'>
                <div className='basis-[70%]'>
                    {/* Order Details */}
                    <div className='order-details block-border  m-2 shadow-sm'>
                        <p className='font-bold'>Order Details</p>
                        <div className="row">
                            <div className="col-lg-6 col-md-6 col-sm-12">
                                <Form.Label htmlFor="channel" className='text-sm-dark d-flex align-items-center'>Select Channel<VscInfo className='label-icon' /></Form.Label>
                                <Typeahead
                                    caseSensitive={false}
                                    id="channel"
                                    // labelKey="name"
                                    options={options}
                                    className='w-[100%]'
                                    placeholder="Select Channel"
                                    value={form.channel}
                                    defaultSelected={options.slice(0, 1)}
                                    
                                    renderMenuItemChildren={(option) => (
                                        <div className='d-flex align-item-center'>
                                            <FaStore />
                                            <span className='ml-4'>{option}</span>
                                        </div>
                                    )}
                                    disabled
                                />
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                <Form.Label htmlFor="order_id" className='text-sm-dark d-flex align-items-center'>Order ID <VscInfo className='label-icon' /> </Form.Label>
                                <Form.Control
                                    type="text"
                                    id="order_id"
                                    aria-describedby="inputOrderHelpBlock"
                                    placeholder='Enter Order ID / Reference Number'
                                    className='w-[100%] border'
                                    {...register("order_id", {required: true})}
                                    isInvalid = {errors.order_id?.type ==='required'}
                                    required
                                />
                            </div>
                        </div>
                    </div>

                    {/* Address details */}
                    <AddressDetailsCard title="Adderss Details" handleAddressData={getAddressFromAddressDetails} />

                    {/* Shipments */}
                    {
                        shipments.map((item, index) => {

                            return <ShipmentDetailsCard title={`Shipment-${item}`} key={item} 
                            handleAddNewShipment={handleAddNewShipment} totalShipment={shipments.length} 
                            currentShipment={index} />
                        })
                    }
{/* 
                    <div className='d-flex justify-content-end m-2'>
                        <Button variant="light" size="sm" className="add-store-btn shadow-sm" onClick={handleAddNewShipment}>+ Add Shipment</Button>

                    </div> */}

                    {
                        isFinanceDetailsRequired &&
                        <div className="finance-details block-border m-2 shadow-sm">
                            <p className="font-bold d-flex align-items-center">
                                Finance <VscInfo className="label-icon" />
                            </p>
                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="seller_gst" className="text-sm-dark">
                                                    Seller GSTN
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="seller_gst"
                                                    placeholder="Enter Seller GSTN"
                                                    {...register("seller_gst", {required: true})}
                                                    isInvalid = {errors.seller_gst?.type ==='required'}
                                                />
                                </div>

                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="eway_bill" className="text-sm-dark">
                                                    E-Waybill Number
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="eway_bill"
                                                    placeholder="Enter Ewaybill Number"
                                                    {...register("eway_bill", {required: true})}
                                                    isInvalid = {errors.eway_bill?.type ==='required'}
                                                />  
                                </div>

                            </div>

                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="gst_hsn" className="text-sm-dark">
                                                    GST HSN
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="gst_hsn"
                                                    placeholder="Enter GST HSN"
                                                    {...register("gst_hsn", {required: true})}
                                                    isInvalid = {errors.gst_hsn?.type ==='required'}
                                                />
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="type" className='text-sm-dark'>Type</Form.Label>
                                        <Form.Select id='type' {...register("type", {required: true})}
                                            isInvalid = {errors.type?.type ==='required'}
                                            >
                                            <option disabled >Select</option>
                                            <option value="GST">GST</option>
                                            <option value="VAT">VAT</option>
                                            <option value="CST">CST</option>
                                        </Form.Select>

                                
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="gst_rates" className='text-sm-dark'>GST Rates</Form.Label>
                                        <Form.Select id='gst_rates' {...register("gst_rates", {required: true})}
                                            isInvalid = {errors.gst_rates?.type ==='required'}
                                            >
                                            <option disabled>Select</option>
                                            <option value="GST">GST</option>
                                            <option value="VAT">VAT</option>
                                            <option value="CST">CST</option>
                                        </Form.Select>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="item_value" className="text-sm-dark">
                                                    Total Item Value
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="item_value"
                                                    disabled
                                                    {...register("item_value", {required: true})}
                                                    isInvalid = {errors.item_value?.type ==='required'}
                                                />
                                </div>

                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="sgst_amount" className="text-sm-dark">
                                                    SGST Amount
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="sgst_amount"
                                                    disabled
                                                    {...register("sgst_amount", {required: true})}
                                                    isInvalid = {errors.sgst_amount?.type ==='required'}
                                                />  
                                </div>

                            </div>

                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="cgst" className="text-sm-dark">
                                                    CGST
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="cgst"
                                                    disabled
                                                    {...register("cgst", {required: true})}
                                                    isInvalid = {errors.cgst?.type ==='required'}
                                                />
                                </div>

                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="igst" className="text-sm-dark">
                                                    IGST
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="igst"
                                                    disabled
                                                    {...register("igst", {required: true})}
                                                    isInvalid = {errors.igst?.type ==='required'}
                                                />  
                                </div>

                            </div>

                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="total_gst_amount" className="text-sm-dark">
                                                    Total GST Amount
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="total_gst_amount"
                                                    disabled
                                                    {...register("total_gst_amount", {required: true})}
                                                    isInvalid = {errors.total_gst_amount?.type ==='required'}
                                                />
                                </div>

                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <Form.Label htmlFor="invoice_value" className="text-sm-dark">
                                                    Total Invoice Value
                                                </Form.Label>
                                                <Form.Control
                                                    type="text"
                                                    id="invoice_value"
                                                    disabled
                                                    {...register("invoice_value", {required: true})}
                                                    isInvalid = {errors.invoice_value?.type ==='required'}
                                                />  
                                </div>

                            </div>

                        </div>

                    }

                </div>

                <div className='basis-[30%] m-2'>
                    <div className='payment-details block-border '>

                        <p className='font-bold d-flex align-items-center'>Payment Details  <VscInfo className='label-icon' /></p>
                        <div className='addresses flex my-2'>
                            <div className='mx-2 flex-1'>
                                <Form.Label htmlFor="shipment_value" className='text-sm-dark'>Shipment value</Form.Label>
                                <InputGroup className="mb-3">
                                    <InputGroup.Text id="shipment_value1"><BsCurrencyRupee /></InputGroup.Text>
                                    <Form.Control
                                        placeholder="00.00"
                                        aria-label="Shipment Value"
                                        // aria-describedby="shipment_value"
                                        id='shipment_value'
                                        {...register("shipment_value", {required: true})}
                                        isInvalid = {errors.shipment_value?.type ==='required'}
                                        required
                                    />
                                </InputGroup>
                            </div>
                            <div className='mx-2 flex-1'>
                                <Form.Label htmlFor="collectable_value" className='text-sm-dark'>Collectable Value</Form.Label>
                                <InputGroup className="mb-3">
                                    <InputGroup.Text id="collectable_value"><BsCurrencyRupee /></InputGroup.Text>
                                    <Form.Control
                                        placeholder="00.00"
                                        aria-label="Collectable Value"
                                        aria-describedby="collectable_value"
                                        id="collectable_value"
                                        {...register("collectable_value", {required: true, 
                                            onChange:onChangeCollectableValue})}
                                        isInvalid = {errors.collectable_value?.type ==='required'}
                                        required
                                    />
                                </InputGroup>
                            </div>
                        </div>
                        <div className='row payment-mode-container mb-3'>
                            <p className='font-bold d-flex align-items-center'>Payment Mode  <VscInfo className='label-icon' /></p>

                            <div className='col-lg-6 col-md-6 col-sm-12 payment-mode selected'>
                                <Form.Check
                                    inline
                                    label="Prepaid Delivery"
                                    name="group1"
                                    type='radio'
                                    id='prepaid_delivery1'
                                    value="PPD"
                                    {...register("payment_mode", {required: true, onChange:calculateRate})}
                                />

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 payment-mode'>
                                <Form.Check
                                    inline
                                    label="Cash on Delivery"
                                    name="group1"
                                    type='radio'
                                    id='prepaid_delivery2'
                                    value='COD'
                                    {...register("payment_mode", {required: true, onChange: calculateRate})}
                                    
                                />
                            </div>
                        </div>
                        <p className='font-bold text-sm'>Choose Shipping Mode</p>
                        <div className='file-cards grid grid-cols-2 gap-2'>

                        {shippingModes.map((mode) => (
                                <ShippingModeCard
                                key={mode.id}
                                isSelected={mode.id === selectedShippingMode}
                                img={mode.img}
                                title={mode.title}
                                price={mode.price}
                                deliveryDays={mode.deliveryDays}
                                onClick={() => handleSelectShippingMode(mode.id)}
                                />
                            ))}
                        </div>
                        <Accordion className='my-2' defaultActiveKey="0">
                            <Accordion.Item eventKey="0">
                                <Accordion.Header>Shipping Charge Breakup</Accordion.Header>
                                <Accordion.Body>
                                    <div className='border-b-1 border-gray-500 amount-breakup'>
                                        <p className='text-xs d-flex align-items-center'>
                                            <span>Freight Cost</span>
                                            <span className='d-flex align-items-center amount'><BsCurrencyRupee />54.00</span>
                                        </p>
                                        <p className='text-xs d-flex align-items-center'>
                                            <span>Fuel Subcharge & DPH</span>
                                            <span className='d-flex align-items-center amount'><BsCurrencyRupee />54.00</span>
                                        </p>
                                        <p className='text-xs d-flex align-items-center'>
                                            <span>Prepaid Delivery</span>
                                            <span className='d-flex align-items-center amount'><BsCurrencyRupee />54.00</span>
                                        </p>
                                        <p className='text-xs d-flex align-items-center'>
                                            <span>GST - 18%(CGST=SGST)</span>
                                            <span className='d-flex align-items-center amount'><BsCurrencyRupee />54.00</span>
                                        </p>
                                    </div>
                                    <hr />
                                    <p className='font-bold d-flex align-items-center amount-breakup'>
                                        <span>Total</span>
                                        <span className='d-flex align-items-center amount'><BsCurrencyRupee />100.00</span>
                                    </p>
                                </Accordion.Body>
                            </Accordion.Item>
                        </Accordion>

                    </div>

                    <div className='buttons space-x-1 my-2'>
                        <Button className='w-[49%] px-0 !text-xxs bg-white text-black !border-[#C5C7C9]' type="button">Create Order and Manifest Later</Button>
                        <Button className='w-[49%] px-0 !text-xxs !bg-[#E10F76] text-white !border-[#C5C7C9]' type='button' onClick={handleSubmit(manifestShipment)}>Create Order and Get AWB</Button>
                    </div>


                </div>

            </div>
        </Form>
    )
}

export default Forward;