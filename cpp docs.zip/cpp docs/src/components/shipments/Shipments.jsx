import React, { useState } from "react";
import { Tab, Tabs } from "react-bootstrap";
import './Shipments.css';
import Bulk from "./Bulk/Bulk";
import Forward from "./Forward/Forward";
import ReverseShipment from "./ReverseShipment/ReverseShipment";

const Shipments = () => {
    const [activeTab, setActiveTab] = useState("forward"); // default active tab

    return (
        <div className="!block custom-tabs w-[100%]">
            <Tabs
                activeKey={activeTab}
                onSelect={(k) => setActiveTab(k)}  // Update active tab on selection
                transition={false}
                id="noanim-tab-example"
                className="mb-3 custom-tabs"
            >
                <Tab eventKey="forward" title="Forward">
                    {activeTab === "forward" && <Forward/>}
                </Tab>
                <Tab eventKey="reverse" title="Reverse">
                    {activeTab === "reverse" && <ReverseShipment/>}
                </Tab>
                <Tab eventKey="bulk" title="Bulk">
                    {activeTab === "bulk" && <Bulk />}
                </Tab>
            </Tabs>
        </div>
    );
};

export default Shipments;
