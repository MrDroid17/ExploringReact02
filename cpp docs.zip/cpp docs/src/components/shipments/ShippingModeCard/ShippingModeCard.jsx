import React from "react";
import "./ShippingModeCard.css";
import { Card } from 'react-bootstrap'
import { BsCurrencyRupee } from 'react-icons/bs'

const ShippingModeCard = (props) => {
    const { isSelected, img, title, price, deliveryDays, onClick } = props; // Destructure props

    return (
        <Card
            className={`shipping-mode ${isSelected ? 'selected' : ''}`}
            onClick={onClick} // Trigger onClick when card is clicked
        >
            <Card.Header className="d-flex align-items-center">
                {img && <img src={img} alt={title} />}
                <span className='font-bold ml-2'>{title}</span>
            </Card.Header>
            <Card.Body>
                <div className="white-background-body">
                   
                        <p className='font-bold d-flex align-items-center'>
                            <BsCurrencyRupee /> 
                            {
                                price ? <>{price}</> : '---'
                            }
                        </p>
                        <small>Delivery in 
                            {
                                deliveryDays ? 
                                <> {deliveryDays} </> : ' -- '
                            }  
                            Days </small>
                </div>
            </Card.Body>
        </Card>
    );
}

export default ShippingModeCard;
