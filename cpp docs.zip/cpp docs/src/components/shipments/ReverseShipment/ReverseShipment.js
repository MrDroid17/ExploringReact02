import React, { useEffect, useRef, useState } from "react";
import { VscInfo } from "react-icons/vsc";
import { Accordion, Button, Card, Form } from "react-bootstrap";
import { Typeahead } from "react-bootstrap-typeahead";
import "./ReverseShipment.css";
import AddressDetailsCard from "../AddressDetailsCard/AddressDetailsCard";
import ShipmentDetailsCard from "../ShipmentDetailsCard/ShipmentDetailsCard";
import shopImage from "../../../assets/images/Notifications.svg";
import { FaRegTrashAlt, FaStore } from "react-icons/fa";
import InputGroup from "react-bootstrap/InputGroup";
import { BsCloudUpload, BsCurrencyRupee, BsFillPencilFill, BsSearch } from "react-icons/bs";
import ShippingModeCard from "../ShippingModeCard/ShippingModeCard";
import shippingModeSurface from "../../../assets/images/lineicons_delivery 1.svg";
import { useToast } from "../../../context/ToastContext";
import { useLoader } from "../../../context/LoaderContext";
import useHttp from "../../../hooks/useHttps";
import { ApiUrl } from "../../../shared/apiUrl";
import useManifestForm from "../Forward/hooks/useManifestForm";
import { useForm } from "react-hook-form";
import useHttps from "../../../hooks/useHttps";
import AddProductModal from "../AddProductModal/AddProductModal";

const ReverseShipment = () => {
  const { showSuccess, showError } = useToast();
  const { getRequest } = useHttp();
  const { showLoader } = useLoader();
  const { form, updateFormField } = useManifestForm();
  const [file, setFile] = useState(null);
  const [shipments, setShipments] = useState([1]);
  const [validated, setValidated] = useState(false);
  const formRef = useRef(null)

  const options = ["Manual - Custom"];

  useEffect(() => {
    // dummyApiCall();
  }, []);

  const dummyApiCall = async () => {
    const resp = await getRequest(ApiUrl.DELIVERY_ADDRESS);
    console.log(resp);
  };

  const handleAddNewShipment = () => {
    setShipments((prev) => [...prev, prev[prev.length - 1] + 1]);
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleChange = (e) => {
    const { id, value } = e.target;
    updateFormField(id, value);
  };

  const getAddressFromAddressDetails = (data) => {
    const addressType = data.type === "pickup" ? "pickup_address" : "return_address";
    updateFormField(addressType, { ...data.data });
  };

  const validateForm = () => {
    // const form = document.getElementById("forwardForm");
    const form = formRef.current;
    if (form.checkValidity() === false) {
      setValidated(true);
      return false;
    }
    return true;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validateForm()) {
      console.log("Form is valid. Proceed with submission.");
      // Handle form submission logic
    }
  };
    return (
        <Form noValidate validated={validated} onSubmit={handleSubmit} ref={formRef}>
            <div className='forward w-[100%] mb-2 p-3'>
                <div className='basis-[70%]'>
                    {/* Order Details */}
                    <div className='order-details block-border  m-2 shadow-sm'>
                        <p className='font-bold'>Order Details</p>
                        <div className="row">
                            <div className="col-lg-6 col-md-6 col-sm-12">
                                <Form.Label htmlFor="channel" className='text-sm-dark d-flex align-items-center'>Select Channel<VscInfo className='label-icon' /></Form.Label>
                                <Typeahead
                                    caseSensitive={false}
                                    id="channel"
                                    // labelKey="name"
                                    options={options}
                                    className='w-[100%]'
                                    placeholder="Select Channel"
                                    value={form.channel}
                                    defaultSelected={options.slice(0, 1)}
                                    
                                    renderMenuItemChildren={(option) => (
                                        <div className='d-flex align-item-center'>
                                            <FaStore />
                                            <span className='ml-4'>{option}</span>
                                        </div>
                                    )}
                                    disabled
                                />
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12'>
                                <Form.Label htmlFor="order_id" className='text-sm-dark d-flex align-items-center'>Order ID <VscInfo className='label-icon' /> </Form.Label>
                                <Form.Control
                                    type="text"
                                    id="order_id"
                                    aria-describedby="inputOrderHelpBlock"
                                    placeholder='Enter Order ID / Reference Number'
                                    className='w-[100%] border'
                                    value={form.order_id}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        </div>
                    </div>

                    {/* Address details */}
                    <AddressDetailsCard title="Return Details" handleAddressData={getAddressFromAddressDetails} />

                    <ItemDetails/>
                    <OtherDetails/>
                    <QcImageUpload/>


                </div>



                <div className='basis-[30%] m-2'>
                    <div className='payment-details block-border '>

                        <p className='font-bold d-flex align-items-center'>Payment Details  <VscInfo className='label-icon' /></p>
                        <div className='addresses flex my-2'>
                            <div className='mx-2 flex-1'>
                                <Form.Label htmlFor="shipment_value" className='text-sm-dark'>Shipment value</Form.Label>
                                <InputGroup className="mb-3">
                                    <InputGroup.Text id="shipment_value"><BsCurrencyRupee /></InputGroup.Text>
                                    <Form.Control
                                        placeholder="00.00"
                                        aria-label="Shipment Value"
                                        aria-describedby="shipment_value"
                                        id='shipment_value'
                                        value={form.shipment_value}
                                        onChange={handleChange}
                                        required
                                    />
                                </InputGroup>
                            </div>
                            <div className='mx-2 flex-1'>
                                <Form.Label htmlFor="collectable_value" className='text-sm-dark'>Collectable Value</Form.Label>
                                <InputGroup className="mb-3">
                                    <InputGroup.Text id="collectable_value"><BsCurrencyRupee /></InputGroup.Text>
                                    <Form.Control
                                        placeholder="00.00"
                                        aria-label="Collectable Value"
                                        aria-describedby="collectable_value"
                                        value={form.collectable_value}
                                        onChange={handleChange}
                                        required
                                    />
                                </InputGroup>
                            </div>
                        </div>
                        {/* <div className='row payment-mode-container mb-3'>
                            <p className='font-bold d-flex align-items-center'>Payment Mode  <VscInfo className='label-icon' /></p>

                            <div className='col-lg-6 col-md-6 col-sm-12 payment-mode selected'>
                                <Form.Check
                                    inline
                                    label="Prepaid Delivery"
                                    name="group1"
                                    type='radio'
                                    id='prepaid_delivery1'
                                    value={form.payment_mode}
                                    onChange={handleChange}
                                    required
                                />

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 payment-mode'>
                                <Form.Check
                                    inline
                                    label="Cash on Delivery"
                                    name="group1"
                                    type='radio'
                                    id='prepaid_delivery2'
                                    value={form.payment_mode}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        </div> */}
                        <p className='font-bold text-sm'>Choose Shipping Mode</p>
                        <div className='file-cards grid grid-cols-2 gap-2'>
                            <ShippingModeCard img={shippingModeSurface} title='Surface' isSelected={true} />
                            <ShippingModeCard img={shippingModeSurface} title='Air' isSelected={false} />

                        </div>

                        <Accordion className='my-2' defaultActiveKey="0">
                            <Accordion.Item eventKey="0">
                                <Accordion.Header>Shipping Charge Breakup</Accordion.Header>
                                <Accordion.Body>
                                    <div className='border-b-1 border-gray-500 amount-breakup'>
                                        <p className='text-xs d-flex align-items-center'>
                                            <span>Freight Cost</span>
                                            <span className='d-flex align-items-center amount'><BsCurrencyRupee />54.00</span>
                                        </p>
                                        <p className='text-xs d-flex align-items-center'>
                                            <span>Fuel Subcharge & DPH</span>
                                            <span className='d-flex align-items-center amount'><BsCurrencyRupee />54.00</span>
                                        </p>
                                        <p className='text-xs d-flex align-items-center'>
                                            <span>Prepaid Delivery</span>
                                            <span className='d-flex align-items-center amount'><BsCurrencyRupee />54.00</span>
                                        </p>
                                        <p className='text-xs d-flex align-items-center'>
                                            <span>GST - 18%(CGST=SGST)</span>
                                            <span className='d-flex align-items-center amount'><BsCurrencyRupee />54.00</span>
                                        </p>
                                    </div>
                                    <hr />
                                    <p className='font-bold d-flex align-items-center amount-breakup'>
                                        <span>Total</span>
                                        <span className='d-flex align-items-center amount'><BsCurrencyRupee />100.00</span>
                                    </p>
                                </Accordion.Body>
                            </Accordion.Item>
                        </Accordion>

                    </div>

                    <div className='buttons space-x-1 my-2'>
                        <Button className='w-[49%] px-0 !text-xxs bg-white text-black !border-[#C5C7C9]' type="button">Create Order and Manifest Later</Button>
                        <Button className='w-[49%] px-0 !text-xxs !bg-[#E10F76] text-white !border-[#C5C7C9]' type='submit'>Create Order and Get AWB</Button>
                    </div>


                </div>

            </div>
        </Form>
    )
}


const ItemDetails = ()=>{
    const { getRequest } = useHttps();
    const { register, handleSubmit, formState: { errors }, reset, clearErrors, getValues } = useForm();
    const [validated, setValidated] = useState(false);
    const [pageNumber, setPageNumber] = useState(1);
    const [isNextPageExist, setIsPageExist] = useState(true);
    const [productList, setProductsList] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState([]);
    const [showNewProductModal, setNewProductModal] = useState(false);
    const handleNewProductModal = () => setNewProductModal(true);
    const handleCloseNewProductModal = () => setNewProductModal(false);

    useEffect(() => {
        getProducts();
       
    }, [showNewProductModal,pageNumber]);


    const getProducts = async () => {
        if(isNextPageExist){
            const products = await getRequest(`${ApiUrl.PRODUCTS}?page=${pageNumber}`);
            if (products && products?.results.length) {
                setIsPageExist(products.next ? true : false);
                setProductsList((prevProducts) => [...prevProducts, ...products.results]);
            }
        }
    }

    const onProductPageChange = () => {
        setPageNumber(pageNumber+1);
    }

    const onSelectProduct = (result) => {
        setSelectedProduct(result);
        // onFormChange();
    }
    const handleQuantityChange = (index, value) => {
        const updatedProducts = [...selectedProduct];
        updatedProducts[index].quantity = value > 0 ? value : 1; // Ensure valid quantity
        setSelectedProduct(updatedProducts);
    };

    const handleDeleteProduct = (index) => {
        const updatedProducts = selectedProduct.filter((_, i) => i !== index);
        setSelectedProduct(updatedProducts);
    };

   const handleNewProductData = (data)=>{
        setSelectedProduct((product) => {
            const exists = product.some((p) => p.name === data.name);
            if (!exists) {
                return [...product, { ...data }];
            }
            return product; // Return unchanged if product exists
        });
   }

    return (
        <div className='return-details block-border m-2 shadow-sm'>
            <p className='font-bold d-flex align-items-center'>Items Details <VscInfo className='label-icon' /></p>
            <div className="row">
                <div className="col-12">
                    <Form.Label htmlFor="inputAddProduct" className='text-sm-dark d-flex align-items-center'>Add Product<VscInfo className='label-icon' /></Form.Label>
                    <div className="search-input-container">
                        <div className="search-input">
                            <BsSearch className="search-icon" />
                            <Typeahead
                                onPaginate={onProductPageChange}
                                paginate={true}
                                maxResults={20}
                                id="inputAddProduct"
                                labelKey="name"
                                onChange={onSelectProduct}
                                options={productList}
                                placeholder="Search Product"
                                className="search-with-button w-100"
                                selected={selectedProduct}
                                paginationText="Load more"
                                renderMenuItemChildren={(product) => (
                                    <>
                                        <div className="d-flex justify-content-between">
                                            <div className="d-flex">
                                                <img
                                                    alt={product.name}
                                                    src={product.product_images[0]}
                                                    style={{
                                                        height: '24px',
                                                        marginRight: '10px',
                                                        width: '24px',
                                                    }}
                                                />
                                                <span>{product.name}</span>
                                            </div>
                                            <span>{product.category}</span>
                                            <span>{product.price}</span>
                                        </div>
                                    </>
                                )}

                                required
                            />
                        </div>

                        <Button variant="light" size="sm" className="add-store-btn shadow-sm" onClick={handleNewProductModal}>+ Add Product</Button>
                        <AddProductModal
                            showModal={showNewProductModal}
                            handleClose={handleCloseNewProductModal}
                            handleSubmitForm={handleNewProductData}
                            key='1' />

                    </div>
                    <Form.Text id="inputHelpAddProduct" muted>
                        Add Product you want to ship,
                        This cannot be modified once the order is created.
                    </Form.Text>

                </div>
            </div>

            {
                selectedProduct.length ?

                    selectedProduct.map((product, index) => {
                        return (
                            <div className="row" key={index}>
                                <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <div className="d-flex justify-content-between">
                                        <div className="d-flex">
                                            {/* <img
                                                alt={product.name}
                                                src={product.product_images[0]}
                                                style={{
                                                    height: '24px',
                                                    marginRight: '10px',
                                                    width: '24px',
                                                }}
                                            /> */}
                                            <span>{product.name}</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <div className="d-flex justify-content-between align-items-center">
                                        <span>{product.price}</span>
                                        <div className="w-25">
                                            {/* <Form.Control size="sm" type="number" placeholder="Quantity"/> */}
                                            <Form.Control
                                                size="sm"
                                                type="number"
                                                placeholder="Quantity"
                                                value={product.quantity || 1} // Default value
                                                min="1" // Minimum quantity
                                                max="999" // Optional: Set a maximum limit
                                                onChange={(e) => handleQuantityChange(index, e.target.value)} // State handler
                                                aria-label={`Quantity for ${product.name}`}
                                            />

                                        </div>    
                                    </div>
                                </div>
                                <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                    <div className="d-flex justify-content-between">

                                        <span>{product.price}</span>
                                        <div className="d-flex shipment-icon-container">
                                            <button className="icon-btn" type="button">
                                                <BsFillPencilFill />
                                            </button>
                                            <button className="icon-btn ml-4" type="button"
                                            onClick={(e)=>handleDeleteProduct(index)}>
                                                <FaRegTrashAlt />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        )
                    })
                    : ''

            }
        </div>
    )
}

const OtherDetails = ()=>{
    return (
        <div className='return-details block-border m-2 shadow-sm'>
        <p className='font-bold d-flex align-items-center'>Other Details <VscInfo className='label-icon' /></p>
        <div className="row">
            <div className="col-12">
                <Form.Label htmlFor="inputAddProduct" className='text-sm-dark d-flex align-items-center'>Reason for Return</Form.Label>
                <Form.Select aria-label="Default select example">
                <option>Open this select menu</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
                </Form.Select>
               

            </div>
            <div className="col-12">
                    <Form.Label htmlFor="inputReason">Enter Reason</Form.Label>
            <Form.Control
                type="text"
                id="inputReason"
                aria-describedby="reasonHelpBlock"
            />
            </div>   

             <div className="col-12">
                    <Form.Label htmlFor="inputNote">Note for Quantity Analysis</Form.Label>
                    <Form.Control as="textarea" rows={3}  id="inputNote"/>
                    <Form.Text id="inputHelpAddProduct" muted>
                    This will help our field executive to check your item(s) based on your notes.
                </Form.Text>
            </div>   
        </div>

    </div>
    )
}

const QcImageUpload = () => {
    const [file, setFile] = useState(null);

    const handleFileChange = async (e) => {
        const file = e.target.files[0];
        setFile(file);
    };
    return (
        <div className='return-details block-border m-2 shadow-sm m-2'>
            <p className='text-sm-dark d-flex align-items-center'>QC Image<VscInfo className='label-icon' /></p>
            <div className='upload-container file-upload text-center m-2 block-border '>
                <div className='justify-center'>
                    <span className='product-image-upload-icon'><BsCloudUpload /></span>
                    <Form.Group controlId="formFile">
                        <Form.Label className="text-decoration-none">
                        <span className='btn btn-link text-decoration-none'>Click to upload</span>
                             <span>or drag and drop</span><br/>
                            <span>.jpeg, .png or gif</span>
                            <Form.Control
                                type="file"
                                onChange={handleFileChange}
                                style={{ display: 'none' }}
                            />
                        </Form.Label>
                    </Form.Group>
                </div>
            </div>
        </div>
    )
}

export default ReverseShipment;