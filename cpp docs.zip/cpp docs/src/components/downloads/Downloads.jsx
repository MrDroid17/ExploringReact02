import React from 'react'
import { Tab, Tabs } from 'react-bootstrap'
import Reports from './reports/Reports'
import ShipmentUpload from './shipment-upload/ShipmentUpload'
import ShipmentDownload from './shipment-download/ShipmentDownload'
import Exceptions from './exceptions/Exceptions'
import Tickets from './tickets/Tickets'
import './Downloads.css'

const Downloads = () => {

  return (
    <div className="!block custom-tabs-download w-[100%]">
            <Tabs
                defaultActiveKey="Exceptions"
                transition={false}
                id="noanim-tab-example"
                className="mb-3 custom-tabs-download"
                >
                <Tab eventKey="Reports" title="Reports">
                    <Reports/>
                </Tab>
                <Tab eventKey="Shipments Upload" title="Shipments Upload">
                    <ShipmentUpload/>
                </Tab>
                <Tab eventKey="Shipment Downloads" title="Shipment Downloads">
                    <ShipmentDownload />
                </Tab>
                <Tab eventKey="Exceptions" title="Exceptions">
                    <Exceptions />
                </Tab>
                <Tab eventKey="Tickets" title="Tickets">
                    <Tickets />
                </Tab>
            </Tabs>
        </div>
  )
}

export default Downloads