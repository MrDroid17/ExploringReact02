import React, { useState } from 'react'
import { Button, Table } from 'react-bootstrap'
import Transithistoymodal from '../../../shared/Transithistoymodal'
import Reattemptmodal from '../../../shared/Reattemptmodal'
import { useNavigate } from 'react-router-dom'
import './Exceptions.css'

const Exceptions = () => {

  const [show, setShow] = useState(false);
    const [transitShow, settransitShow] = useState(false);

    const handleShow = () => setShow(true); 
    const handleClose = () => setShow(false);

    const navigate = useNavigate()

    const handletransitShow = (event) => {
        event.stopPropagation();
        settransitShow(true)
    };
    const handletransitClose = (event) => {
        event.stopPropagation();
        settransitShow(false)
    };

    const handleAWBClick = () => {
        navigate('/home/awb')
    }




  return (
    <div className='w-full rounded-md'>
      <Table className='custom-table-exception mb-4 mt-2 p-3' hover>
        <thead>
            <tr className='ndr-header'>
                <th><input type="checkbox"/></th>
                <th className='ndr-header'>File Name</th>
                <th className='ndr-header'>Activity</th>
                <th className='ndr-header'>Type</th>
                <th className='ndr-header'>Last Update</th>
                <th className='ndr-header'>Uploaded By</th>
                <th className='ndr-header'>Action</th>
            </tr>
        </thead>
        <tbody>
          <tr>
              <td><input type="checkbox"/></td>
              <td className='!text-left'>
                  <p className='mb-0'>Store-1 Manifestation </p>
                  <p className='mb-0'>504 Listing, .csv format, 58KB</p>
              </td>
              <td>Bulk Manifest</td>
              <td>Missing Required Fields</td>
              <td>Sep 29, 2023 10:04</td>
              <td className='!text-left'>
                  <p className='mb-0'>Sumit Sharma</p>
                  <p className='mb-0'>sumits@gmail.com</p>
              </td>
              <td className="p-0">
                  <div className="flex gap-2 items-center justify-center h-full">
                      <Button className="!text-xs" variant="outline-dark">Download</Button>
                      <Button className="!text-xs" variant="outline-dark">Manifest Now</Button>
                  </div>
              </td>
          </tr>
          <tr>
              <td><input type="checkbox"/></td>
              <td className='!text-left'>
                  <p className='mb-0 cursor-pointer'>Store-1 NDR </p>
                  <p className='mb-0'>504 Listing, .csv format, 58KB</p>
              </td>
              <td>NDR Upload</td>
              <td>Field Format Error</td>
              <td>Sep 29, 2023 10:04</td>
              <td className='!text-left'>
                  <p className='mb-0'>Vikas Sharma</p>
                  <p className='mb-0'>vikass@gmail.com</p>
              </td>
              <td className="p-0">
                  <div className="flex gap-2 items-center justify-center h-full">
                      <Button className="!text-xs" variant="outline-dark">Download</Button>
                      <Button className="!text-xs" variant="outline-dark">Manifest Now</Button>
                  </div>
              </td>
          </tr>
          <tr>
              <td><input type="checkbox"/></td>
              <td className='!text-left'>
                  <p className='mb-0 cursor-pointer'>Store-1 Manifestation </p>
                  <p className='mb-0'>504 Listing, .csv format, 58KB</p>
              </td>
              <td>Bulk Manifest</td>
              <td>Missing Required Fields</td>
              <td>Sep 29, 2023 10:04</td>
              <td className='!text-left'>
                  <p className='mb-0'>Sumit Sharma</p>
                  <p className='mb-0'>sumits@gmail.com</p>
              </td>
              <td className="p-0">
                  <div className="flex gap-2 items-center justify-center h-full">
                      <Button className="!text-xs" variant="outline-dark">Download</Button>
                      <Button className="!text-xs" variant="outline-dark">Manifest Now</Button>
                  </div>
              </td>
          </tr>
        </tbody>
      </Table>
    </div>
  )
}

export default Exceptions