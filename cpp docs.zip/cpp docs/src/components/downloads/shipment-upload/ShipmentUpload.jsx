import React from 'react'

const ShipmentUpload = () => {
  return (
    <div className='forward w-[100%] mb-2 p-3 rounded-md'>ShipmentUpload</div>
  )
}

export default ShipmentUpload