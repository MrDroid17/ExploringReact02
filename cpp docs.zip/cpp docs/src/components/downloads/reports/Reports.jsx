import React from 'react'

const Reports = () => {
  return (
    <div className='forward w-[100%] mb-2 p-3 rounded-md'>Reports</div>
  )
}

export default Reports