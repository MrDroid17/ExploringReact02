import React from 'react'

const ShipmentDownload = () => {
  return (
    <div className='forward w-[100%] mb-2 p-3 rounded-md'>ShipmentDownload</div>
  )
}

export default ShipmentDownload