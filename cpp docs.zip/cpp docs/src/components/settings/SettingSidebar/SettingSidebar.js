import React from 'react';
import { NavLink } from 'react-router-dom'
import { Navbar, Nav } from 'react-bootstrap';
import { SETTING_MENUS } from '../constants';
import "./SettingSidebar.css";

const SettingSidebar = () => {
  return (
    <div className="setting-sidebar">
        <div className="menu">
          <Navbar variant="dark" className="d-flex flex-column align-items-start">
            <Nav className="flex-column w-100">
              { 
                SETTING_MENUS.map(menu=>{
                  return <NavLink 
                    to={menu.link} 
                    key={menu.id}
                    className="setting-sidebar sidebar-link"
                    activeclassname="active"
                    exact="true"
                    >
                      <span className='menu-label ml-2'>{menu.label}</span>
                  </NavLink>
                  
                })
            }
            </Nav>
          </Navbar>
        </div>
    </div>
  );
};

export default SettingSidebar;
