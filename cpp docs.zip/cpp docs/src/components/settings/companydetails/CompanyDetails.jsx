import React, { useEffect, useRef, useState } from 'react'
import { Button, Form, InputGroup } from 'react-bootstrap';
import "./CompanyDetails.css";
import { useForm } from 'react-hook-form';
import useHttps from '../../../hooks/useHttps';
import { ApiUrl } from '../../../shared/apiUrl';
import infoIcon from "../../../assets/images/info-small.svg";
import { BiError } from "react-icons/bi";
import closeIcon from '../../../assets/images/ic_close.svg';
import { useToast } from '../../../context/ToastContext';
import { BUSINESS_TYPE } from '../constants';

const CompanyDetails = () => {
    const defaultValue = {
        "document_number": "",
        "type": "",
        "name": "",
        "trade_name": "",
        "pan_number": "",
        "address": "",
        "pincode": null,
        "state": "",
        "city": "",
        "legal_entity_name": "",
    }

    const { showError, showSuccess } = useToast();
    const { getRequest, postRequest } = useHttps();
    const companyDetailsForm = useForm(defaultValue);
    const { register, watch, handleSubmit, getValues, setValue, formState: { errors, isValid } } = companyDetailsForm;
    const formRef = useRef(null)

    const [documentNo, setdocumentNo] = useState("");
    const [isCompanyInfoAvaiable, setIsCompanyInfoAvaiable] = useState(false);
    const [companyInfo, setCompanyInfo] = useState(null);
    const [validated, setValidated] = useState(false);
    const [isValidDocument, setIsValidDocument] = useState(false);
    const [isCompanyDetailDisable, setIsCompanyDetailDisable] = useState(false);
    const [isIfscVerified, setIsIfscVerified] = useState(false);
    const [isBankDetailVerified, setIsBankDetailVerified] = useState(false);
    const [isBankDetailVerificationInProgress, setIsbankDetailVerificationInProgress] = useState(false);
    const [showCancel, setShowCancel] = useState(false);
    const [enableSubmit, setEnableSubmit] = useState(true);

    useEffect(() => {
        getCustomerDetails();
    }, []);

    const getCustomerDetails = async () =>{
        const resp = await getRequest(ApiUrl.CUSTOMER_INFO);
        if (resp && resp.data && resp.data.success) {
            setValue('legal_entity_name', resp.data?.legal_entity_name);
            setValue('business_type', resp.data?.business_type)
            setValue('address', resp.data?.address);
            setValue('pincode', resp.data?.pincode);
            setValue('city', resp.data?.city);
            setValue('state', resp.data?.state);
            setdocumentNo(resp.data?.document_number)
            setShowCancel(true);
            setCompanyInfo(resp.data);
            setIsCompanyInfoAvaiable(true);
            setIsBankDetailVerified(true);
        }
    }


    const verifyDocumentNo = () => {
        console.log(documentNo);
        getDocumentDetail();
        setShowCancel(true);
    }

    const getDocumentDetail = async () => {
        const data = {
            document_number: documentNo
        }
        const resp = await postRequest(ApiUrl.DOCUMENY_VERIFY, data);
        if (resp && resp.data && resp.data.success) {
            setValue('legal_entity_name', resp.data?.legal_entity_name);
            setValue('address', resp.data?.address);
            setValue('pincode', resp.data?.pincode);
            setValue('city', resp.data?.city);
            setValue('state', resp.data?.state);
            setIsCompanyDetailDisable(true);
            setIsValidDocument(true);
        }
    }

    const verifyIFSC = async (e) => {
        const data = {
            ifsc: e.target.value
        }
        const resp = await postRequest(ApiUrl.IFSC_VERIFY, data);
        if (resp && resp.data && resp.data.success) {
            showSuccess({ detail: resp.message || "IFSC Verified" });
            setIsIfscVerified(true);
        }
    }

    const pennyDropAPI = async (data) => {
        setValidated(true);
        data.documentNo = documentNo
        delete data?.name;
        setIsbankDetailVerificationInProgress(true);

        const resp = await postRequest(ApiUrl.PENNY_DROP, data);
        if (resp && resp.data && resp.data.success) {
            showSuccess({ detail: resp.mesage || "Bank Details Successfully Verified" });
            setIsbankDetailVerificationInProgress(false);
            setIsBankDetailVerified(true);
        } else {
            setIsbankDetailVerificationInProgress(false);
        }
    }

    const saveDetails = async () => {
        const data = {
            account_type: "S"
        }
        const resp = await postRequest(ApiUrl.SAVE_BANK_DETAILS, data);
        if (resp && resp.data && resp.data.success) {
            showSuccess({ detail: resp.message || "Bank Details Successfully saved" });
            setEnableSubmit(true);
        }
    }

    const clearDocumentNo = () => {
        setShowCancel(false);
        setdocumentNo("");
    }

    const CompanyDetail = () => (
        <>
            <div className='row mt-2'>
                <div className='col-lg-6 col-md-6 col-sm-12'>
                    <Form.Label htmlFor="name" className='text-sm-dark'>Company Name*</Form.Label>
                    <Form.Control
                        type="text"
                        id="name"
                        placeholder='Enter Company Name'
                        {...register("legal_entity_name", { required: true })}
                        isInvalid={errors.legal_entity_name?.type === 'required'}
                        disabled={isCompanyDetailDisable || isCompanyInfoAvaiable}
                    />
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12'>
                    <Form.Label htmlFor="business-type" className='text-sm-dark'>Business type*</Form.Label>
                    <Form.Select id="business-type"
                        {...register("business_type", { required: true })}
                        isInvalid={errors.business_type?.type === 'required'}
                        disabled={isCompanyInfoAvaiable}
                    >
                        <option value="">Select Business type</option>
                        {
                            BUSINESS_TYPE.map(business_type => (
                                <option
                                    key={business_type.key}
                                    value={business_type.key}
                                >{business_type.label}</option>
                            ))
                        }
                    </Form.Select>
                </div>
            </div>
            <div className='row mt-2'>
                <div className='col-lg-12 col-md-12 col-sm-12'>
                    <Form.Label htmlFor="address" className='text-sm-dark'>Address*</Form.Label>
                    <Form.Control
                        type="text"
                        id="address"
                        placeholder='Street, Apartment, Unit, Building, Floor, etc. '
                        {...register("address", { required: true })}
                        isInvalid={errors.address?.type === 'required'}
                        disabled={isCompanyDetailDisable || isCompanyInfoAvaiable}
                    />
                </div>
            </div>

            <div className='row mt-2'>
                <div className='col-lg-4 col-md-4 col-sm-12'>
                    <Form.Label className='text-sm-dark' htmlFor="pincode">Pincode*</Form.Label>
                    <Form.Control
                        type='number'
                        placeholder='Enter Pincode' id="pincode"
                        {...register("pincode", { required: true })}
                        isInvalid={errors.pincode?.type === 'required'}
                        disabled={isCompanyDetailDisable || isCompanyInfoAvaiable} />
                </div>

                <div className='col-lg-4 col-md-4 col-sm-12'>
                    <Form.Label className='text-sm-dark' htmlFor="city">City*</Form.Label>
                    <Form.Control
                        type='text'
                        placeholder='City' id="city"
                        {...register("city", { required: true })}
                        isInvalid={errors.city?.type === 'required'}
                        disabled={isCompanyDetailDisable || isCompanyInfoAvaiable} />
                </div>
                <div className='col-lg-4 col-md-4 col-sm-12'>
                    <Form.Label className='text-sm-dark' htmlFor="state">State*</Form.Label>
                    <Form.Control
                        type='text'
                        placeholder='State' id="state"
                        {...register("state", { required: true })}
                        isInvalid={errors.state?.type === 'required'}
                        disabled={isCompanyDetailDisable || isCompanyInfoAvaiable} />
                </div>
            </div>
        </>
    )

    const BankDetails = () => {
        return (
            <>
                <div className='row'>
                    <div className='col-lg-6 col-md-6 col-sm-12'>
                        <Form.Label className='text-sm-dark' htmlFor="ifsc">IFSC Code*</Form.Label>
                        <Form.Control
                            type='text'
                            placeholder='Enter IFSC Code' id="ifsc"
                            {...register("ifsc", { required: true })}
                            isInvalid={errors.ifsc?.type === 'required'}
                            disabled={isIfscVerified}
                            onBlur={verifyIFSC}
                        />

                    </div>
                    <div className='company-name flex-1'>
                        <Form.Label className='text-sm-dark' htmlFor="account-no">Account Number*</Form.Label>
                        <Form.Control
                            type='number'
                            placeholder='Enter Account Number' id="account-no"
                            {...register("account_no", { required: true })}
                            isInvalid={errors.account_no?.type === 'required'}
                        // disabled={isIfscVerified}
                        />
                    </div>


                </div>
                <div className='text-right my-2 border-b border-slate-300'>
                    <Button variant="primary" className='mb-2 submit-btn' type='submit'
                        onClick={handleSubmit(pennyDropAPI)}
                        disabled={!isValid}
                    >Validate</Button>
                </div>
            </>
        )
    }

    const BankDetailShimmer = () => (
        <>
            <div className='bank-detail-bg'>
                <div className='w-[65%] progress'></div>
                <div className='h-[15px] progress'></div>
                <div className='h-[15px] progress'></div>
                <div className='d-flex justify-content-start'>
                    <img src={infoIcon} alt="Info icon" className='w-4 my-3 mx-2 mt-0' />
                    <p className='text-xs mb-1'>Bank account validation in progress</p>

                </div>
            </div>
        </>
    )

    const BankDetailVerified = () => (
        <>
            <div className='px-3 py-2 bank-detail-bg'>
                <div className='text-base font-bold'>{companyInfo?.bank_name}</div>
                <div className=''>{companyInfo?.bank_ifsc}, {companyInfo?.bank_branch_name}, {companyInfo?.bank_city}, {companyInfo?.bank_state}-{companyInfo?.bank_pincode}</div>
                {
                    isBankDetailVerified ? (
                        <span className='verify-success'>Bank Account Validated</span>
                    ) : (
                        <span className='verify-failure mt-1 text-sm py-1 rounded-2xl'><BiError className='inline my-0 mr-2' />Bank Account Validation failed</span>
                    )
                }
            </div>
        </>
    )


    return (
        <div className='company-details'>
            <div className=''>
                <div className='justify-content-start'>
                    <div className='m-0'>
                        <Form.Label htmlFor="verify-document-no" className='text-sm-dark'>GST/PAN Number*</Form.Label>
                        <div className="d-flex justify-content-start ">
                            <div className='w-[50%] document-input-container' >
                                <Form.Control
                                    type='text'
                                    id='verify-document-no'
                                    placeholder="Enter GST/PAN Number"
                                    aria-label="Enter GST/PAN Number"
                                    aria-describedby="basic-addon2"
                                    // className='document-input'
                                    value={documentNo}
                                    onChange={(e
                                    ) => { setdocumentNo(e.target.value) }}
                                />
                                {
                                    showCancel && <img className='close-icon' src={closeIcon} alt="close-icon"
                                        onClick={clearDocumentNo} />
                                }

                                <Button variant="light" size='sm' className='check-btn shadow-sm'
                                    onClick={verifyDocumentNo}
                                    disabled={!documentNo}
                                >Verify</Button>
                            </div>
                            {isValidDocument && <div className='w-[40%] px-3 py-2 verify-success'>GST/PAN  number verified</div>}

                        </div>
                    </div>
                </div>
                <Form noValidate validated={validated} ref={formRef}>
                    <CompanyDetail />
                    <p className='text-lg font-medium mt-2'>Bank Details</p>
                    {/**
                         * Bank details form will be visible by default 
                         * during bank detail verification shimmer will be shown and then after 
                         * success or failure response after that
                         */ }
                    {(!isBankDetailVerified && !isBankDetailVerificationInProgress) && <BankDetails />}
                    {isBankDetailVerified && <BankDetailVerified />}
                    {isBankDetailVerificationInProgress && <BankDetailShimmer />}


                </Form>
                {
                    !isCompanyInfoAvaiable && (
                        <div className='text-right'>
                            <Button variant="primary" className="mt-2 submit-btn" disabled={!enableSubmit}
                                onClick={saveDetails}
                            >Submit</Button>
                        </div>
                    )
                }
            </div>
        </div>
    )
}


export default CompanyDetails