import React from 'react';
import searchImage from '../../../assets/images/ic_search.svg';
import refreshIcon from '../../../assets/images/refresh.svg';
import downloadIcon from '../../../assets/images/download.svg';
import { Button, Dropdown, Form } from 'react-bootstrap';
import './Invoice.css';

const Invoice = () => {
  const headers = [
    { 'field': 'invoice_number', 'label': 'Invoice Number' },
    { 'field': 'date', 'label': 'Date' },
    { 'field': 'shipments', 'label': 'Shipments' },
    { 'field': 'state', 'label': 'State' },
    { 'field': 'amount', 'label': 'Amount' },
  ];
  const data = [
    {
      "invoice_number": "10299976001",
      "date": "Nov 29, 2023 10:04",
      "shipments": "200",
      "state": "North",
      "amount": "- ₹33,836.10"
    },
    {
      "invoice_number": "10299976002",
      "date": "Nov 29, 2023 10:04",
      "shipments": "20",
      "state": "North",
      "amount": "- ₹3,134.60"
    },
    {
      "invoice_number": "10299976003",
      "date": "Nov 29, 2023 10:04",
      "shipments": "150",
      "state": "North",
      "amount": "- ₹20,112.10"
    }
  ]

  return (
    <div className='invoice border-b border-slate-300 w-full'>
      <div className='d-flex justify-content-between mb-2 w-full'>
        <Form.Select aria-label="" className='date-select'>
          <option>Select Month</option>
          <option value="nov">Nov, 2024</option>
          <option value="oct">Oct, 2024</option>
          <option value="sept">Sept, 2024</option>
        </Form.Select>
        <div className='d-flex justify-content-end'>
          <img className="w-6 ml-3" src={downloadIcon} alt="download icon" />
          <img className="w-6 mx-3" src={refreshIcon} alt="refresh icon" />
        </div>
      </div>
      <div className='invoice-list'>
        <div className='invoice-header border-b border-slate-300'>
          <Form.Check
            className='select-all'
            type="checkbox"
            id="select-all-checkbox"
            label=""
          />

          {
            headers.map(header => <div key={header.field} className='header'>{header['label']}</div>)
          }
          <div className='header'>
            Action
          </div>
        </div>
        {
          data.map((invoice, index) => (
            <div key={index} className='invoice-body border-b border-slate-300 w-full mb-3'>
              <Form.Check
                className='item-checkbox'
                type="checkbox"
                id="select-all-checkbox"
                label=""
              />
              {
                headers.map(header => (
                  
                  <div 
                  key={header.field} 
                  className={`invoice-row ${header.field === 'invoice_number' ? 'invoice-no' : ''} ${(header.field === 'amount' && invoice[header.field].includes('-')) ? 'text-danger' : ''}  ${(header.field === 'amount' && !invoice[header.field].includes('-')) ? 'text-SUCCESS' : ''}`}>
                     {invoice[header.field]} 
                     </div>
                ))
              }
              <Button variant='btn-secondary' className='download-btn shadow-md invoice-row'>Download</Button>
            </div>
          ))
        }


      </div>
    </div>
  )
}

export default Invoice