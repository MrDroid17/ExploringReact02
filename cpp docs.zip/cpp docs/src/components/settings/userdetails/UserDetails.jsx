import React, { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap'
import './UserDetails.css'
import { useForm } from 'react-hook-form'
import useHttps from '../../../hooks/useHttps'
import { ApiUrl } from '../../../shared/apiUrl'

const UserDetails = () => {
    const { getRequest } = useHttps();
    const userForm = useForm();
    const { register, setValue } = userForm;
    const [isDisable, setIsDisable] = useState(false);

    useEffect(() => {
        getUserDetail();
    }, [])

    const getUserDetail = async () => {
        const resp = await getRequest(ApiUrl.USER_DETAILS);
        if (resp && resp.data && resp.data.success) {
            setValue('full_name', resp.data.full_name);
            setValue('email', resp.data.email);
            setValue('phone_number', resp.data.phone_number);
            setValue('shipper_name', resp.data.shipper_name);
            setValue('shipper_code', resp.data.shipper_code);
        }
        setIsDisable(true);
    }
    return (
        <div className='user-details'>
            <form className='border-b border-slate-300'>

                <div className='flex mb-3 gap-4'>
                    <div className='user-name flex-1'>
                        <p className='mb-1' htmlFor="name">Full Name*</p>
                        <input className='border p-2 rounded-md w-full' placeholder='Enter Name'
                            id="name" {...register("full_name")}
                            disabled={isDisable} />
                    </div>

                    <div className='user-email flex-1'>
                        <p className='mb-1' htmlFor="email">Email*</p>
                        <input className='border p-2 rounded-md w-full' placeholder='Enter your email address'
                            id="email" {...register("email")}
                            disabled={isDisable} />
                    </div>

                </div>

                <div className='flex mb-3 gap-4'>
                    <div className='user-phone flex-1'>
                        <p className='mb-1' htmlFor="phone-number">Phone Number*</p>
                        <input className='border pr-5 p-2 rounded-md !w-[48%]' placeholder='Enter Phone Number'
                            id="phone-number" {...register("phone_number")}
                            disabled={isDisable} />
                    </div>
                </div>

                <p className='text-lg font-medium mt-8'>Shipment Details</p>
                <div className='flex mb-3 gap-4'>
                    <div className='user-sname flex-1'>
                        <p className='mb-1' htmlFor="shipper-name">Shipper Name*</p>
                        <input className='border p-2 rounded-md w-full' placeholder='Enter Shipper Name' id="shipper-name" {...register("shipper_name")} 
                        disabled={isDisable}/>
                    </div>

                    <div className='user-code flex-1'>
                        <p className='mb-1' htmlFor="shipper-code">Shipper Code*</p>
                        <input className='border p-2 rounded-md w-full' placeholder='Enter Shipper Code' id="shipper-code" {...register("shipper_code")} 
                        disabled={isDisable}/>
                    </div>

                </div>
            </form>
        </div>
    )
}

export default UserDetails