import React, { useEffect, useState } from 'react'
import { BsGrid } from "react-icons/bs";
import { TfiViewList } from "react-icons/tfi";
import { IoAddSharp } from "react-icons/io5";
import { Button, Card, Form, Table } from 'react-bootstrap';
import "./PickupLocation.css";
import useHttps from '../../../hooks/useHttps';
import { ApiUrl } from '../../../shared/apiUrl';
import { AiOutlineDelete } from "react-icons/ai";
import { SlPencil } from "react-icons/sl";
import { HiOutlinePhone } from "react-icons/hi";
import { PICKUP_LOCATION_TABLE_HEADERS as headers } from '../constants';
import AddAddressModal from '../../shipments/AddAddressModal/AddAddressModal';
import InfiniteScroll from 'react-infinite-scroll-component';
import { useToast } from '../../../context/ToastContext';
import ConfirmationDialog from '../../../shared/ui/ConfirmationDialog';

const PickupLocation = () => {
  const { getRequest, getRequestWithoutLoader, patchRequest } = useHttps();
  const [index, setIndex] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [hasMore, setHasMore] = useState(true);
  const [pickupLocations, setPickupLocations] = useState([]);
  const [isGridEnabled, setIsGridEnabled] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [locationDialogTitle, setLocationDialogTitle] = useState("Add Pickup Location");
  const [pickupLocationData, setPickupLocationData] = useState(null);
  const { showSuccess, showError } = useToast();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteData, setDeleteData] = useState({});

  useEffect(() => {
    getPickupLocations();
  }, []);

  const getPickupLocations = async (isLoaderRequired) => {
    const query = `?page=${index}&page_size=${pageSize}`;
    if (isLoaderRequired) {
      const resp = await getRequest(ApiUrl.PICKUP_ADDRESS + query);
      handleResponse(resp)
    } else {
      /**
       * Avoid Loader for lazy loading
       */
      const resp = await getRequestWithoutLoader(ApiUrl.PICKUP_ADDRESS + query);
      handleResponse(resp);

    }
  }

  const handleResponse = (res) => {
    if (res && res.results && res.results.length) {
      setIndex(prevIndex => prevIndex + 1)
      setPickupLocations(prevData => [...prevData, ...res.results]);
    } else {
      setHasMore(false);
    }
  }

  const changeViewMode = () => {
    setIsGridEnabled(!isGridEnabled);
  }

  const handlePickupLocationFormData = (address) => {
    const updatedLocations = pickupLocations.map(location => {
      if (location.id === address.id) {
        return address;
      }
      return location;
    })
    setPickupLocations(updatedLocations);
    setShowModal(false);
  };

  const handleCloseModal = () => setShowModal(false);

  const handleAddNewLocation = () => {
    setShowModal(true);
  }

  const handleSwitchToggle = async (address) => {
    // update status
    const address_id = address.id;
    const req_body = {
      active: !address.active
    }
    const resp = await patchRequest(ApiUrl.PICKUP_ADDRESS + address_id + "/", req_body);
    if (resp && resp.message) {
      const updatedLocations = pickupLocations.map(location => {
        if (location.id === address.id) {
          location.active = !location.active
        }
        return location;
      })
      setPickupLocations(updatedLocations);
      showSuccess({ detail: resp.message })
    }
  }

  const deleteLocation = async (address) => {
    const req_body = {
      is_active: false // is used to soft deleted  a  location
    }
    const resp = await patchRequest(ApiUrl.PICKUP_ADDRESS + address.id + "/", req_body);
    if (resp && resp.message) {
      const filteredLocations = pickupLocations.filter(location => location.id === address.id ? false : true);
      // showSuccess({})
      setPickupLocations(filteredLocations);
      showSuccess({ detail: resp.message });
    }
  }

  const editLocation = (data) => {
    setPickupLocationData(data);
    setLocationDialogTitle("Edit Pickup Location");
    handlePickupLocationFormData(data)
    setShowModal(true);
    getPickupLocations(true);
  }

  const deleteButtonHandler = (data) => {
    setShowDeleteDialog(true);
    setDeleteData(data);
  }

  const onDeleteConfirmationCancel = () => {
    setShowDeleteDialog(false);
    setDeleteData({});
  }

  const onDeleteConfirmation = (data) => {
    setShowDeleteDialog(false);
    deleteLocation(data);
  }

  const ListView = () => (
    <div className='location-table' >
      <Table hover responsive className='h-full overflow-y-auto'>
        <thead className='py-2 border-b'>
          <tr className='header'>
            {
              headers.map(header => (
                <th key={header.field}>{header.label}</th>
              ))
            }
            <th key="actions" className='ml-3 action'>Action</th>
          </tr>
        </thead>
        <tbody>
          {
            pickupLocations.map(location => (
              <tr key={location.id} className='body py-3 border-b'>
                {
                  headers.map(header => (
                    <>
                      {
                        header.field === 'status' ? <td key={location.id + '_' + header.field} className='w-32'>
                          <Form.Check
                            type="switch"
                            id="custom-switch"
                            checked={location.active}
                            onChange={() => { handleSwitchToggle(location) }}
                            label={location.active ? 'Active' : 'Inactive'}
                          />
                        </td> :
                          <td key={location.id + '_' + header.field}> {location[header.field] ? location[header.field] : '--'}</td>
                      }


                    </>
                  ))
                }
                <td key={'actions_' + location.id}>
                  <div className='d-flex mb-2'>
                    <AiOutlineDelete className='actions w-5 h-5 cursor-pointer' title='Delete Location'
                      onClick={() => {
                        deleteButtonHandler(location)
                      }}
                    />
                    <SlPencil className='actions w-4 h-4 my-1 cursor-pointer' title='Edit Location' onClick={() => { editLocation(location) }} />
                  </div>
                </td>
              </tr>
            ))
          }
        </tbody>
      </Table>

    </div>
  )

  const GridView = () => (
    <div className='location-grid'>
      {
        pickupLocations.map(location => (
          <Card key={location.id} className="grid-card p-2">
            <div className='d-flex justify-content-between'>
              <p className='title'>{location.name}</p>
              <p className='gst-number'>GST: 22AAAAA0000A1Z5	</p>
            </div>
            <div className='text-left mt-1'>
              <p className='name'>{location.facility_name}</p>
              <p className='address'>{`${location.address_line_1} ${location.landmark} ${location.city} ${location.state}-${location.pincode}`}</p>
            </div>
            <div className='d-flex justify-content-start my-2'>
              <HiOutlinePhone className='w-4 h-4 ml-0 mr-2 mt-1' />
              <p>{location.phone_number}</p>
            </div>
            <div className='d-flex justify-content-between'>
              <p>
                <Form.Check
                  type="switch"
                  id="custom-switch"
                  checked={location.active}
                  onChange={() => { handleSwitchToggle(location) }}
                  label={location.active ? 'Active' : 'Inactive'}
                />
              </p>
              <div className='d-flex justify-content-end mb-2'>
                {/* <AiOutlineDelete className='actions w-5 h-5' title='Delete Location' onClick={() => { deleteLocation(location) }} /> */}
                <AiOutlineDelete className='actions w-5 h-5 cursor-pointer' title='Delete Location'
                  onClick={() => {
                    deleteButtonHandler(location)
                  }} />
                <SlPencil className='actions w-4 h-4 my-1 cursor-pointer' title='Edit Location' onClick={() => { editLocation(location) }} />
              </div>
            </div>

          </Card>
        ))
      }


    </div>
  )

  return (
    <div className='pickup-locations w-full'>
      <div className='d-flex justify-content-between w-full'>
        <div className='font-medium'>Pickup Location</div>
        <div className='d-flex justify-content-end mb-3'>
          {
            isGridEnabled ? <TfiViewList title='Change to List View' onClick={changeViewMode} className='mx-3 my-2 w-5 h-5 cursor-pointer' /> : <BsGrid title='Change to Grid View' onClick={changeViewMode} className='mx-3 my-2 w-5 h-5 cursor-pointer' />
          }


          <Button variant="light" size="sm" className="shadow-md"
            onClick={handleAddNewLocation}>
            <IoAddSharp className='inline w-5 h-5' /> Add Location</Button>
        </div>
      </div>
      <div id='scrollable' style={{ maxHeight: '65vh', overflowY: 'auto' }} className='pr-3'>

        <InfiniteScroll
          scrollableTarget="scrollable"
          dataLength={pickupLocations.length}
          next={() => {
            console.log('infinite scroll')
            getPickupLocations()
          }}
          hasMore={hasMore}
          loader={<p className="dot-loader">Loading<span className="dot">.</span><span className="dot">.</span><span className="dot">.</span></p>
          }
          endMessage={
            pickupLocations.length === 0 ? <p className='no-data'>No Record</p> : <p></p>
          }
        >
          {
            isGridEnabled ? <GridView /> : <ListView />
          }
          {
            showDeleteDialog && <ConfirmationDialog
              showDialog={showDeleteDialog}
              data={deleteData}
              dialogTitle="Delete Confirmation"
              description="Are you sure, you want to delete this location?"
              closeButtonLabel="Cancel"
              ConfirmButtonLabel="Delete"
              onConfirmation={onDeleteConfirmation}
              onCancel={onDeleteConfirmationCancel} />
          }

        </InfiniteScroll>
        {
          showModal &&
          <AddAddressModal
            addressData={pickupLocationData}
            showModal={showModal}
            handleClose={handleCloseModal}
            handleFormData={handlePickupLocationFormData}
            addressType="pickup"
            title={locationDialogTitle}
          />
        }
      </div>
    </div>
  )
}

export default PickupLocation