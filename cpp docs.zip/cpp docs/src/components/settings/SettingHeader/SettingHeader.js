import Wallet from "../../dashboard/wallet/Wallet";
import infoIcon from "../../../assets/images/info-small.svg"
import "./SettingHeader.css";

const SettingHeader = (props) => {
    let menu = props.menu;
    return (
        <div className="d-flex justify-content-between">
            <div className="info">
                <img className="" src={infoIcon} alt="info"/>
                {menu.content}
            </div>
            <div className="setting-wallet">
            {
                menu.showWallet ? <Wallet isDashboard={false}/> : <></>
            }
            </div>
            
        </div>
    )

}

export default SettingHeader;