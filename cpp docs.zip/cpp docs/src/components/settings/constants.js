import Api from "./api/Api";
import CompanyDetails from "./companydetails/CompanyDetails";
import Invoice from "./invoice/Invoice";
import PickupLocation from "./pickuplocation/PickupLocation";
import Pincode from "./pincode/Pincode";
import ProductCatalogue from "./productcatalogue/ProductCatalogue";
import Statements from "./statements/Statements";
import UserDetails from "./userdetails/UserDetails";
import validLocation from "../../assets/images/active_location_outline.svg"
import invalidLocation from "../../assets/images/off_location_outline.svg"
import ShipmentLabel from "./ShipmentLabel/ShipmentLabel";

export const SETTING_MENUS = [
  {
    id: 'userdetails',
    label: 'User Details',
    content: 'On this page, you have the ability to modify your contact information and review all other relevant details.',
    src: <UserDetails />,
    link: 'user-details',
    showWallet: false
  },
  {
    id: 'companydetails',
    label: 'Company Details',
    content: 'On this page, you have the ability to modify your company details and review all other relevant details.',
    src: <CompanyDetails />,
    link: 'company-details',
    showWallet: false
  },
  {
    id: 'statements',
    label: 'Statements',
    content: 'On this page, You can check transactions and review all other relevant details.',
    src: <Statements />,
    link: 'statements',
    showWallet: true
  },
  {
    id: 'invoice',
    label: 'Invoice',
    content: 'On this page, You can download the monthly invoice.',
    src: <Invoice />,
    link: 'invoice',
    showWallet: false
  },
  {
    id: 'api',
    label: 'API',
    content: 'On this page, You can Generate API key.',
    src: <Api />,
    link: 'api',
    showWallet: false
  },
  {
    id: 'pincode',
    label: 'Pincode',
    content: 'On this page, You can check pincode Serviceability & Embargo.',
    src: <Pincode />,
    link: 'pincode',
    showWallet: false
  },
  {
    id: 'shipmentlabel',
    label: 'Manage Shipment Label',
    content: 'On this page, you can edit the format of the labels that are most suitable for your company.',
    src: <ShipmentLabel />,
    link: 'shipment-label',
    showWallet: false
  },
  {
    id: 'pickuplocation',
    label: 'Manage Pickup Location',
    content: 'On this page, You can add and remove the pickup location.',
    src: <PickupLocation />,
    link: 'pickup-location',
    showWallet: false
  },
  {
    id: 'productcatalogue',
    label: 'Manage Product Catalogue',
    content: 'On this page, You can add and remove the product.',
    src: <ProductCatalogue />,
    link: 'product-catalogue',
    showWallet: false
  },
];

export const PINCODES_DOWNLOAD_CARDS = [
  {
    id: "serviceability",
    label: "Pincode Serviceability",
    icon: validLocation,
    iconLabel: "valid location",
    description: "Pincode serviceability refers to a service provider's ability to reach a specific area"
  },
  {
    id: "embargo",
    label: "Pincode Embargo",
    icon: invalidLocation,
    iconLabel: "invalid location",
    description: "Pincode embargo refers to restrictions or limitations imposed on a specific postal code "
  },
]

export const VALID_PINCODE_DETAIL = {
  message: "Pincode is serviceable",
  description: "",
  pincode: "609608",
  location: "Ubayavedanthapuram, Thiruvarur, Tamil Nadu",
  services: [
    {
      name: "Pick-up",
      status: "Yes",
      info: ""
    },
    {
      name: "Delivery",
      status: "Yes",
      info: ""
    },
    {
      name: "Return",
      status: "Yes",
      info: ""
    }
  ]
};

export const INVALID_PINCODE_DETAIL = {
  message: "Pincode is restricted",
  description: "From 17 Oct, 2023 till 23 Oct,2023",
  pincode: "385535",
  location: "Baiwada, Banaskantha, Gujarat",
  services: [
    {
      name: "Pick-up",
      status: "No",
      info: ""
    },
    {
      name: "Delivery",
      status: "No",
      info: ""
    },
    {
      name: "Return",
      status: "No",
      info: ""
    }
  ]
}

export const PICKUP_LOCATION_TABLE_HEADERS = [
  { 'field': 'status', 'label': 'Status' },
  { 'field': 'facility_name', 'label': 'Facility Name' },
  { 'field': 'address_line_1', 'label': 'Address' },
  { 'field': 'city', 'label': 'City' },
  { 'field': 'pincode', 'label': 'Pincode' },
  { 'field': 'phone_number', 'label': 'Mobile' },
  // { 'field': 'gst_no', 'label': 'GST No.' },
  // { 'field': 'invoice_number', 'label': 'Invoice Number' }

]

export const PRODUCT_TABLE_HEADERS = [
  { 'field': 'name', 'label': 'Product Name' },
  { 'field': 'category', 'label': 'Catagory' },
  { 'field': 'hsn_code', 'label': 'HSN code' },
  { 'field': 'price', 'label': 'Price (₹)' },
  { 'field': 'tax_type', 'label': 'Tax Type' },
  { 'field': 'discount', 'label': 'Discount' },
  { 'field': 'is_dangerous_goods', 'label': 'Type' },
]

export const BUSINESS_TYPE = [
  {key: "proprietorship", label:"PROPRIETORSHIP"},
  {key: "llp", label:"LLP"},
  {key: "partnership", label:"PARTNERSHIP"},
  {key: "public", label:"PUBLIC"},
  {key: "private", label:"PRIVATE"},
]

