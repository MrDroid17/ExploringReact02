import React, { useEffect, useState } from 'react'
import { Button, Card, Form, Table } from 'react-bootstrap';
import "./ProductCatalogue.css";
import useHttps from '../../../hooks/useHttps';
import { BsGrid } from "react-icons/bs";
import { TfiViewList } from "react-icons/tfi";
import { IoAddSharp } from "react-icons/io5";
import { ApiUrl } from '../../../shared/apiUrl';
import { AiOutlineDelete } from "react-icons/ai";
import { SlPencil } from "react-icons/sl";
import { PRODUCT_TABLE_HEADERS as headers } from '../constants';
import InfiniteScroll from 'react-infinite-scroll-component';
import imagePlaceholder from "../../../assets/images/image_placeholder.svg";
import rupeeTag from "../../../assets/images/rupee_tag.svg";
import taxTag from "../../../assets/images/tax_tag.svg";
import AddProductModal from '../../shipments/AddProductModal/AddProductModal';
import ConfirmationDialog from '../../../shared/ui/ConfirmationDialog';
import { useToast } from '../../../context/ToastContext';


const ProductCatalogue = () => {
  const { getRequest, getRequestWithoutLoader, deleteRequest, patchRequest } = useHttps();
  const [index, setIndex] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [hasMore, setHasMore] = useState(true);
  const [products, setProducts] = useState([]);
  const [isGridEnabled, setIsGridEnabled] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [productDialogTitle, setProductDialogTitle] = useState("Add Product");
  const [productData, setProductData] = useState(null);
  const { showSuccess, showError } = useToast();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteData, setDeleteData] = useState({});

  useEffect(() => {
    getProducts(true);
  }, []);

  const getProducts = async (isLoaderRequired) => {
    const query = `?page=${index}&page_size=${pageSize}`;
    if (isLoaderRequired) {
      const resp = await getRequest(ApiUrl.PRODUCTS + query);
      handleResponse(resp)
    } else {
      /**
       * Avoid Loader for lazy loading
       */
      const resp = await getRequestWithoutLoader(ApiUrl.PRODUCTS + query);
      handleResponse(resp);
    }
  }

  const handleResponse = (res) => {
    if (res && res.results && res.results.length) {
      setIndex(prevIndex => prevIndex + 1)
      setProducts(prevData => [...prevData, ...res.results]);
    } else {
      setHasMore(false);
    }
  }

  const changeViewMode = () => {
    setIsGridEnabled(!isGridEnabled);
  }

  const handleProductFormData = (data) => {
    setShowModal(false);
    getProducts();
  };

  const handleCloseModal = () => setShowModal(false);

  const handleAddNewProduct = () => {
    setProductData({});
    setShowModal(true);
  }

  const deleteProduct = async (product) => {
    const req_body = {
      is_active: false // is used to soft deleted  a  location
    }
    const resp = await patchRequest(ApiUrl.PRODUCTS + product.id + "/", req_body);
    if (resp && resp.message) {
      const filteredproducts = products.filter(prod => prod.id === product.id ? false : true);
      setProducts(filteredproducts);
      showSuccess({ detail: resp.message });
    }
  }

  const deleteButtonHandler = (data) => {
    setShowDeleteDialog(true);
    setDeleteData(data);
  }

  const onDeleteConfirmationCancel = () => {
    setShowDeleteDialog(false);
    setDeleteData({});
  }

  const onDeleteConfirmation = (data) => {
    setShowDeleteDialog(false);
    deleteProduct(data);
  }

  const editProduct = (data) => {
    setProductData(data);
    setProductDialogTitle("Edit Product");
    handleProductFormData(data)
    setShowModal(true);
    getProducts(false);
  }

  const ListView = () => (
    <div className='product-table' >
      <Table hover responsive className='h-full overflow-y-auto'>
        <thead className='py-2 border-b'>
          <tr className='header'>
            <th className='ml-3 image'>Image</th>
            {
              headers.map(header => (
                <th key={header.field}>{header.label}</th>
              ))
            }
            <th className='ml-3 action'>Action</th>
          </tr>
        </thead>
        <tbody>
          {
            products.map(product => (
              <tr key={product.id} className='body py-3 border-b'>
                <td>
                  <div>
                    <img src={product.image_url ? product.image_url : imagePlaceholder} alt="Product Image" className='product-img' />
                  </div>
                </td>
                {
                  headers.map(header => (
                    <>
                      {
                        header.field === 'is_dangerous_goods' ?
                          <td key={product.id + '_' + header.field}>
                              <p className={product.is_dangerous_goods ? 'dangerous-goods mt-3 w-[130px]' : ''}>
                                {product.is_dangerous_goods ? "Dangerous Goods" : ""}
                              </p>
                              <p className={product.is_essential_goods ? 'essential-goods mt-3 w-[130px]' : ''}>
                                {product.is_essential_goods ? "Essential Goods" : ""}
                              </p>
                          </td>
                          :
                          <td key={product.id + '_' + header.field} className='content-center'> {product[header.field] ? product[header.field] : '--'}</td>
                      }


                    </>
                  ))
                }
                <td>
                  <div className='d-flex mb-2'>
                    <AiOutlineDelete className='actions w-5 h-5 mt-4 cursor-pointer' title='Delete Product'
                      onClick={() => {
                        deleteButtonHandler(product)
                      }} />
                    <SlPencil className='actions w-4 h-4 my-1 mt-4 cursor-pointer' title='Edit Product' onClick={() => { editProduct(product) }} />
                  </div>
                </td>
              </tr>
            ))
          }
        </tbody>
      </Table>
    </div>
  )

  const GridView = () => (
    <div className='product-grid'>
      {
        products.map(product => (
          <Card key={product.id} className="grid-card p-2">
            <div className='d-flex justify-content-between'>
              <p className='hsn-code'>HSN Code: {product.hsn_code}</p>
              <p className='discount'>Discount {product.discount}%	</p>
            </div>
            <div className='text-left mt-1'>
              <p className='category'>{product.category}</p>
              <div className='d-flex justify-content-start'>
                <img src={product.image_url ? product.image_url : imagePlaceholder} alt="Product Image" className='product-img' />
                <div className='ml-2'>
                  <p className='name'>{product.name}</p>
                  <p className='d-flex justify-content-start mr-3'>
                    <div className='d-flex mr-2'><img src={rupeeTag} alt="Rupee Tag" /> {product.price}</div>
                    <div className='d-flex mr-2'><img src={taxTag} alt="Rupee Tag" /> {product.tax_type}</div>
                  </p>
                </div>
              </div>
            </div>
            <div className='d-flex justify-content-between mt-2'>
              <p className='d-flex justify-start'>
                <span className={product.is_dangerous_goods ? 'dangerous-goods' : ''}>
                  {product.is_dangerous_goods ? "Dangerous Goods" : ""}
                </span>
                <span className={product.is_essential_goods ? 'essential-goods' : ''}>
                  {product.is_essential_goods ? "Essential Goods" : ""}
                </span>
              </p>
              <div className='d-flex justify-content-end mb-2'>
                <AiOutlineDelete className='actions w-5 h-5 cursor-pointer' title='Delete Product'
                  onClick={() => {
                    deleteButtonHandler(product)
                  }} />
                <SlPencil className='actions w-4 h-4 my-1 cursor-pointer' title='Edit Product' onClick={() => { editProduct(product) }} />
              </div>
            </div>
          </Card>
        ))
      }

    </div>
  )

  return (
    <div className='products w-full'>
      <div className='d-flex justify-content-between w-full'>
        <div className='font-medium'>Product</div>
        <div className='d-flex justify-content-end mb-3'>
          {
            isGridEnabled ? (
              <TfiViewList title='Change to List View' onClick={changeViewMode} className='mx-3 my-2 w-5 h-5 cursor-pointer' />
            ) : (
              <BsGrid title='Change to Grid View' onClick={changeViewMode} className='mx-3 my-2 w-5 h-5 cursor-pointer' />
            )
          }


          <Button variant="light" size="sm" className="shadow-md"
            onClick={handleAddNewProduct}>
            <IoAddSharp className='inline w-5 h-5' /> Add Product</Button>
        </div>
      </div>
      <div id='scrollable' style={{ maxHeight: '65vh', overflowY: 'auto' }}>

        <InfiniteScroll
          scrollableTarget="scrollable"
          dataLength={products.length}
          next={() => {
            console.log('infinite scroll')
            getProducts()
          }}
          hasMore={hasMore}
          loader={<p className="dot-loader">Loading<span className="dot">.</span><span className="dot">.</span><span className="dot">.</span></p>
          }
          endMessage={
            products.length === 0 ? <p className='no-data'>No Record</p> : <p></p>
          }
        >
          {
            isGridEnabled ? <GridView /> : <ListView />
          }
          {
            showDeleteDialog && <ConfirmationDialog
              showDialog={showDeleteDialog}
              data={deleteData}
              dialogTitle="Delete Confirmation"
              description="Are you sure, you want to delete this product?"
              closeButtonLabel="Cancel"
              ConfirmButtonLabel="Delete"
              onConfirmation={onDeleteConfirmation}
              onCancel={onDeleteConfirmationCancel} />
          }
        </InfiniteScroll>
        {
          showModal &&
          <AddProductModal
            productData={productData}
            showModal={showModal}
            handleClose={handleCloseModal}
            handleSubmitForm={handleProductFormData}
            title={productDialogTitle}
          />
        }
      </div>
    </div>
  )
}

export default ProductCatalogue