import React, { useEffect, useState } from 'react'
import { Button, Form, InputGroup } from 'react-bootstrap';
import eyeOpenIcon from '../../../assets/images/eye_open.svg';
import eyeCloseIcon from '../../../assets/images/eye-off.svg';
import './Api.css';

const Api = () => {
  const [isKeyGenerated, setIsKeyGenerated] = useState(false);
  const [isKeyVisible, setIsKeyvisible] = useState(false);
  const [maskedKey, setMaskedKey] = useState('');
  const [apiKey, setApiKey] = useState("");

  const generateApiKey = () => {
    const newApiKey = 'API_KEYAZx' + Math.random().toString(36).slice(1, 35);
    setApiKey(newApiKey);
    console.log("generating key.....", newApiKey);
    setIsKeyGenerated(true);
    showHidekey();
  }
  const showHidekey = () => {
    setIsKeyvisible(!isKeyVisible);
    /**
     * Masked the API key post 5 min
     */
    if(isKeyVisible){     
      setTimeout(() => {
        setIsKeyvisible(false); 
      }, 300000);
    }
    setMaskedKey('*'.repeat(apiKey.length)); 
  };

  return (
    <div className='api border-1 border-slate-400 p-4 rounded-md'>
      <p className='mb-1 text-lg font-medium'>Generate an API Key for your application</p>
      <p className='text-xs font-light text-slate-400 mb-1'>Ecom provide API's to cover every business process involved to automate the whole life cycle of a shipment starting from manifestation until its closure. In order to test and use these API's, customers must get the UAT API credentials from the team and get their respective UAT server static IP's whitelisted. For setting this up, customers are requested to get in touch with Ecom IT team at <a href=''>software.support@ecomexpress.in</a></p>

      <div className='flex gap-2 mb-3'>
        <p className='mb-0 content-center'>Learn about API Keys in our</p>
        <Button className='shadow-md' variant="light">Api Documentation</Button>
      </div>
      {
        isKeyGenerated ? <div className='p-3 bg-slate-100 rounded-md border-1 border-slate-300'>
          <p>Generated API Key</p>
          <div className='d-flex justify-content-start api-key-container'>
            <InputGroup className='d-flex justify-content-end api-key-input !w-[50%] h-full rounded-md border-slate-300 border-2 mr-2'
            >
              <Form.Control
                value={isKeyVisible ? apiKey : maskedKey}
                type="text"
                disabled={true}
                placeholder=""
                aria-label="Recipient's username"
                aria-describedby="basic-addon2"
                className='h-full api-key-input'
              />

              <img className="mx-1 my-1 p-1" onClick={showHidekey} src={isKeyVisible ? eyeOpenIcon : eyeCloseIcon} alt="eye-open" />
              <Button className='copy-button btn-secondary' disabled={!isKeyVisible} onClick={()=>{
                    navigator.clipboard.writeText(apiKey).then(() => {
                      alert('Text copied to clipboard!');
                    }).catch(err => {
                      alert('Failed to copy text: ' + err);
                    }); 
              }}>Copy</Button>
            </InputGroup>

            <button className='bg-pink-600 text-white p-2 rounded-md' onClick={generateApiKey} >Generate New API Key</button>
          </div>
        </div> :
          <div className='p-3 bg-slate-100 rounded-md border-1 border-slate-300'>
            <button className='bg-pink-600 text-white p-2 rounded-md' onClick={generateApiKey}>Generate API Key</button>
          </div>
      }



      <p className='text-md font-medium my-2'>Important Instructions</p>
      <ul className='list-decimal font-light text-slate-500 pl-5 space-y-1 text-sm'>
        <li>Once you generate a new Token, your old token will stop working immediately</li>
        <li>Once you generate your token, it will be visible for 5 minutes and then will be hidden from view</li>
        <li>To protect your data, you'll only be able to reveal your API token once.</li>
        <li>Copy and save your API token in a secure place.</li>
      </ul>
    </div>
  )
}

export default Api