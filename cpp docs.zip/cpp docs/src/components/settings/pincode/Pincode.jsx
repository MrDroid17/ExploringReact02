import React, { useState } from 'react'
import { Button, Card, Form } from 'react-bootstrap';
import closeIcon from '../../../assets/images/ic_close.svg';
import "./Pincode.css";
import { PINCODES_DOWNLOAD_CARDS as downloadCards, INVALID_PINCODE_DETAIL, VALID_PINCODE_DETAIL } from '../constants';
import infoIcon from "../../../assets/images/info-small.svg";

const Pincode = () => {
    let default_detail = {
        message: '',
        description: '',
        pincode: '',
        location: '',
        services: [],
    }
    const [pincode, setPincode] = useState("");
    const [pincodeDetail, setPincodeDetail] = useState(default_detail);
    const [showCancel, setShowCancel] = useState(false);
    const clearPincode = () => {
        setPincode("");
        setShowCancel(false);
        setPincodeDetail(default_detail);
    }

    const checkPincode = () => {
        setShowCancel(true);
        if (pincode && pincode === "609608") {
            setPincodeDetail(VALID_PINCODE_DETAIL);
        } else if (pincode && pincode === "385535") {
            setPincodeDetail(INVALID_PINCODE_DETAIL);
        } else {
            setPincodeDetail(default_detail);
        }
    }

    const handlePincodeChange = (e) => {
        setPincode(e.target.value);
    }

    const downloadPincodes = (download_type) => {
        console.log("Pincode Download type  ======> ", download_type);
    }

    const PincodeDetailSection = () => (
        <div className='pincode-details'>
            <p className={pincodeDetail.description ? 'pincode-msg invalid-pincode' : 'pincode-msg valid-pincode'}>{pincodeDetail.message}</p>
            {
                pincodeDetail.description ? <p className='pincode-desc'>{pincodeDetail.description}</p> : ''
            }
            <div className='pincode'>{pincodeDetail.pincode}</div>
            <div className='location'>{pincodeDetail.location}</div>

            <div className='services'>
                {
                    pincodeDetail.services.map(service => (
                        <div className='d-flex justify-content-between px-3 border-b border-slate-300 mt-3'>
                            <div className='d-flex justify-content-start'>
                                <div>{service.name}</div>
                                <img src={infoIcon} alt="info-icon" />
                            </div>
                            <div>
                                {service.status}
                            </div>
                        </div>
                    ))
                }
            </div>
        </div>
    )

    const CheckPincodeContainer =() => (
        <div className="w-full">
            <Form.Label htmlFor="checkPincode" className="text-sm-dark d-flex align-items-center">
                Check Pincode Serviceability
            </Form.Label>
            <div className="pincode-input-container">
                <Form.Control
                    type="text"
                    id="checkPincode"
                    placeholder="Enter Pincode and City"
                    className='pincode-input'
                    value={pincode}
                    onChange={handlePincodeChange}
                    pattern='[0-9A-Za-z]'
                />
                {showCancel ? <img className='close-icon' src={closeIcon} alt="close-icon" onClick={clearPincode} /> : <></>}
                <Button variant="light" size='sm' className='check-btn shadow-sm' onClick={checkPincode}>Check</Button>
            </div>
            <p className='ml-1 mt-1 mb-3 text-xs text-slate-400'>Using this tool you can check single pincode Serviceability.</p>
        </div>
    );

    const DownloadSection = () => (
        <div className='download-section'>
            Download
            {
                downloadCards.map(card => {
                    return (
                        <Card key={card.id} className='download-card'>
                            <Card.Body>
                                <div className='header'>
                                    <img className="mr-2" src={card.icon} alt={card.iconLabel} />
                                    <div>{card.label}</div>
                                </div>
                                <p className='body'>{card.description}</p>
                                <button className='footer' onClick={() => downloadPincodes(card.id)}>Download</button>
                            </Card.Body>
                        </Card>
                    )
                })
            }

        </div>
    )

    return (
        <div className='pincodes d-flex justify-content-between w-full'>
            <div className="w-[40%]">
                {   /* check pincode container */
                    <CheckPincodeContainer/>
                }

                {
                    /* Pincode details section   */
                    (pincodeDetail && pincodeDetail.pincode) ? <PincodeDetailSection/> : <></>
                }
            </div>
            {
                /* Download Section */
                <DownloadSection/>
            }
        </div>
    )
}

export default Pincode