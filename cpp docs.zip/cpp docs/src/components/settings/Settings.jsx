import React, { useEffect, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import './Settings.css';
import SettingSidebar from './SettingSidebar/SettingSidebar';
import SettingHeader from './SettingHeader/SettingHeader';
import { SETTING_MENUS } from './constants';

const Settings = () => {
  const activate_route = useLocation();
  const [activatedMenu, setActivatedMenu] = useState(SETTING_MENUS[0]);

  useEffect(()=>{
    const endpoint = activate_route['pathname'].split("/");
    const filteredMenu = SETTING_MENUS.filter(menu => endpoint[endpoint.length-1] === menu.link);
    setActivatedMenu(filteredMenu[0]);
  }, [activate_route]);

  
  return (
      <>
          <div className='setting'>  
              <div className="setting-sidebar">
                  <div className='setting-label'>
                    Settings
                  </div>
                  <div className='sidebar-container'>
                    <SettingSidebar/>
                  </div>
              </div>
              <div className='setting-body'>
                <SettingHeader  className="" menu={activatedMenu}/>
                <div >
                    <div className='main-body-content'>
                        <Outlet/>
                    </div>
                </div>
              </div>
          </div>
      </>
  );
  
};

export default Settings;
