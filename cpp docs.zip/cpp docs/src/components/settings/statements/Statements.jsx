import React, { useState } from 'react'
import { Table, Pagination, InputGroup, DropdownButton, Dropdown, Form } from 'react-bootstrap'
import searchImage from '../../../assets/images/ic_search.svg';
import refreshIcon from '../../../assets/images/refresh.svg';
import downloadIcon from '../../../assets/images/download.svg';
import calenderIcon from '../../../assets/images/calender.svg';
import "./Statements.css";
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";


const Statements = () => {
  const [dateRange, setDateRange] = useState([null, null]);
  const [startDate, endDate] = dateRange;

  const statementTableColumn = [
    { name: 'Transaction Id', field: "transaction_id" },
    { name: 'Date', field: "date" },
    { name: 'Category', field: "category" },
    { name: 'AWB & order Id', field: "awb_order_id" },
    { name: 'Description', field: "description" },
    { name: 'Amount', field: "amount" },
    { name: 'Balance', field: "balance" }
  ];
  const dummyData = [
    {
      transaction_id: "100jnjnnbbbbb34h3vh4-bjhjhjhb-bjgjgjgcxfxfxf",
      date: "Sep 29, 2024 10:04",
      category: "return Debit",
      awb_order_id: 'hsjhgjsghdgjs jhjj',
      description: 'rettune  shipment order',
      amount: 456,
      balance: 560
    },
    {
      transaction_id: "100jnjnnbbbbb34h3vh4-bjhjhjhb-bjgjgjgcxfxfxf",
      date: "Sep 29, 2024 10:04",
      category: "return Debit",
      awb_order_id: 'hsjhgjsghdgjs jhjj',
      description: 'rettune  shipment order',
      amount: 456,
      balance: 560
    },
    {
      transaction_id: "100jnjnnbbbbb34h3vh4-bjhjhjhb-bjgjgjgcxfxfxf",
      date: "Sep 29, 2024 10:04",
      category: "return Debit",
      awb_order_id: 'hsjhgjsghdgjs jhjj',
      description: 'rettune  shipment order',
      amount: 456,
      balance: 560
    },
    {
      transaction_id: "100jnjnnbbbbb34h3vh4-bjhjhjhb-bjgjgjgcxfxfxf",
      date: "Sep 29, 2024 10:04",
      category: "return Debit",
      awb_order_id: 'hsjhgjsghdgjs jhjj',
      description: 'rettune  shipment order',
      amount: 456,
      balance: 560
    },
    {
      transaction_id: "100jnjnnbbbbb34h3vh4-bjhjhjhb-bjgjgjgcxfxfxf",
      date: "Sep 29, 2024 10:04",
      category: "return Debit",
      awb_order_id: 'hsjhgjsghdgjs jhjj',
      description: 'rettune  shipment order',
      amount: 456,
      balance: 560
    },
    {
      transaction_id: "100jnjnnbbbbb34h3vh4-bjhjhjhb-bjgjgjgcxfxfxf",
      date: "Sep 29, 2024 10:04",
      category: "return Debit",
      awb_order_id: 'hsjhgjsghdgjs jhjj',
      description: 'rettune  shipment order',
      amount: 456,
      balance: 560
    },
    {
      transaction_id: "100jnjnnbbbbb34h3vh4-bjhjhjhb-bjgjgjgcxfxfxf",
      date: "Sep 29, 2024 10:04",
      category: "return Debit",
      awb_order_id: 'hsjhgjsghdgjs jhjj',
      description: 'rettune  shipment order',
      amount: 456,
      balance: 560
    },
    {
      transaction_id: "100jnjnnbbbbb34h3vh4-bjhjhjhb-bjgjgjgcxfxfxf",
      date: "Sep 29, 2024 10:04",
      category: "return Debit",
      awb_order_id: 'hsjhgjsghdgjs jhjj',
      description: 'rettune  shipment order',
      amount: 456,
      balance: 560
    }
  ];
  return (
    <div className='statement border-b border-slate-300 w-full'>
      <div className='d-flex justify-content-between mb-2 w-full'>
        <div className="input-container">
          <InputGroup className="w-400">
            <DropdownButton
              variant="outline-dark"
              title="AWB & Order Id"
              id="input-group-dropdown-1"
            >
              <Dropdown.Item href="#">AWB & Order Id</Dropdown.Item>
              <Dropdown.Item href="#">Transaction Id</Dropdown.Item>
            </DropdownButton>
            <Form.Control aria-label="Text input with dropdown button" placeholder="Search" className='statement search-input'/>
          <img className="statement search-icon" src={searchImage} alt="search icon" />
          </InputGroup>
        </div>
        <div className='d-flex justify-content-end'>

          <DatePicker className='react-datepicker-for-range'
            // icon={<img src={calenderIcon}></img>}
            // calendarIconClassName="calender-icon"
            // showIcon={true}
            selectsRange={true}
            startDate={startDate}
            endDate={endDate}
            onChange={(update) => {
              setDateRange(update);
               }}
            // isClearable={true}
            />
          <img className="w-6 mx-3 w-5 z-1" src={calenderIcon} alt="calender icon" />
          <img className="w-6 ml-2" src={downloadIcon} alt="download icon" />
          <img className="w-6 mx-3" src={refreshIcon} alt="refresh icon" />
        </div>
      </div>
      <div className='statement-table' style={{ width: '1080px' }}>
        <Table striped bordered hover>
          <thead>
            <tr>
              {
                statementTableColumn.map(col => <th key={col.field}>{col.name}</th>)
              }

            </tr>
          </thead>
          <tbody>
            {
              dummyData.map((statement, rowIndex) => (
                <tr key={rowIndex}>
                  {statementTableColumn.map((col) => <td key={col.field}>{statement[col.field]}</td>
                  )}
                </tr>
              ))}
          </tbody>
        </Table>
      </div>
      <div className='d-flex justify-content-end'>
        <Pagination>
          <Pagination.First />
          <Pagination.Prev />
          <Pagination.Item>{1}</Pagination.Item>
          <Pagination.Ellipsis />

          <Pagination.Item>{10}</Pagination.Item>
          <Pagination.Item>{11}</Pagination.Item>
          <Pagination.Item active>{12}</Pagination.Item>
          <Pagination.Item>{13}</Pagination.Item>
          <Pagination.Item disabled>{14}</Pagination.Item>

          <Pagination.Ellipsis />
          <Pagination.Item>{20}</Pagination.Item>
          <Pagination.Next />
          <Pagination.Last />
        </Pagination>

      </div>
    </div>
  )
}

export default Statements