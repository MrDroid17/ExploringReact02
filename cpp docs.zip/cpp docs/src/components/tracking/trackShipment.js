import { useEffect, useState } from "react";
import './trackShipment.css'
import { Badge, Button, Card, CardGroup, Container, Row, Stack } from "react-bootstrap";
import useHttps from "../../hooks/useHttps";
import { ApiUrl } from "../../shared/apiUrl";
import { useParams } from "react-router-dom";


function TrackShipment(props) {
    const { awb } = useParams();
    const [shipmentDetails, setShipmentDetails] = useState(null);
    const [shipmentJourney, setShipmentJourney] = useState(null);
    const { getRequest, postRequest } = useHttps();

    const getShipmentDetails = async () => {
        //const awb = 715587140
        const resp = await getRequest(ApiUrl.TRACK_SHIPMENT_DETAIL + "?awb=" + awb);
        console.log(resp);
        setShipmentDetails(resp?.data || null)
    }
    const getShipmentJourney = async () => {
        const resp = await getRequest(ApiUrl.TRACK_SHIPMENT_JOURNEY + "?awb=" + awb);
        console.log(resp);
        setShipmentJourney(resp?.data || null)
    }

    useEffect(() => {
        if (awb) {
            getShipmentDetails()
            getShipmentJourney()
        }
    }, [])

    return (
        <Card border="light" className="parent-card">
            <Card.Body className="parent-card-body">
                {
                    shipmentDetails && shipmentJourney ?
                        <>
                            <div className="grid-a">
                                <Stack className="badge-stack" direction="horizontal" gap={2} >
                                    <Badge className="badge badge-status" pill bg="none">{shipmentDetails?.package_details?.shipmentdetails_response.status || ""}</Badge>
                                    <Badge className="badge badge-order-date" pill bg="none">Ordered On: May 19, 2024</Badge>
                                    <Badge className="badge badge-shipping-type" pill bg="none">Icon Surface</Badge>
                                </Stack>
                                <Card border="secondary" >
                                    <Card.Body>
                                        <div className="heading">Package Details</div>
                                        <div className="package row-auto-space">
                                            <div className="pkg-title-subtitle">
                                                <div className="title subheading">{shipmentDetails?.package_details?.shipmentdetails_response.item_description || ""}</div>

                                            </div>
                                            <div className="pkg-price-tax">
                                                <div className="price subheading">&#8377; {shipmentDetails?.package_details?.shipmentdetails_response.declared_value || ""}</div>
                                                {/* <div className="tax body-text">Tax@&#8377; 18.00|18%</div> */}
                                            </div>
                                            <div className="pkg-quantity">
                                                <div className="quantity subheading">{shipmentDetails?.package_details?.shipmentdetails_response?.quantity || "0"}</div>
                                            </div>
                                            {/* <div className="pkg-disc-per">
                                    <div className="disc-amt subheading">&#8377; 0.00</div>
                                    <div className="disc-per body-text">0% off</div>
                                </div> */}
                                        </div>
                                    </Card.Body>
                                </Card>
                                <div className="parent-card pt10 row-auto-space">
                                    <Card className="grid-c" border="secondary">
                                        <Card.Body>
                                            <div className="heading">Delivery Details</div>
                                            <div className="pt10 pb5 fw400 fs14">Pickup Address</div>
                                            <Card className="grid-e bg-grey" border="secondary">
                                                <Card.Body>
                                                    <div className="subheading">{shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.name || ""}</div>
                                                    <div className="body-text">
                                                        {shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.address1 + ", " || ""}
                                                        {(shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.address2 && shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.address2 + ", ") || ""}
                                                        {(shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.address3 && shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.address3 + ", ") || ""}
                                                        {(shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.address4 && shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.address4 + ", ") || ""}
                                                        {shipmentDetails?.pickup_details?.shipperdetails_response?.SubShipperDetails.pin_code || ""}
                                                    </div>
                                                </Card.Body>
                                            </Card>
                                            <div className="pt10 pb5 fw400 fs14">Delivery Address</div>
                                            <Card className="grid-e bg-grey" border="secondary">
                                                <Card.Body>
                                                    <div className="subheading">{shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.name || ""}</div>
                                                    <div className="body-text">
                                                        {shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.address1 + ", " || ""}
                                                        {(shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.address2 && shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.address2 + ", ") || ""}
                                                        {(shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.address3 && shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.address3 + ", ") || ""}
                                                        {(shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.address4 && shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.address4 + ", ") || ""}
                                                        {shipmentDetails?.delivery_details?.consigneedetails_response?.ConsigneeDetails.pin_code || ""}
                                                    </div>
                                                </Card.Body>
                                            </Card>
                                        </Card.Body>
                                    </Card>
                                    <Card className="grid-d" border="secondary">
                                        <Card.Body>
                                            <div className="row-auto-space">
                                                <div className="heading">Payment Details</div>
                                                <Button className="btn-bg-light" variant="light" size="sm">Print Invoice</Button>
                                            </div>
                                            <div className="row-auto-space">
                                                <div className="pt10 pb5 fw400 fs14">Shipping Charge Breakup</div>
                                            </div>
                                            <div className="row-auto-space pl5 pr5">
                                                <div className="pt10 pb5 fw400 fs14">Freight Cost</div>
                                                <div className="pt10 pb5 fw400 fs14">&#8377; {shipmentDetails?.charges?.freight_cost || 0.0}</div>
                                            </div>
                                            <div className="row-auto-space pl5 pr5">
                                                <div className="pt10 pb5 fw400 fs14">Fuel Surcharge & DPH</div>
                                                <div className="pt10 pb5 fw400 fs14">&#8377; {shipmentDetails?.charges?.fuel_surcharge || 0.0}</div>
                                            </div>
                                            <div className="row-auto-space pl5 pr5">
                                                <div className="pt10 pb5 fw400 fs14">Prepaid Delivery</div>
                                                <div className="pt10 pb5 fw400 fs14">&#8377; {shipmentDetails?.charges?.prepaid_delivery || 0.0}</div>
                                            </div>
                                            <div className="row-auto-space pl5 pr5">
                                                <div className="pt10 pb5 fw400 fs14">GST - 18% (CGST=SGST)</div>
                                                <div className="pt10 pb5 fw400 fs14">&#8377; {shipmentDetails?.charges?.GST || 0.0}</div>
                                            </div>
                                            <div className="divider-h ml5 mr5"></div>
                                            <div className="row-auto-space pl5 pr5 pt5">
                                                <div className="pt10 pb5 fw500 fs14">Total</div>
                                                <div className="pt10 pb5 fw500 fs14">&#8377; {(shipmentDetails?.charges?.freight_cost || 0.0)
                                                    + (shipmentDetails?.charges?.fuel_surcharge || 0.0)
                                                    + (shipmentDetails?.charges?.prepaid_delivery || 0.0)
                                                    + (shipmentDetails?.charges?.GST || 0.0)}
                                                </div>
                                            </div>
                                        </Card.Body>
                                    </Card>
                                </div>
                            </div>
                            <div className="grid-b">
                                <Card border="secondary" >
                                    <Card.Body>
                                        <div className="heading pb5">Order Tracker</div>
                                        <Card className="grid-e bg-grey" border="secondary">
                                            <Card.Body>
                                                <div>
                                                    <div className="subheading">AWB No.:- {shipmentJourney?.journey_data?.awb_number || ""} </div>
                                                    <div className="fs14 fw400">Order ID:- {shipmentJourney?.journey_data?.order_number || ""}</div>
                                                </div>
                                                <div className="row-auto-space pt5">
                                                    <div>
                                                        <div className="subheading">Box Size</div>
                                                        <div className="fs14 fw400">
                                                            {shipmentDetails?.package_details?.shipmentdetails_response?.length || "0"}
                                                            *{shipmentDetails?.package_details?.shipmentdetails_response?.width || "0"}
                                                            *{shipmentDetails?.package_details?.shipmentdetails_response?.height || "0"}
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <div className="subheading">Box Weight</div>
                                                        <div className="fs14 fw400">{shipmentDetails?.package_details?.shipmentdetails_response?.volumetric_weight || "0"}</div>
                                                    </div>
                                                </div>
                                            </Card.Body>
                                        </Card>
                                        <div className="milestones pt10">
                                            {
                                                shipmentJourney?.journey_data?.journey?.reverse().map((item, index) => (
                                                    <div key={index} className="milestone-row">
                                                        <div className="line-dot-box">
                                                            <Button className="btn-dot"></Button>
                                                            {
                                                                shipmentJourney?.journey_data?.journey?.length !== (index + 1) && <div className="line"></div>
                                                            }
                                                        </div>
                                                        <div className="ml5">
                                                            <div className="subheading">{item.status}</div>
                                                            <div className="body-text">{item?.info}</div>
                                                        </div>
                                                    </div>
                                                ))
                                            }
                                        </div>
                                    </Card.Body>
                                </Card>
                                <div className="btn-stack pt10 row-auto-space">
                                    <Button className="btn-a" size="sm" variant="outline-secondary">Re Attempt</Button>
                                    <Button className="btn-b" size="sm">Return / Mark RTS</Button>
                                </div>
                            </div>
                        </>
                        :
                        <div className="data-not-found">
                            Data not found!
                        </div>
                }
            </Card.Body>
        </Card>
    )
}

export default TrackShipment;