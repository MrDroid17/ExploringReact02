import React from 'react';
import ReactDOM from 'react-dom/client';
import "../src/assets/styles/_variables.css"
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import { ReactKeycloakProvider } from '@react-keycloak/web';
import keycloak from './initKeycloak';
import { keyfile, localStoragekey, storeEncryptedData } from './utils/localStorageUtils';

const tokenLogger = (keycloakResponse) => {
  
  const { token } = keycloakResponse;
  storeEncryptedData(keyfile.token, localStoragekey.token, token);
}

const keycloakInitOptions={
  onLoad:'login-required',
  redirectUri: process.env.REACT_APP_KEYCLOAK_REDIRECT_URL,
  checkLoginIframe: false,
  responseType: 'code',
  requireHttps: false,
  showDebugInformation: true,
  disableAtHashCheck: true,
  skipIssuerCheck: false,
}


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ReactKeycloakProvider authClient={keycloak}
  onTokens={tokenLogger}
  initOptions={keycloakInitOptions}>
    <App />
  </ReactKeycloakProvider>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();





