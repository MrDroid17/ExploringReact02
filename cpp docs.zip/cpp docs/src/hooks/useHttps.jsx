import { useState, useCallback } from "react";
import axios from "axios";
import { useToast } from "../context/ToastContext";
import {
  keyfile,
  localStoragekey,
  retrieveDecryptedData
} from "../utils/localStorageUtils";
import { useLoader } from "../context/LoaderContext";
import { useAuth } from "../context/AuthContext";
import { isArray } from "chart.js/helpers";

export default function useHttps() {
  const { showLoader } = useLoader();
  const { showError } = useToast();  // Use specific functions for toast notifications
  const { logout } = useAuth();

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);
  const [statusCode, setStatusCode] = useState(null);

  // Response handler
  const handleResponse = useCallback(
    response => {
      if (response.status >= 200 && response.status < 300) {
        setData(response.data);
        setStatusCode(response.status);
        return response.data;  // Return successful response data
      }
      setError(response.data);
      setStatusCode(response.status);
      showError({
        detail: response.data.message || "An error occurred"
      });
      return undefined;
    },
    [showError]
  );

  // Common function to make any HTTP request
  const makeRequest = useCallback(
    async (method, requestData, url, isLoaderRequired) => {
      if(isLoaderRequired){
        showLoader(true);
      }
      setIsLoading(true);
      setError(null);

      const headers = {
        // "Content-Type": "application/json",
        'Authorization': `Bearer ${retrieveDecryptedData(localStoragekey.token, keyfile.token)}`,
        // 'X-CSRFTOKEN': retrieveDecryptedData(localStoragekey.token, keyfile.token)
      };
      const baseUriEndpoint = `https://test2.ecomexpress.in:8060${url}`;

      try {
        const config = {
          method,
          url: baseUriEndpoint,
          headers,
          data: requestData,
          Credential: 'include'
        };

        
        const response = await axios(config);
        return handleResponse(response);  // Handle the response
      } catch (err) {
        console.log("http error",err);
        setError(err);
        if (err.response && 
          err.response.status) {
          handleError(err,err.response.status)
        } else {
          const message = err.message || "An unexpected error occurred";
          showError({ detail: message });  // Show general error message
        }
        return undefined;
      } finally {
        setIsLoading(false);
        showLoader(false);
      }
    },
    [handleResponse, showError, showLoader, logout]
  );

  const handleError = (err,error_code)=>{
    switch(error_code){
      case 401:
        const errorMessage = err.response.data.error || "Unauthorized access";
        showError({ detail: errorMessage });
        logout();
        break;
      case 400:
          // Base error message from response
          if (err.response && err.response.data) {
            const { message, errors } = err;
            let errorDetails = message || "An error occurred";

            // Case 1: If 'errors' is an array
            if (Array.isArray(errors)) {
              errorDetails = getErrorMessageFromArray(errors);
            }
            // Case 2: If 'errors' is an object with key-value pairs
            else if (errors && typeof errors === "object" && Object.keys(errors).length > 0) {
              errorDetails = Object.entries(errors)
                .map(([key, value]) => `${key}: ${value}`)
                .join(" | ");
            }
            // Case 3: If 'message' is a string with multiple errors concatenated
            else if (message && typeof message === "string" && message.includes(":")) {
              // Extract error details from the message
              errorDetails = message
                .split(",") // Split by commas to separate individual errors
                .map((error) => error.trim()) // Trim whitespace
                .join(" | "); // Combine with a separator
            }
            // Case 4: Fallback to 'message' if it's a simple string
            else if (message && typeof message === "string") {
              errorDetails = message;
            }

          showError({ detail: errorDetails });

        }
        break;
      case 415:
        const { detail } = err.response.data;
        showError({detail: detail});
        break;

    }
  }

  const getErrorMessageFromArray=(dataSource)=>{
    let msg = ''
    const fieldErrors = Object.entries(dataSource)
                .map(([field, msgs]) => `${msgs.join(", ")}`)
                .join("\n");
    msg = `\n${fieldErrors}`;
    return msg;
  }

  // Separate function for GET requests
  const getRequest = useCallback(
    (url) => makeRequest("GET", null, url, true),
    [makeRequest]
  );

  // Separate function for POST requests
  const postRequest = useCallback(
    (url, requestData) => makeRequest("POST", requestData, url,true),
    [makeRequest]
  );

  // Separate function for PUT requests
  const putRequest = useCallback(
    (url, requestData) => makeRequest("PUT", requestData, url,true),
    [makeRequest]
  );

  // Separate function for DELETE requests
  const deleteRequest = useCallback(
    (url, requestData) => makeRequest("DELETE", requestData, url, true),
    [makeRequest]
  );

  // Separate function for PATCH requests
  const patchRequest = useCallback(
    (url, requestData) => makeRequest("PATCH", requestData, url,true),
    [makeRequest]
  );

  const getRequestWithoutLoader = useCallback(
    (url) => makeRequest("GET", null, url, false),
    [makeRequest]
  );
  
  return {
    data,
    isLoading,
    error,
    statusCode,
    getRequest,
    getRequestWithoutLoader,
    postRequest,
    putRequest,
    deleteRequest,
    patchRequest
  };
}
