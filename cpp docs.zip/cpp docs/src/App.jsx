import './App.css';
import { AuthProvider } from './context/AuthContext';
import { LoaderProvider } from './context/LoaderContext';
import { ToastProvider } from './context/ToastContext';
import AppWebRouter from './Routes';
function App() {  
  return (
    <AuthProvider>
    <ToastProvider>
      <LoaderProvider>
        <AppWebRouter/>
      </LoaderProvider>
    </ToastProvider>
  </AuthProvider>
  
  );
}

export default App;