import React, { useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useLocation,
  useNavigate,
} from "react-router-dom";
import AdminLayout from "./layouts/admin/AdminLayout";
import Dashboard from "./components/dashboard/Dashboard";
import Shipment from "./components/shipments/Shipments";
import Listing from "./components/listing/Listing";
import { useKeycloak } from "@react-keycloak/web";
import AWBDetail from "./components/listing/awbDetail/AWBDetail";
import Downloads from "./components/downloads/Downloads";
import Settings from "./components/settings/Settings";
import UserDetails from "./components/settings/userdetails/UserDetails";
import { SETTING_MENUS } from "./components/settings/constants";
import TrackShipment from "./components/tracking/trackShipment";


function AppWebRouter() {
  const { keycloak } = useKeycloak();

  return (
    <Router>
      <RoutePersistence isAuthenticated={keycloak.authenticated} />
      <Routes>
        {keycloak.authenticated && (
          <>
            <Route
              path="/"
              element={
                <Navigate
                  to={sessionStorage.getItem("currentRoute") || "/home/dashboard"}
                />
              }
            />
            <Route path="home" element={<AdminLayout />}>
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="shipment" element={<Shipment />} />
              <Route path="setting" element={<Settings />}>
                <Route path="user-details" element={<UserDetails />} />
                {SETTING_MENUS.map((menu) => (
                  <Route
                    key={menu.id}
                    path={menu.link}
                    element={menu.src}
                    label={menu}
                  />
                ))}
              </Route>
              <Route index element={<Dashboard />} />
              <Route path="generic-list/:screen" element={<Listing />} />
              {/* <Route path="awb" element={<AWBDetail />} /> */}
              <Route path="trackShipment/:awb?" element={<TrackShipment/>}/>
              <Route path="download" element={<Downloads />} />
            </Route>
          </>
        )}
      </Routes>
    </Router>
  );
}

const RoutePersistence = ({ isAuthenticated }) => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      sessionStorage.setItem("currentRoute", location.pathname + location.search);
    }
  }, [location, isAuthenticated]);

  useEffect(() => {
    const savedRoute = sessionStorage.getItem("currentRoute");
    if (isAuthenticated && savedRoute && savedRoute !== location.pathname) {
      navigate(savedRoute, { replace: true });
    }
  }, [navigate, isAuthenticated]);

  return null;
};

export default AppWebRouter;