import React, { useState, useEffect } from 'react';
import Dropdown from 'react-bootstrap/Dropdown';
import './Header.css';
import notificationImage from '../../../../assets/images/Notifications.svg';
import searchImage from '../../../../assets/images/ic_search.svg';
import actionImage from '../../../../assets/images/quick action.svg';
import { useKeycloak } from '@react-keycloak/web';
import { useNavigate } from 'react-router-dom';
import { Button } from 'react-bootstrap';
import { useLocation } from 'react-router-dom';
import useHttps from '../../../../hooks/useHttps';
import { ApiUrl } from '../../../../shared/apiUrl';
import { toast } from 'react-toastify';
import { awbNumberFormat } from '../../../../utils/common';


export default function Header() {
  const { keycloak } = useKeycloak();
  const [userInitial, setUserInitial] = useState('');
  const { getRequest } = useHttps()
  const navigate = useNavigate()
  const location = useLocation();
  const [searchValue, setSearchValue] = useState("");
  const [quickActions, setQuickActions] = useState([]);
  const [notificationCount, setNotificationCount] = useState(0);


  const isDashboardPath = location.pathname === '/home/dashboard';


  const quickAction = {
    Manifest : '',
    'Rate Calculator' : '',
    Downloads : '',
    'Recharge Wallet' : ''
  }


  const NotificationCountFetch = async () => { 
    try {
      const response = await getRequest(
        `${ApiUrl.NOTIFICATIONS}`);
      console.log(response.count)
      setNotificationCount(response.count)
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };


  const handleAWBClick = (searchValue) => {
    console.log(searchValue)
    if (searchValue.length > 4 && searchValue.length < 21){
      navigate(`/home/trackShipment/${searchValue}`);
      setSearchValue('');
    }else{
      toast.error('Input length must be between 5 and 20 characters');
    }
  };


  useEffect(() => {
    if (keycloak.authenticated) {
      getUserInfo();
    }
  }, [keycloak.authenticated]);


  const getUserInfo = async () => {
    try {
      const profile = await keycloak.loadUserInfo();
      if (profile?.name) {
        const initials = profile.name.charAt(0).toUpperCase();
        setUserInitial(initials);
      }
    } catch (error) {
      console.error("Error fetching user info from keycloak: ", error);

    }
  };

  // const handleNavigation = (event) => {
  //   const buttonName = event.target.innerHTML
  //   if (buttonName === 'Manifest'){
  //     navigate("/home/shipment")
  //   } else if (buttonName === 'Downloads'){
  //     navigate("/home/download")
  //   }
  // }

  const handleBack = () => {
    console.log(window.history)
    if (window.history.state && window.history.state.idx > 0) {
      navigate(-1);
    } else {
      navigate('/home/dashboard');
    }

  }


  const handleQuickActions = async () => {
    try{
      const response = await getRequest(`${ApiUrl.QUICKACTIONS}`);
      setQuickActions(response.results)
      console.log(response.results)
    }catch(error){
      console.error('Error fetching data:', error);
    }
  }

  useEffect(() => {
    handleQuickActions()
    NotificationCountFetch()
  },[])


  const logout = () => {
    localStorage.clear();
    sessionStorage.clear();
    keycloak.logout();
  };

  return (
    <div className="header">
      <div className="header-container">
        <div className="back">
          {!isDashboardPath && (
              <Button variant="outline-dark" onClick={handleBack}>
                ￩ Back
              </Button>
          )}
        </div>

        <div className="header-filters">
          <div className="search-container">
            <div className="input-container">
              <img className="icon" src={searchImage} alt="search icon" />
              <input className="header-search" 
                placeholder="Search AWB no." 
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                onKeyDown={(e) => awbNumberFormat(e, handleAWBClick, searchValue)}
              />
            </div>

            <div className="quick-action">
              <Dropdown>
                <Dropdown.Toggle variant="outline-dark" id="dropdown-basic">
                  <div className="dropdown-btn-container">
                    <img className="action-icon" src={actionImage} alt="quick action icon" />
                    <span>Quick Action</span>
                  </div>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  {quickActions.map((action,index) => {
                    return <Dropdown.Item key={index}>{action.title}</Dropdown.Item>
                  })}
                  {/* <Dropdown.Item onClick={handleNavigation}>Manifest</Dropdown.Item>
                  
                  <Dropdown.Item onClick={handleNavigation}>Downloads</Dropdown.Item>
                  <Dropdown.Item>Recharge Wallets</Dropdown.Item> */}
                </Dropdown.Menu>
              </Dropdown>
            </div>
          </div>

          <div className="d-flex justify-content-center align-items-center">
          <div className="relative inline-block">
            <img className="notification-icon" src={notificationImage} alt="notification icon" />
            <p className="notification-count absolute top-0 right-0 text-white bg-red-700 rounded-full text-xxs min-w-[15px] min-h-[15px] flex items-center justify-center">
              {notificationCount}
            </p>
          </div>

            <Dropdown>
              <Dropdown.Toggle as="div" className="user-avatar">
                <span className="user-initial">{userInitial}</span>
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item onClick={logout}>Logout</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
      </div>
    </div>
  );
}
