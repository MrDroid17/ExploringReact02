import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <div className='footer'>Copyright © 2024 Ecom Express. All rights reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></div>
  )
}

export default Footer