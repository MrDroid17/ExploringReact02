import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom'
import { Navbar, Nav } from 'react-bootstrap';
import eElementImage from '../../../../assets/images/E elements.svg';
import TechnicalImage from '../../../../assets/images/Technical.svg';
import ShipmentImage from '../../../../assets/images/Shipment.svg';
import DashboardImage from '../../../../assets/images/Dashboard.svg';
import RightarrowImage from '../../../../assets/images/ic_arrow_forward.svg';
import './Sidebar.css';

const menuItems = [
  { id: 'dashboard', src: DashboardImage, alt: 'dashboard', label: 'Dasboard', link:'/home/dashboard' },
  { id: 'shipment', src: ShipmentImage, alt: 'shipment', label: 'Shipment', link:'/home/shipment' },
  { id: 'tech', src: TechnicalImage, alt: 'tech', label: 'Settings', link:'/home/Setting/user-details' },
];

const toggleSidebarBtn =  { id: 'arrow', src: RightarrowImage, alt: 'arrow' };

const Sidebar = ({ isExpanded, toggleSidebar }) => {


  const navigate = useNavigate()

  const handleIconClick = () => {
    navigate('/home/dashboard')
  }


  return (
    <div className={`sidebar ${isExpanded ? 'expanded' : 'collapsed'}`}>
      {/* Brand logo */}
      <div className="brand-logo">
        <img className="logo cursor-pointer" onClick={() => handleIconClick()} src={eElementImage} alt="ecom-logo" />
      </div>
      
      <div className={isExpanded ? 'd-flex justify-content-end' : 'd-flex justify-content-center'}>
       <Nav.Link href="#" onClick={toggleSidebar}>
          <img src={toggleSidebarBtn.src} alt={toggleSidebarBtn.alt} /> 
       </Nav.Link>

      </div>
               
      {/* Sidebar Menu */}
        <div className="menu">
          <Navbar variant="dark" className="d-flex flex-column align-items-start">
            <Nav className="flex-column w-100">
              { 
                menuItems.map(menu=>{
                  return <NavLink 
                    to={menu.link} 
                    key={menu.id}
                    className="sidebar-link"
                    activeclassname="active"
                    exact="true"
                    >
                      <img src={menu.src} alt={menu.alt} /> 
                      { isExpanded  ? 
                      <span className='menu-label ml-2'>{menu.label}</span>
                      :''
                    }
                  </NavLink>
                  
                })
            }
            </Nav>
          </Navbar>
        </div>
    </div>
  );
};

export default Sidebar;
