import React, {useState} from 'react';
import { Outlet } from 'react-router-dom';
import Headers from './components/header/Header';
import Sidebar from './components/sidebar/Sidebar';
import "./AdminLayout.css";
import Footer from './components/footer/Footer';
import { useLoader } from '../../context/LoaderContext';
import Loader from '../../shared/ui/Loader';

const AdminLayout = ()=>{
    const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);
    const { isLoading } = useLoader()

    const toggleSidebar = () => {
      setIsSidebarExpanded(!isSidebarExpanded);
    };

    return (
        <>
            {isLoading && <Loader />}

            <div className='App'>  
                <div className='sidebar-section'>
                    <Sidebar isExpanded={isSidebarExpanded} toggleSidebar={toggleSidebar}/>
                </div>
                <div className={`main-content ${isSidebarExpanded ? 'shifted' : ''}`} >
                    <Headers isExpanded={isSidebarExpanded}/>
                    <div className='main-body-content'>
                        <Outlet/>
                    </div>
                    <div className='footer-section'>
                        <Footer />
                    </div>
                </div>
            </div>
        
        
        </>
    )   
}

export default AdminLayout;

